# Solcord 3.0.3 for Linux

Download SolcordInstaller-Linux-3.0.3-x86_64. In file Properties allow executing it as a program, then open it. Close Discord completely, select its installation if needed, and choose Install / Update. Launch Solcord from your application menu afterwards.

Terminal alternative:

    chmod +x SolcordInstaller-Linux-3.0.3-x86_64
    ./SolcordInstaller-Linux-3.0.3-x86_64

The compiled setup includes its Python/Tk runtime. System Python, pip, Node.js and FUSE are not required. It requests administrator access through polkit only when Discord's files require it. Use the native Discord package (.deb, .rpm, Arch/CachyOS packages, or an extracted native download); sandboxed Flatpak/Snap files cannot be patched in place.

This is an x86_64 glibc build made on Ubuntu 22.04. It targets modern distributions including CachyOS/Arch; ARM, musl-only distributions and much older glibc need another build. It uses the same desktop client and 623 bundled plugins as Windows; OS-specific integrations keep their own requirements.

A small native launcher replaces its process with Discord. No Python interpreter or background helper stays running during Discord use. Plugin code remains deferred and the library renders bounded pages. Normal Wayland/X11 and graphics preferences are preserved; this does not alter Discord's codec, Electron memory limits or hardware support.

Open the installer and choose Repair if a Discord package update replaces its loader. The launcher detects a replaced host and attempts repair where permissions allow. Remove restores the original host while retaining your settings.

CLI actions: install, repair, status and uninstall; optional --path /path/to/Discord and --channel stable|ptb|canary. Launch with ~/.local/bin/solcord. Use ~/.local/bin/solcord --diagnose for launcher status. The owner signed client updater is retained; Discord's own package/runtime updates remain managed by Discord or your distribution.

Corresponding source and GPL notices are included in the executable and available in the matching source download. Setup and loader tests run on Linux CI; physical CachyOS and live Discord account integration still need user verification.
