#!/bin/sh
set -eu
SOLCORD_INSTALLER_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
if ! command -v python3 >/dev/null 2>&1; then
    echo "Solcord needs Python 3.9 or newer. Install python3 using your distribution's package manager, then run this file again." >&2
    exit 1
fi
exec python3 "$SOLCORD_INSTALLER_DIR/solcord_linux.py" "$@"
