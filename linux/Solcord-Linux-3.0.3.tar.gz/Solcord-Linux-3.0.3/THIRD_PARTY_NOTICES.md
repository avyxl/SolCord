# Third-party notices

Solcord is maintained by avyxl: https://github.com/avyxl/SolCord

This distribution contains code derived from Endcord, Vencord, and Equicord. Original copyright and license notices are preserved in their files. The main project is licensed GPL-3.0-or-later; see LICENSE. Additional third-party code carries the licenses included alongside it. These notices describe code provenance and do not claim affiliation or endorsement.

## Windows installer fonts

Sora by The Sora Project Authors and Manrope by The Manrope Project Authors are bundled under the SIL Open Font License 1.1. Their complete notices are in installer/UI/Fonts/Sora-OFL.txt and Manrope-OFL.txt. Sources: https://github.com/google/fonts/tree/main/ofl/sora and https://github.com/google/fonts/tree/main/ofl/manrope.
