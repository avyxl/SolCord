#!/usr/bin/env python3
"""Solcord native Linux installer and launch-time repair. GPL-3.0-or-later, avyxl 2026."""

import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import struct
import sys
import uuid

FILES = ("patcher.js", "preload.js", "renderer.js", "renderer.css")
LOADER_MARKER = "SOLCORD-LINUX-LOADER:1"
CHANNELS = {"stable": ("discord", "Discord"), "ptb": ("discordptb", "discord-ptb", "DiscordPTB"), "canary": ("discordcanary", "discord-canary", "DiscordCanary")}


class InstallError(Exception):
    pass


def plain(path):
    path = Path(path)
    if path.is_symlink():
        raise InstallError("Refusing to replace a symbolic link: " + str(path))
    return path


def atomic(path, data, mode=0o644, owner=None):
    path = plain(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp-" + uuid.uuid4().hex)
    try:
        with temporary.open("xb") as stream:
            stream.write(data if isinstance(data, bytes) else data.encode("utf8"))
            stream.flush()
            os.fsync(stream.fileno())
        temporary.chmod(mode)
        if owner and os.name == "posix":
            os.chown(temporary, *owner)
        os.replace(temporary, path)
    finally:
        temporary.unlink(missing_ok=True)


def real_user():
    if os.name == "posix" and os.geteuid() == 0:
        import pwd
        name = os.environ.get("SUDO_USER", "")
        if not name or name == "root":
            raise InstallError("Run this from your normal desktop account. Use sudo only when the Discord folder requires it.")
        user = pwd.getpwnam(name)
        return Path(user.pw_dir), (user.pw_uid, user.pw_gid), True
    return Path.home(), None, False


class Paths:
    def __init__(self, home, config=None, data=None, owner=None):
        self.home = Path(home).resolve()
        self.config = Path(config or self.home / ".config").resolve() / "Solcord"
        self.data = Path(data or self.home / ".local/share").resolve() / "Solcord/linux"
        self.dist = self.config / "dist"
        self.owner = owner

    def make_dirs(self):
        for target in (self.config, self.data, self.home / ".local/bin", self.home / ".local/share/applications"):
            missing = []
            current = target
            while not current.exists():
                missing.append(current)
                current = current.parent
            if current.is_symlink() or any(p.is_symlink() for p in target.parents if p != self.home.parent):
                raise InstallError("Use real directories for Solcord's data paths.")
            target.mkdir(parents=True, exist_ok=True)
            if self.owner and os.name == "posix":
                for created in reversed(missing):
                    os.chown(created, *self.owner)
            plain(target)

    def state(self):
        try:
            value = json.loads(plain(self.data / "installed.json").read_text("utf8"))
            if value.get("schema") != 1 or not isinstance(value.get("installations"), list):
                raise ValueError()
            return value
        except FileNotFoundError:
            return {"schema": 1, "installations": []}
        except (ValueError, TypeError):
            raise InstallError("The Linux installation record is damaged. Keep a copy before reinstalling.")

    def save(self, value):
        atomic(self.data / "installed.json", json.dumps(value, indent=2) + "\n", 0o600, self.owner)


@contextlib.contextmanager
def install_lock(paths):
    paths.make_dirs()
    file = plain(paths.data / "installer.lock")
    with file.open("a+b") as stream:
        if paths.owner and os.name == "posix":
            os.chown(file, *paths.owner)
        try:
            if os.name == "posix":
                import fcntl
                fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
            yield
        except BlockingIOError:
            raise InstallError("Another Solcord installation is in progress.")


def is_asar(path):
    try:
        if plain(path).is_file():
            with Path(path).open("rb") as stream:
                start = stream.read(16)
                if len(start) != 16:
                    return False
                magic, header_bytes, payload_bytes, json_bytes = struct.unpack("<IIII", start)
                if magic != 4 or not 8 <= header_bytes <= 32 * 1024 * 1024 or not 0 < json_bytes <= header_bytes - 8 or payload_bytes > header_bytes:
                    return False
                header = json.loads(stream.read(json_bytes))
                return isinstance(header.get("files"), dict) and "package.json" in header["files"]
    except (OSError, ValueError, struct.error, InstallError):
        pass
    return False


def resources_at(path):
    candidate = Path(path).expanduser().resolve()
    if candidate.is_file():
        candidate = candidate.parent
    for res in (candidate, candidate / "resources"):
        if res.is_dir() and (is_asar(res / "app.asar") or is_asar(res / "_app.asar")):
            return res
    return None


def find_resources(home, channel="stable", explicit=None):
    if explicit:
        result = resources_at(explicit)
        if not result:
            raise InstallError("No original Discord app.asar was found in that folder. If Discord just installed, open it once first.")
        return [result]
    names = CHANNELS[channel]
    seeds = []
    for name in names:
        seeds.extend([Path(base) / name for base in ("/opt", "/usr/share", "/usr/lib", "/usr/lib64")])
        seeds.extend([Path(home) / base / name for base in (".local/share", ".local/opt", ".config", ".cache", "Applications", "")])
        executable = shutil.which(name)
        if executable:
            seeds.append(Path(executable).resolve().parent)
    found, visited = {}, set()
    for seed in seeds:
        if not seed.is_dir():
            continue
        for current, dirs, _ in os.walk(seed, followlinks=False):
            current = Path(current)
            depth = len(current.relative_to(seed).parts)
            dirs[:] = [name for name in dirs if name not in ("Cache", "Code Cache", "GPUCache", "node_modules", "logs", "Crashpad", "modules") and not (current / name).is_symlink()] if depth < 6 and len(visited) < 1200 else []
            if current in visited:
                dirs[:] = []
                continue
            visited.add(current)
            result = resources_at(current)
            if result:
                found[str(result)] = result
                dirs[:] = []
    return sorted(found.values(), key=lambda item: (item.stat().st_mtime_ns, str(item)), reverse=True)


def owns_loader(app):
    try:
        plain(app)
        record = json.loads(plain(Path(app) / ".solcord-loader.json").read_text("utf8"))
        return record.get("marker") == LOADER_MARKER and LOADER_MARKER in plain(Path(app) / "index.js").read_text("utf8")[:2048]
    except (OSError, ValueError, InstallError):
        return False


def host_running(resources):
    if not Path("/proc").is_dir():
        return False
    root = Path(resources).resolve().parent
    for process in Path("/proc").iterdir():
        if not process.name.isdigit():
            continue
        try:
            executable = (process / "exe").resolve(strict=True)
            if executable.name.lower().startswith("discord") and executable.parent == root:
                return True
        except (OSError, RuntimeError):
            continue
    return False


def patch_host(resources, paths, check_only=False):
    resources = Path(resources).resolve()
    if not resources_at(resources):
        raise InstallError("Discord's original application archive is missing.")
    original, backup, app = resources / "app.asar", resources / "_app.asar", resources / "app"
    for file in (original, backup, app):
        plain(file)
    if app.exists() and not owns_loader(app):
        raise InstallError("Another loader already uses resources/app. Remove that mod first; no files were replaced.")
    if original.exists() and not is_asar(original):
        raise InstallError("Another loader uses app.asar. Restore Discord with its installer first.")
    if backup.exists() and not is_asar(backup):
        raise InstallError("Discord's backup archive is not recognized. No files were replaced.")
    if host_running(resources):
        raise InstallError("Close Discord completely, including its tray icon, before installing or repairing this host.")
    if check_only:
        return
    token = uuid.uuid4().hex
    stage = resources / (".solcord-app-staging-" + token)
    moves = []
    try:
        stage.mkdir(mode=0o755)
        record = {"marker": LOADER_MARKER, "config": str(paths.config)}
        (stage / ".solcord-loader.json").write_text(json.dumps(record), "utf8")
        (stage / "package.json").write_text('{"name":"discord","main":"index.js"}\n', "utf8")
        # Use the launching user's config, even when root patched a system Discord. No user's home is hard-coded.
        loader = "// " + LOADER_MARKER + "\nconst path=require('path');\nconst config=process.env.XDG_CONFIG_HOME||path.join(require('os').homedir(),'.config');\nconst root=process.env.SOLCORD_USER_DATA_DIR||path.join(config,'Solcord');\nprocess.env.SOLCORD_USER_DATA_DIR=root;\ntry{require(path.join(root,'dist','patcher.js'));}catch(error){console.error('[Solcord] Loader failed; starting Discord.',error);require(path.join(__dirname,'..','_app.asar'));}\n"
        (stage / "index.js").write_text(loader, "utf8")

        def move(source, target):
            os.replace(source, target)
            moves.append((source, target))

        if app.exists():
            move(app, resources / (".solcord-old-app-" + token))
        if original.exists():
            if backup.exists():
                move(backup, resources / (".solcord-old-asar-" + token))
            move(original, backup)
        move(stage, app)
    except BaseException:
        for source, target in reversed(moves):
            if target.exists():
                os.replace(target, source)
        raise
    finally:
        if stage.exists():
            shutil.rmtree(stage)
    for _, temporary in moves:
        if temporary.name.startswith(".solcord-old-app-") and owns_loader(temporary):
            shutil.rmtree(temporary)
        elif temporary.name.startswith(".solcord-old-asar-") and is_asar(temporary):
            # Retain a single previous native archive for inspection, not an unbounded backup per host update.
            previous = plain(resources / ".solcord-previous-original.asar")
            if previous.exists() and not is_asar(previous):
                continue
            os.replace(temporary, previous)
    return {"resources": str(resources), "channel": "stable"}


def unpatch_host(resources):
    resources = Path(resources).resolve()
    app, original, backup = resources / "app", resources / "app.asar", resources / "_app.asar"
    if not app.exists():
        return False
    if not owns_loader(app) or not is_asar(backup):
        raise InstallError("This folder is not a recognized Solcord installation with an original backup. Nothing was removed.")
    if original.exists():
        raise InstallError("Discord has installed a new app.asar. Use repair before uninstalling to preserve the current host.")
    temporary = resources / (".solcord-uninstall-" + uuid.uuid4().hex)
    os.replace(app, temporary)
    try:
        os.replace(backup, original)
    except BaseException:
        os.replace(temporary, app)
        raise
    shutil.rmtree(temporary)
    return True


def install_payload(source, paths):
    source = Path(source)
    manifest = json.loads(plain(source / "manifest.json").read_text("utf8"))
    if manifest.get("schema") != 1 or set(manifest.get("files", {})) != set(FILES):
        raise InstallError("The bundled payload manifest is invalid.")
    content = {}
    for name in FILES:
        content[name] = plain(source / name).read_bytes()
        if hashlib.sha256(content[name]).hexdigest() != manifest["files"][name]:
            raise InstallError("Bundled payload failed its checksum: " + name)
    if b"// Platform: Universal" not in content["patcher.js"][:512]:
        raise InstallError("A platform-independent desktop build is required for Linux.")
    paths.make_dirs()
    stage = paths.config / (".linux-dist-" + uuid.uuid4().hex)
    stage.mkdir()
    previous = paths.config / ("dist.previous-linux-" + uuid.uuid4().hex)
    try:
        for name, value in content.items():
            atomic(stage / name, value, owner=paths.owner)
        atomic(stage / ".linux-payload.json", json.dumps(manifest), owner=paths.owner)
        if paths.owner and os.name == "posix":
            os.chown(stage, *paths.owner)
        plain(paths.dist)
        if paths.dist.exists():
            os.replace(paths.dist, previous)
        try:
            os.replace(stage, paths.dist)
        except BaseException:
            if previous.exists():
                os.replace(previous, paths.dist)
            raise
    finally:
        if stage.exists():
            shutil.rmtree(stage)
    if previous.exists():
        # Existing payloads are left available for rollback, without touching settings or account stores.
        known_previous = paths.config / "previous-linux"
        if known_previous.exists() and (known_previous / ".linux-payload.json").is_file():
            plain(known_previous)
            shutil.rmtree(known_previous)
        if not known_previous.exists():
            os.replace(previous, known_previous)
    return manifest


def desktop_quote(value):
    return '"' + str(value).replace("\\", "\\\\").replace('"', '\\"').replace("`", "\\`").replace("$", "\\$").replace("%", "%%") + '"'


def install_launcher(paths, channel, source_dir):
    manager = paths.data / "solcord_linux.py"
    atomic(manager, Path(__file__).read_bytes(), 0o755, paths.owner)
    icon = Path(source_dir) / "solcord.png"
    if icon.is_file():
        atomic(paths.data / "solcord.png", icon.read_bytes(), owner=paths.owner)
    command = ["python3", str(manager), "launch", "--channel", channel]
    launcher = "#!/bin/sh\nexec " + " ".join(shlex.quote(word) for word in command) + ' "$@"\n'
    atomic(paths.home / ".local/bin/solcord", launcher, 0o755, paths.owner)
    desktop = "[Desktop Entry]\nType=Application\nName=Solcord\nComment=Discord with Solcord plugins\nExec=" + " ".join(desktop_quote(word) for word in command) + " %U\nIcon=" + str(paths.data / "solcord.png") + "\nTerminal=false\nCategories=Network;InstantMessaging;\nStartupWMClass=discord\n"
    atomic(paths.home / ".local/share/applications/solcord.desktop", desktop, owner=paths.owner)


def host_executable(resources, channel):
    for name in CHANNELS[channel]:
        executable = Path(resources).parent / name
        if executable.is_file() and os.access(executable, os.X_OK):
            return executable
    raise InstallError("The Discord executable is not beside its resources folder. Reinstall the native Discord package or select its actual app folder with --path.")


def repair(paths, channel, explicit=None):
    state = paths.state()
    detected = find_resources(paths.home, channel, explicit)
    if not detected:
        detected = [Path(row["resources"]) for row in state["installations"] if row.get("channel") == channel and resources_at(row.get("resources", ""))]
    if not detected:
        raise InstallError("No native Discord app was found. Install Discord from discord.com/download, open it once, then run install.sh --path /path/to/Discord.")
    resource = detected[0]
    if not owns_loader(resource / "app") or (resource / "app.asar").exists():
        patch_host(resource, paths)
    state["installations"] = [row for row in state["installations"] if row.get("resources") != str(resource)] + [{"resources": str(resource), "channel": channel}]
    paths.save(state)
    return resource


def main(argv=None):
    parser = argparse.ArgumentParser(description="Solcord Linux — developed by avyxl")
    parser.add_argument("action", nargs="?", choices=("install", "repair", "launch", "status", "uninstall"), default="install")
    parser.add_argument("--path", help="Discord app folder, executable, or resources folder")
    parser.add_argument("--channel", choices=tuple(CHANNELS), default="stable")
    args, extra = parser.parse_known_args(argv)
    if extra and args.action != "launch":
        parser.error("Unexpected arguments: " + " ".join(extra))
    if not sys.platform.startswith("linux"):
        raise InstallError("Run this installer on Linux. It does not change your Windows or macOS installation.")
    home, owner, elevated = real_user()
    paths = Paths(home, None if elevated else os.environ.get("XDG_CONFIG_HOME"), None if elevated else os.environ.get("XDG_DATA_HOME"), owner)
    source = Path(__file__).resolve().parent
    if args.action == "launch":
        if elevated:
            raise InstallError("Launch Solcord from your normal account, without sudo.")
        if not all((paths.dist / name).is_file() for name in FILES):
            raise InstallError("Solcord's client files are missing. Run the downloaded install.sh again.")
        with install_lock(paths):
            resource = repair(paths, args.channel, args.path)
        environment = dict(os.environ, SOLCORD_USER_DATA_DIR=str(paths.config))
        os.execvpe(str(host_executable(resource, args.channel)), [str(host_executable(resource, args.channel)), *extra], environment)
    with install_lock(paths):
        if args.action == "install":
            candidates = find_resources(home, args.channel, args.path)
            if not candidates:
                raise InstallError("No native Discord app found. Open Discord once, then use --path to its app folder. Flatpak/Snap read-only app images are not patched by this installer.")
            if not os.access(candidates[0], os.W_OK):
                raise InstallError("Discord's resources folder needs administrator access. Close Discord and run: sudo python3 " + shlex.quote(str(source / "solcord_linux.py")) + " install --channel " + args.channel + " --path " + shlex.quote(str(candidates[0])))
            patch_host(candidates[0], paths, check_only=True)
            manifest = install_payload(source / "payload", paths)
            resource = repair(paths, args.channel, str(candidates[0]))
            install_launcher(paths, args.channel, source)
            print("Installed Solcord " + manifest["version"] + " with the full bundled desktop plugin set.\nOpen Solcord from your app menu, or run ~/.local/bin/solcord.\nDiscord: " + str(resource) + "\nEnable SolcordBot in Plugins and redeem your activation key in its settings.")
        elif args.action == "repair":
            print("Solcord loader repaired: " + str(repair(paths, args.channel, args.path)))
        elif args.action == "status":
            print(json.dumps({"clientDirectory": str(paths.dist), "payloadPresent": all((paths.dist / name).is_file() for name in FILES), "nativeInstallations": [{"resources": str(r), "solcordLoader": owns_loader(r / "app")} for r in find_resources(home, args.channel, args.path)], "record": paths.state()}, indent=2))
        elif args.action == "uninstall":
            state = paths.state()
            targets = find_resources(home, args.channel, args.path) if args.path else [Path(row["resources"]) for row in state["installations"] if row.get("channel") == args.channel]
            removed = []
            for resource in targets:
                if resources_at(resource):
                    if (resource / "app.asar").exists() and owns_loader(resource / "app"):
                        patch_host(resource, paths)
                    if unpatch_host(resource):
                        removed.append(str(resource))
            state["installations"] = [row for row in state["installations"] if row.get("resources") not in removed]
            paths.save(state)
            if not state["installations"]:
                for shortcut in (paths.home / ".local/bin/solcord", paths.home / ".local/share/applications/solcord.desktop"):
                    if shortcut.is_file() and not shortcut.is_symlink() and str(paths.data / "solcord_linux.py") in shortcut.read_text("utf8"):
                        shortcut.unlink()
            print("Restored Discord in " + str(len(removed)) + " installation(s). Your Solcord settings and account data were kept.")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (InstallError, PermissionError, FileNotFoundError, ValueError) as error:
        print("Solcord: " + str(error), file=sys.stderr)
        raise SystemExit(1)
