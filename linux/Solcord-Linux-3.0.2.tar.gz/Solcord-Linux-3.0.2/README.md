# Solcord for Linux

Developed by avyxl. This package contains the same platform-independent Solcord 3.0.0 desktop plugin bundle as the matching Windows installer, including SolcordBot. It installs into native Discord; Discord itself is not redistributed here. Original GPL notices and corresponding source are included.

1. Install native Discord from <https://discord.com/download>, open it once, then close it completely, including its tray icon.
2. Extract this archive. Open a terminal in the extracted folder.
3. Run `sh install.sh`.
4. Open **Solcord** from your application menu, or run `~/.local/bin/solcord`.

Python 3.9 or newer is required. Node.js, npm, a compiler and a separate Electron download are not required to install. If your Discord is in a system folder, the installer prints the exact sudo command needed. Launch the client from your normal desktop account.

Custom folder: `sh install.sh install --path /path/to/Discord`. The folder may contain `resources`, be the resources folder itself, or point to the executable. PTB and Canary are supported through `--channel ptb` or `--channel canary`.

Native .deb, .rpm, Arch and extracted tar installations are detected in common system and per-user locations, including version folders under `~/.local/share/discord`. Immutable Flatpak and Snap app images are not patched by this installer; use a native Discord installation. If automatic detection misses your custom path, use `--path`.

The Solcord launcher checks the host loader before starting Discord and repairs it when it has been replaced by an update, provided the current resources folder is writable. If a system package update replaces root-owned resources, rerun the printed administrator repair command. This does not promise repair during a Discord self-restart that bypasses the Solcord launcher. The existing signed Solcord client updater remains in the client; no new online release is published by this package.

## Plugin compatibility

All plugins in the matching desktop bundle are included, with the same lazy-loading structure, settings formats, custom profiles and badges. SolcordBot supports the same activation key as Windows: enable it in Plugins, redeem the key in its settings, then type `,sol help`.

Platform integrations retain their existing requirements. Windows Registry GPU binding does not apply on Linux; macOS Apple Music automation needs macOS; XSOverlay needs its external supported runtime. The credential vault requires a working Linux OS keyring and refuses plaintext fallback. Audio devices, screen capture and global shortcuts also depend on the Linux desktop, its permissions and installed services. Inclusion and code checks do not certify every hardware-dependent feature on every distribution.

The client code is loaded on demand. The installer adds no permanent polling service or background daemon. Its repair check runs when the Solcord launcher is used. Purge runs only after your explicit preview and typed confirmation.

## Maintenance

- Status: `python3 ~/.local/share/Solcord/linux/solcord_linux.py status`
- Repair: `python3 ~/.local/share/Solcord/linux/solcord_linux.py repair`
- Uninstall: `python3 ~/.local/share/Solcord/linux/solcord_linux.py uninstall`
- Custom XDG data roots place the manager under `$XDG_DATA_HOME/Solcord/linux`.

Uninstall restores the original Discord application archive. It keeps your Solcord settings and account-local data. Conflicting loaders are refused rather than removed automatically. Installation writes are staged and host changes roll back on failure.

`SHA256SUMS.txt` verifies archive contents. These local checksums establish integrity, not a signed online release. `Source/` contains the corresponding source and rebuild instructions. No private signing keys, bot token or original activation key is included in the public package.
