#!/usr/bin/env python3
"""Package the universal Solcord desktop payload for Linux. GPL-3.0-or-later, avyxl 2026."""
import hashlib
import io
import json
from pathlib import Path
import re
import tarfile
ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT.parents[1] / "outputs"
VERSION = json.loads((ROOT / "package.json").read_text("utf8"))["version"]
SOURCE = OUTPUT / ("Solcord-" + VERSION + "-source.zip")
PREFIX = "Solcord-Linux-" + VERSION
FILES = ("patcher.js", "preload.js", "renderer.js", "renderer.css")
source_dir = ROOT / "scripts/linuxInstaller"
content = {"payload/" + name: (ROOT / "dist" / name).read_bytes() for name in FILES}
if b"// Platform: Universal" not in content["payload/patcher.js"][:512]:
    raise RuntimeError("Build with --standalone first")
renderer = content["payload/renderer.js"]
layout = re.search(rb"/\*solcord-layout (\d+) (\d+) (-?\d+)\*/\n?$", renderer[-128:])
if not layout:
    raise RuntimeError("Packed plugin index is missing")
at, data = int(layout[1]), int(layout[2])
head = renderer[at:data].decode("utf8")
index = json.loads(head[head.index("\n", len("\n/*solcord-chunks ")) + 1:-1])
plugins = sorted(index["p"])
if "SolcordBot" not in plugins:
    raise RuntimeError("SolcordBot is missing")
manifest = {"schema": 1, "version": VERSION, "platform": "linux", "build": "universal-desktop", "lazyPluginCount": len(plugins), "files": {name: hashlib.sha256(content["payload/" + name]).hexdigest() for name in FILES}}
content["payload/manifest.json"] = (json.dumps(manifest, indent=2) + "\n").encode()
content["PLUGIN-INVENTORY.json"] = (json.dumps({"version": VERSION, "plugins": plugins, "chunks": len(index["c"]), "note": "Same universal client payload as the matching Windows installer. Platform integrations retain their OS and hardware requirements."}, indent=2) + "\n").encode()
for name in ("install.sh", "solcord_linux.py", "README.md"):
    content[name] = (source_dir / name).read_bytes()
content["LICENSE"] = (ROOT / "LICENSE").read_bytes()
content["THIRD_PARTY_NOTICES.md"] = (ROOT / "THIRD_PARTY_NOTICES.md").read_bytes()
content["Source/" + SOURCE.name] = SOURCE.read_bytes()
content["solcord.png"] = (ROOT / "assets/app_logo.png").read_bytes()
content["SHA256SUMS.txt"] = ("".join(hashlib.sha256(value).hexdigest() + "  " + name + "\n" for name, value in sorted(content.items()))).encode()
OUTPUT.mkdir(parents=True, exist_ok=True)
staging = OUTPUT / PREFIX
staging.mkdir(exist_ok=True)
for name, value in content.items():
    dest = staging / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(value)
target = OUTPUT / (PREFIX + ".tar.gz")
with tarfile.open(target, "w:gz", compresslevel=6) as archive:
    for name, value in sorted(content.items()):
        entry = tarfile.TarInfo(PREFIX + "/" + name)
        entry.size = len(value)
        entry.mode = 0o755 if name in ("install.sh", "solcord_linux.py") else 0o644
        entry.mtime = 0
        archive.addfile(entry, io.BytesIO(value))
print(json.dumps({"file": str(target), "staging": str(staging), "size": target.stat().st_size, "sha256": hashlib.sha256(target.read_bytes()).hexdigest(), "version": VERSION, "lazyPlugins": len(plugins), "chunks": len(index["c"]), "publicSourceIncluded": True}))
