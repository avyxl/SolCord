$ErrorActionPreference='Stop'
$repoRoot=Split-Path -Parent $PSScriptRoot
$resource=Join-Path $repoRoot 'dist\SolcordInstaller.g.resources'
if (!(Test-Path -LiteralPath $resource)) { throw 'Build the installer font resources first.' }
$csc='C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe'
$argsList=@('/nologo','/target:winexe','/optimize+',('/out:'+(Join-Path $repoRoot 'SolcordPublisher.exe')),('/resource:'+$resource+',SolcordPublisher.g.resources'),('/resource:'+(Join-Path $repoRoot 'assets\app_logo.png')+',app_logo.png'),('/win32icon:'+(Join-Path $repoRoot 'assets\app_icon.ico')),'/r:System.dll','/r:System.Core.dll','/r:System.IO.Compression.dll','/r:System.IO.Compression.FileSystem.dll','/r:System.Xaml.dll','/r:WPF\WindowsBase.dll','/r:WPF\PresentationCore.dll','/r:WPF\PresentationFramework.dll',(Join-Path $repoRoot 'tools\update-manager\PublisherWindow.cs'),(Join-Path $repoRoot 'tools\update-manager\ReleaseCore.cs'),(Join-Path $repoRoot 'installer\Core\Json.cs'),(Join-Path $repoRoot 'installer\Core\PayloadRelease.cs'),(Join-Path $repoRoot 'installer\Core\ReleaseManifest.cs'))
& $csc $argsList
if($LASTEXITCODE -ne 0){throw 'Update Manager compilation failed.'}
Write-Host 'Compiled SolcordPublisher.exe'
