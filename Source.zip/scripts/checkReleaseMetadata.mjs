/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readdirSync,readFileSync } from "node:fs";
import { join, relative } from "node:path";

import { unzipSync } from "fflate";

const root = join(import.meta.dirname, "..");
const { version } = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
const manifest = JSON.parse(readFileSync(join(root, "version.json"), "utf8"));
const sha = bytes => createHash("sha256").update(bytes).digest("hex");
assert.equal(manifest.manifestType, "solcord-local-build");
assert.equal(manifest.version, version);
assert.equal(manifest.published, false);
assert.equal(manifest.automaticUpdates, /Updater Disabled: false/.test(readFileSync(join(root,"dist/patcher.js"),"utf8")));
assert.equal(manifest.updatePolicy, "signed-releases-only");
for (const key of ["bundle", "downloadUrl", "signature", "installerSha256", "hash"])
    assert(!(key in manifest), `Stale release field: ${key}`);
assert.equal(manifest.installer.name, "SolcordInstaller.exe");
const exe = readFileSync(join(root, "SolcordInstaller.exe"));
assert.equal(manifest.installer.sha256, sha(exe));
assert.equal(manifest.installer.sizeBytes, exe.length);
assert.equal(manifest.embeddedPayloads.length, 4);
for (const asset of manifest.embeddedPayloads) {
    const bytes = readFileSync(join(root, "dist", asset.name));
    assert.equal(asset.sha256, sha(bytes));
    assert.equal(asset.sizeBytes, bytes.length);
}
const excluded = new Set(["node_modules", "dist", "dist_compressed", "previews", ".git", "node-v22", ".github", "benchmark"]);
const text = /\.(?:[cm]?js|tsx?|json|md|txt|sh|ps1|cs|html|ya?ml|css|manifest)$/i;
const legacy = new RegExp(["end", "cord"].join(""), "i");
const failures = [];
function audit(name, content) {
    if (!text.test(name) || name.endsWith("THIRD_PARTY_NOTICES.md") || /(?:SOLCORD-3.0-WORK|UPDATE-KEY-SETUP)\.md$/.test(name)) return;
    for (const [i, line] of content.split(/\r?\n/).entries())
        if (legacy.test(line) && !/copyright/i.test(line))
            failures.push(`${name}:${i + 1}`);
}
function walk(dir) {
    for (const entry of readdirSync(dir, { withFileTypes: true })) {
        if (excluded.has(entry.name)) continue;
        const file = join(dir, entry.name);
        if (entry.isDirectory()) walk(file);
        else if (entry.isFile()) {
            const name = relative(root, file).replaceAll("\\", "/");
            if (legacy.test(name)) failures.push(name);
            if (text.test(name)) audit(name, readFileSync(file, "utf8"));
        }
    }
}
walk(root);
if (process.argv[2]) {
    const files = unzipSync(readFileSync(process.argv[2]));
    const decode = name => new TextDecoder().decode(files[name]);
    assert.equal(JSON.parse(decode("Source/Solcord/package.json")).version, version);
    const packed = JSON.parse(decode("build-info.json"));
    assert.deepEqual(packed, manifest);
    assert.equal(sha(files["SolcordInstaller.exe"]), manifest.installer.sha256);
    assert.equal(decode("Source/Solcord/version.json"), decode("build-info.json"));
    for (const [name, bytes] of Object.entries(files)) {
        if (legacy.test(name)) failures.push(name);
        if (text.test(name)) audit(name, new TextDecoder().decode(bytes));
    }
}
assert.deepEqual(failures, [], "Legacy branding outside preserved copyright/provenance notices");
console.log(`PASS: Solcord ${version} metadata, actual installer/payload hashes, no stale online-release claims, and source/archive branding.`);
