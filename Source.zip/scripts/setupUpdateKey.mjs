/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */
import { generateKeyPairSync, createPrivateKey, createPublicKey } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { execFileSync } from "node:child_process";
import { homedir } from "node:os";
import { dirname, isAbsolute, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";
const root=resolve(dirname(fileURLToPath(import.meta.url)),"..");
const args=process.argv.slice(2),at=args.indexOf("--directory");
if(at>=0&&!args[at+1])throw Error("--directory needs an absolute private folder path.");
const folder=resolve(at<0?join(homedir(),".solcord"):args[at+1]);
const within=relative(root,folder);
if(!within||(!within.startsWith("..")&&!isAbsolute(within)))throw Error("Keep the private key outside the Solcord source folder.");
const privatePath=join(folder,"update-signing-key.pem");
const resume = args.includes("--resume");
if(existsSync(privatePath) && !resume)throw Error("Your private key already exists. Keep it. To finish setup using that same key, run: node scripts/setupUpdateKey.mjs --resume");
if(resume && !existsSync(privatePath))throw Error("No key exists to resume. Run the setup without --resume first.");
const trustedPath=join(root,"src/main/updater/updateKey.pem"),csharpPath=join(root,"installer/Core/ReleaseManifest.cs");
const csharp=readFileSync(csharpPath,"utf8");
if(!/const string PublicKeyBase64 = "[^"]+";/.test(csharp))throw Error("Installer trust field changed. No key was created.");
const privateKey = resume ? readFileSync(privatePath, "utf8") : generateKeyPairSync("ec", { namedCurve: "prime256v1", privateKeyEncoding: { format: "pem", type: "pkcs8" }, publicKeyEncoding: { format: "pem", type: "spki" } }).privateKey;
const parsedKey = createPrivateKey(privateKey);
if(parsedKey.asymmetricKeyType !== "ec" || parsedKey.asymmetricKeyDetails?.namedCurve !== "prime256v1") throw Error("This key is not a Solcord P-256 signing key. It has not been changed.");
const publicKey = createPublicKey(parsedKey).export({format:"pem",type:"spki"});
mkdirSync(folder,{recursive:true,mode:0o700});
if(!resume)writeFileSync(privatePath,privateKey,{flag:"wx",mode:0o600});
try{
    if(process.platform==="win32"){
        const sid=execFileSync("whoami",["/user","/fo","csv","/nh"],{encoding:"utf8"}).match(/S-1-(?:\d+-)+\d+/)?.[0];
        if(!sid)throw Error("Could not identify your Windows account for private-key permissions.");
        execFileSync("icacls",[privatePath,"/inheritance:r","/grant:r","*"+sid+":(F)","*S-1-5-18:(F)"],{stdio:"pipe"});
    }
    const base64=createPublicKey(publicKey).export({format:"der",type:"spki"}).toString("base64");
    writeFileSync(trustedPath,publicKey);
    writeFileSync(csharpPath,csharp.replace(/(const string PublicKeyBase64 = )"[^"]+";/,'$1"'+base64+'";'));
    const publicPath = join(folder,"update-signing-key.public.pem");
    if(existsSync(publicPath) && !createPublicKey(readFileSync(publicPath)).export({format:"der",type:"spki"}).equals(createPublicKey(publicKey).export({format:"der",type:"spki"}))) throw Error("A different public key already exists in this folder. It was not overwritten.");
    writeFileSync(publicPath,publicKey);
    console.log(resume ? "Existing key retained; setup completed." : "Key created locally.");
    console.log("Public key to share: " + publicPath);
    console.log("Desktop and Windows installer public trust updated. Rebuild both before publishing.");
    console.log("Back up the private key privately. Share only update-signing-key.public.pem.");
}catch(error){
    throw new Error("Setup stopped. Keep the private key at "+privatePath+" and restore/retry the public trust changes. "+error.message);
}
