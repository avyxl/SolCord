/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */


import {readFile,readdir,writeFile,mkdir} from "node:fs/promises";
import {resolve,join,relative} from "node:path";
import {createHash} from "node:crypto";
import vm from "node:vm";
import {build} from "esbuild";
import {zipSync,strToU8} from "fflate";
const root=resolve(import.meta.dirname,".."),output=resolve(root,"../../outputs");await mkdir(output,{recursive:true});
const pkg=JSON.parse(await readFile(join(root,"package.json"),"utf8")),features=JSON.parse(await readFile(join(root,"src/solcord3/features.json"),"utf8"));
if(!["3.0.0-dev.2", "3.0.2", "3.0.3"].includes(pkg.version))throw new Error("Review the archive identity when changing the release version.");
const compiled=await build({entryPoints:[join(root,"src/solcord3/availability.ts")],bundle:true,write:false,format:"cjs",platform:"node",logLevel:"error"}),module={exports:{}};vm.runInNewContext(compiled.outputFiles[0].text,{module,exports:module.exports,Set,Map});
const {IMPLEMENTED,PARTIAL,COVERED}=module.exports,groups=[["Implemented",features.filter(f=>IMPLEMENTED.has(f.id))],["In progress",features.filter(f=>PARTIAL.has(f.id))],["Already covered",features.filter(f=>COVERED.has(f.id))],["Planned",features.filter(f=>!IMPLEMENTED.has(f.id)&&!PARTIAL.has(f.id)&&!COVERED.has(f.id))]];
if(new Set(features.map(f=>f.id)).size!==200||IMPLEMENTED.size+PARTIAL.size+COVERED.size>200)throw new Error("Invalid feature inventory.");
const status=["# Solcord 3.0 development status","","This is development source, not a stable 3.0 release. Planned requirements are not working plugins.","",groups.map(([label,rows])=>label+": "+rows.length).join(" · "),"","Changelog: top-right toolbar, control center, Settings > Changelog.","","Validation limits: component fixtures mock Discord adapters; native fixtures mock OS encryption, windows and network. Live Discord, real microphone hardware, native voice processing and optional model downloads need integration verification.","","Performance: new tools are optional. Heavy models and engines are loaded on request. The shared read index is bounded; Busy Hours retains metadata only.","","Configuration: public-resource tools require allowed HTTPS origins and daily request budgets in Integration controls. Credentials use available OS encryption. Some capabilities are desktop-only.","",...groups.flatMap(([label,rows])=>["## "+label,"",...rows.map(f=>"- "+f.id+". **"+f.name+"** — "+f.description+(PARTIAL.has(f.id)?" "+PARTIAL.get(f.id):COVERED.has(f.id)?" "+COVERED.get(f.id):"")),""] )].join("\n");
await mkdir(join(root,"docs"),{recursive:true});await writeFile(join(root,"docs/SOLCORD-3.0-STATUS.md"),status);
const files={},prefix="Solcord-"+pkg.version+"/";let count=0;
async function add(file){const rel=relative(root,file).replaceAll("\\","/");if(rel.startsWith("../")||/\/(?:node_modules|dist|dist_compressed)\//.test("/"+rel))return;if(/(?:^|\/)\.env(?:\.|$)|STAFF-KEYS\.txt|private.*signing.*\.json/i.test(rel))throw new Error("Private configuration cannot be packaged.");files[prefix+rel]=new Uint8Array(await readFile(file));count++;}
async function walk(dir){for(const e of await readdir(dir,{withFileTypes:true})){if(e.isSymbolicLink()||["node_modules","dist","dist_compressed",".git","__pycache__"].includes(e.name))continue;const file=join(dir,e.name);if(e.isDirectory())await walk(file);else if(e.isFile())await add(file);}}
for(const dir of ["src","packages","assets","scripts","installer","tools","test","docs","patches",".github"])await walk(join(root,dir));
for(const file of ["package.json","pnpm-lock.yaml","pnpm-workspace.yaml","tsconfig.json","eslint.config.mjs",".stylelintrc.json",".editorconfig","LICENSE","THIRD_PARTY_NOTICES.md","README.md","CONTRIBUTING.md","CODE_OF_CONDUCT.md","SECURITY.md","CHANGELOG.md","SOLCORD-3.0-WORK.md"])await add(join(root,file));
files[prefix+"DEVELOPMENT-STATUS.md"]=strToU8(status);
const bytes=zipSync(files,{level:6}),target=join(output,"Solcord-"+pkg.version+"-source.zip");await writeFile(target,bytes);
console.log(JSON.stringify({target,files:count+1,bytes:bytes.length,sha256:createHash("sha256").update(bytes).digest("hex"),counts:Object.fromEntries(groups.map(([label,rows])=>[label,rows.length]))}));
