# Builds SolcordInstaller.exe from dist/ and runs its self-test. The exe and a zip of it go to dist\Installer, and a copy
# of the exe next to this repo. Releases ship them from GitHub (scripts/githubRelease.mjs), never from the site
$ErrorActionPreference = "Stop"

$repoRoot = Split-Path -Parent $PSScriptRoot
$cscPath = "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\csc.exe"
$outExe = Join-Path $repoRoot "SolcordInstaller.exe"
# The installer copy sits next to this repo
$workDir = Split-Path -Parent $repoRoot
$desktopExe = Join-Path $workDir "SolcordInstaller.exe"
$distInstallerDir = Join-Path $repoRoot "dist\Installer"

foreach ($outputPath in @($outExe, $desktopExe, (Join-Path $distInstallerDir "SolcordInstaller.exe"))) {
    if (Test-Path -LiteralPath $outputPath) {
        try {
            $outputCheck = [System.IO.File]::Open($outputPath, [System.IO.FileMode]::Open, [System.IO.FileAccess]::ReadWrite, [System.IO.FileShare]::None)
            $outputCheck.Dispose()
        } catch { throw "Close the installer using '$outputPath' before building. No process was stopped." }
    }
}

Write-Host "[1/5] Ensuring dist payload files exist..." -ForegroundColor Cyan
$distDir = Join-Path $repoRoot "dist"
$distCompressedDir = Join-Path $repoRoot "dist_compressed"
if (!(Test-Path $distDir)) {
    New-Item -ItemType Directory -Path $distDir -Force | Out-Null
}

$payloadNames = @("patcher.js", "preload.js", "renderer.js", "renderer.css")
foreach ($pName in $payloadNames) {
    $rawFile = Join-Path $distDir $pName
    $gzFile = Join-Path $distCompressedDir ($pName + ".gz")
    if ((!(Test-Path $rawFile)) -and (Test-Path $gzFile)) {
        $inStream = [System.IO.File]::OpenRead($gzFile)
        $gzStream = New-Object System.IO.Compression.GZipStream($inStream, [System.IO.Compression.CompressionMode]::Decompress)
        $outStream = [System.IO.File]::Create($rawFile)
        $gzStream.CopyTo($outStream)
        $outStream.Close()
        $gzStream.Close()
        $inStream.Close()
        Write-Host "  -> Unpacked $pName from dist_compressed" -ForegroundColor DarkGray
    }
}

# The installer refuses any payload file whose hash isn't in this list, so a file planted next to the exe can't be installed
$hashFile = Join-Path $distDir "payload.sha256"
$hashLines = foreach ($pName in $payloadNames) {
    $hash = (Get-FileHash -Algorithm SHA256 -LiteralPath (Join-Path $distDir $pName)).Hash.ToLowerInvariant()
    "$hash  $pName"
}
[System.IO.File]::WriteAllLines($hashFile, [string[]]$hashLines, (New-Object System.Text.UTF8Encoding($false)))

# Embedded WPF font resources: no font installation or extra runtime downloads.
$fontResource = Join-Path $distDir "SolcordInstaller.g.resources"
$fontWriter = New-Object System.Resources.ResourceWriter($fontResource)
try {
    foreach ($font in @("Sora", "Manrope")) {
        $fontStream = [System.IO.File]::OpenRead((Join-Path $repoRoot ("installer/UI/Fonts/" + $font + ".ttf")))
        $fontWriter.AddResource(("fonts/" + $font.ToLowerInvariant() + ".ttf"), [System.IO.Stream]$fontStream, $true)
    }
    $fontWriter.Generate()
} finally { $fontWriter.Close() }

Write-Host "[2/5] Collecting installer C# sources..." -ForegroundColor Cyan
$csFiles = @()
$csFiles += Get-ChildItem -Path (Join-Path $repoRoot "installer") -Recurse -Filter "*.cs" | Select-Object -ExpandProperty FullName

Write-Host ("  -> Found " + $csFiles.Count + " source files.") -ForegroundColor Gray

$cscArgs = @(
    "/target:winexe",
    "/optimize+",
    "/utf8output",
    "/out:$outExe",
    "/win32icon:$(Join-Path $repoRoot 'assets/app_icon.ico')",
    "/win32manifest:$(Join-Path $repoRoot 'installer/app.manifest')",
    "/resource:$(Join-Path $repoRoot 'dist\patcher.js'),patcher.js",
    "/resource:$(Join-Path $repoRoot 'dist\preload.js'),preload.js",
    "/resource:$(Join-Path $repoRoot 'dist\renderer.js'),renderer.js",
    "/resource:$(Join-Path $repoRoot 'dist\renderer.css'),renderer.css",
    "/resource:$hashFile,payload.sha256",
    "/resource:$fontResource,SolcordInstaller.g.resources",
    "/resource:$(Join-Path $repoRoot 'assets/app_logo.png'),app_logo.png",
    "/r:System.dll",
    "/r:System.Core.dll",
    "/r:System.IO.Compression.dll",
    "/r:System.Drawing.dll",
    "/r:System.Windows.Forms.dll",
    "/r:System.Web.Extensions.dll",
    "/r:System.Xaml.dll",
    "/r:WPF\WindowsBase.dll",
    "/r:WPF\PresentationCore.dll",
    "/r:WPF\PresentationFramework.dll"
)
$cscArgs += $csFiles

Write-Host "[3/5] Compiling SolcordInstaller.exe..." -ForegroundColor Cyan
& $cscPath $cscArgs

if ($LASTEXITCODE -ne 0) {
    Write-Error "Compilation failed with exit code $LASTEXITCODE"
    exit $LASTEXITCODE
}
Write-Host "  -> Compiled successfully: $outExe" -ForegroundColor Green

Write-Host "[4/5] Running Automated Installer Self-Tests (--self-test)..." -ForegroundColor Cyan
$testReport = Join-Path $repoRoot "installer-selftest.log"
if (Test-Path $testReport) { Remove-Item $testReport -Force }
$env:SOLCORD_TEST_REPORT = $testReport
# Keep fixture paths short enough for the .NET Framework file APIs.
$fixtureTemp = Join-Path $repoRoot "test-temp"
New-Item -ItemType Directory -Force -Path $fixtureTemp | Out-Null
$oldTestTemp = $env:TEMP
$oldTestTmp = $env:TMP
$env:TEMP = $fixtureTemp
$env:TMP = $fixtureTemp
try {
    $proc = Start-Process -FilePath $outExe -ArgumentList @("--self-test", $testReport) -Wait -PassThru -WindowStyle Hidden
} finally { $env:TEMP = $oldTestTemp; $env:TMP = $oldTestTmp }
if (Test-Path $testReport) {
    Get-Content $testReport | ForEach-Object { Write-Host "  $_" -ForegroundColor Gray }
}
if ($proc.ExitCode -ne 0) {
    Write-Error "Automated self-tests failed with exit code $($proc.ExitCode)"
    exit $proc.ExitCode
}
Write-Host "  -> All self-tests passed!" -ForegroundColor Green


& node (Join-Path $repoRoot "scripts/writeLocalManifest.mjs")
if ($LASTEXITCODE -ne 0) { throw "Local release metadata generation failed." }

Write-Host "[5/5] Publishing artifacts..." -ForegroundColor Cyan
if (!(Test-Path $distInstallerDir)) {
    New-Item -ItemType Directory -Path $distInstallerDir -Force | Out-Null
}
Copy-Item -Path $outExe -Destination (Join-Path $distInstallerDir "SolcordInstaller.exe") -Force
Copy-Item -Path $outExe -Destination $desktopExe -Force
# For browsers that block a downloaded .exe: the same installer in a zip
$zipPath = Join-Path $distInstallerDir "SolcordInstaller.zip"
if (Test-Path $zipPath) { Remove-Item $zipPath -Force }
Compress-Archive -Path $outExe -DestinationPath $zipPath -Force

# What people can check their download against
Write-Host ("SHA-256 of SolcordInstaller.exe: " + (Get-FileHash -Algorithm SHA256 -LiteralPath $outExe).Hash.ToLowerInvariant()) -ForegroundColor Gray
Write-Host "Build & Test complete!" -ForegroundColor Green
