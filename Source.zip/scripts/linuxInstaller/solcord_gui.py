#!/usr/bin/env python3
"""Solcord native setup window. Copyright 2026 avyxl. GPL-3.0-or-later."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import threading

import solcord_linux as core


def cli(arguments):
    try:
        return core.main(arguments)
    except (core.InstallError, OSError, ValueError) as error:
        print("Solcord: " + str(error), file=sys.stderr)
        return 1


def gui(smoke=False):
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    root = tk.Tk()
    root.title("Solcord Installer")
    root.geometry("880x650")
    root.minsize(800, 600)
    root.configure(bg="#0c0b10")
    asset_root = Path(getattr(sys, "_MEIPASS", Path(__file__).parent))
    manifest = json.loads((asset_root / "payload/manifest.json").read_text("utf8"))
    style = ttk.Style(root)
    style.theme_use("clam")
    style.configure("TButton", background="#25202f", foreground="#f4f1fa", borderwidth=0, padding=(16, 11), font=("DejaVu Sans", 10))
    style.map("TButton", background=[("active", "#393047")], foreground=[("disabled", "#81798e")])
    style.configure("Accent.TButton", background="#8540d7", foreground="white")
    style.map("Accent.TButton", background=[("active", "#9945ff")])
    style.configure("Horizontal.TProgressbar", background="#62e7bc", troughcolor="#211c2a", borderwidth=0)
    left = tk.Frame(root, bg="#17151e", width=210)
    left.pack(side="left", fill="y")
    left.pack_propagate(False)
    original_image = tk.PhotoImage(file=str(asset_root / "solcord.png"))
    factor = max(1, original_image.width() // 64)
    image = original_image.subsample(factor, factor)
    tk.Label(left, image=image, bg="#17151e").pack(anchor="w", padx=25, pady=(30, 16))
    tk.Label(left, text="Solcord", bg="#17151e", fg="#f4f1fa", font=("DejaVu Sans", 22, "bold")).pack(anchor="w", padx=25)
    tk.Label(left, text="LINUX INSTALLER", bg="#17151e", fg="#62e7bc", font=("DejaVu Sans", 9)).pack(anchor="w", padx=25, pady=(8, 35))
    tk.Label(left, text="1  Choose Discord\n\n2  Install or update\n\n3  Open Solcord", justify="left", bg="#17151e", fg="#c2b9d0", font=("DejaVu Sans", 11)).pack(anchor="w", padx=25)
    tk.Label(left, text="Developed by avyxl", bg="#17151e", fg="#62e7bc", font=("DejaVu Sans", 9)).pack(side="bottom", anchor="w", padx=25, pady=25)
    right = tk.Frame(root, bg="#0c0b10")
    right.pack(side="left", fill="both", expand=True, padx=30, pady=28)
    tk.Label(right, text="Install Solcord " + manifest["version"], bg="#0c0b10", fg="#f4f1fa", font=("DejaVu Sans", 21, "bold")).pack(anchor="w")
    tk.Label(right, text="The full desktop plugin bundle, with a native Linux launcher.", bg="#0c0b10", fg="#aaa3ba", font=("DejaVu Sans", 10), wraplength=560, justify="left").pack(anchor="w", pady=(8, 22))
    selected = tk.StringVar()
    status = tk.StringVar(value="Looking for Discord…")
    tk.Label(right, text="Discord installation", bg="#0c0b10", fg="#c2b9d0", font=("DejaVu Sans", 11)).pack(anchor="w")
    field = tk.Entry(right, textvariable=selected, bg="#17151e", fg="#f4f1fa", insertbackground="white", relief="flat", font=("DejaVu Sans", 10))
    field.pack(fill="x", ipady=12, pady=(8, 10))
    ttk.Button(right, text="Choose Discord folder", command=lambda: selected.set(filedialog.askdirectory(title="Choose the Discord app or resources folder") or selected.get())).pack(anchor="w")
    tk.Label(right, text="Close Discord completely before installing or repairing. Your settings are kept when updating or removing Solcord.", bg="#0c0b10", fg="#aaa3ba", wraplength=560, justify="left", font=("DejaVu Sans", 10)).pack(anchor="w", pady=(18, 12))
    log = tk.Text(right, height=10, bg="#17151e", fg="#c2b9d0", relief="flat", font=("DejaVu Sans Mono", 9), wrap="word", state="disabled")
    log.pack(fill="both", expand=True)
    bar = ttk.Progressbar(right, mode="indeterminate")
    bar.pack(fill="x", pady=(12, 8))
    tk.Label(right, textvariable=status, bg="#0c0b10", fg="#62e7bc", wraplength=560, justify="left", font=("DejaVu Sans", 10)).pack(anchor="w", pady=(2, 12))
    actions = tk.Frame(right, bg="#0c0b10")
    actions.pack(fill="x")
    buttons = []
    busy = [False]

    def append(line):
        log.configure(state="normal")
        log.insert("end", line)
        log.see("end")
        log.configure(state="disabled")

    def completed(code):
        busy[0] = False
        bar.stop()
        for button in buttons:
            button.configure(state="normal")
        status.set("Finished. Open Solcord from your application menu." if code == 0 else "This step stopped. The details above explain what needs attention.")

    def run(action):
        if busy[0]:
            return
        resource = core.resources_at(selected.get()) if selected.get().strip() else None
        if not resource:
            messagebox.showerror("Choose Discord", "Select the installed Discord folder first. Open Discord once if it has only just been installed.")
            return
        if action == "uninstall" and not messagebox.askyesno("Remove Solcord?", "Restore Discord's original loader? Your Solcord settings and account data will be kept."):
            return
        command = ([sys.executable] if getattr(sys, "frozen", False) else [sys.executable, str(Path(__file__))]) + [action, "--path", str(resource)]
        if not os.access(resource, os.W_OK):
            pkexec = shutil.which("pkexec")
            if not pkexec:
                messagebox.showerror("Administrator access needed", "Install polkit or run this installer's command from your normal account using sudo.")
                return
            command = [pkexec, *command]
        busy[0] = True
        for button in buttons:
            button.configure(state="disabled")
        bar.start(15)
        status.set("Installing…" if action == "install" else "Working…")

        def worker():
            try:
                with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True) as process:
                    for line in process.stdout:
                        root.after(0, append, line)
                    code = process.wait()
            except OSError as error:
                root.after(0, append, str(error) + "\n")
                code = 1
            root.after(0, completed, code)
        threading.Thread(target=worker, daemon=True).start()

    for label, action in (("Remove", "uninstall"), ("Repair", "repair"), ("Install / Update", "install")):
        button = ttk.Button(actions, text=label, style="Accent.TButton" if action == "install" else "TButton", command=lambda value=action: run(value))
        button.pack(side="left", padx=(0, 10))
        buttons.append(button)

    def detected(rows):
        if rows:
            selected.set(str(rows[0]))
            status.set("Discord found. Ready to install.")
        else:
            status.set("Choose your Discord folder. Native Arch, .deb, .rpm and extracted installations are supported.")

    def detect():
        try:
            rows = core.find_resources(Path.home())
            root.after(0, detected, rows)
        except OSError as error:
            root.after(0, append, str(error) + "\n")
    if not smoke:
        threading.Thread(target=detect, daemon=True).start()
    else:
        status.set("Native setup window loaded successfully.")
        root.after(300, root.destroy)
    root.protocol("WM_DELETE_WINDOW", lambda: None if busy[0] else root.destroy())
    root.mainloop()
    return 0


if __name__ == "__main__":
    if sys.argv[1:] == ["--ui-smoke"]:
        raise SystemExit(gui(True))
    if sys.argv[1:]:
        raise SystemExit(cli(sys.argv[1:]))
    raise SystemExit(gui())
