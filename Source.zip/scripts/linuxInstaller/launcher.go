//go:build linux

// Solcord native Linux launcher. Copyright 2026 avyxl. GPL-3.0-or-later.
package main

import (
 "encoding/json"
 "fmt"
 "os"
 "os/exec"
 "path/filepath"
 "strings"
 "syscall"
 "time"
)

type installation struct { Resources string `json:"resources"`; Channel string `json:"channel"`; Command []string `json:"command"` }
type record struct { Schema int `json:"schema"`; Config string `json:"config"`; Manager string `json:"manager"`; DefaultChannel string `json:"defaultChannel"`; Installations []installation `json:"installations"` }
func exists(path string) bool { item,err:=os.Stat(path);return err==nil&&!item.IsDir() }
func healthy(resource string) bool {
 if exists(filepath.Join(resource,"app.asar"))||!exists(filepath.Join(resource,"_app.asar")){return false}
 data,err:=os.ReadFile(filepath.Join(resource,"app",".solcord-loader.json"));return err==nil&&strings.Contains(string(data),"SOLCORD-LINUX-LOADER:1")
}
func load(path string)(record,error){var r record;data,err:=os.ReadFile(path);if err!=nil{return r,err};if len(data)>65536{return r,fmt.Errorf("installation record is too large")};err=json.Unmarshal(data,&r);if err==nil&&r.Schema!=1{err=fmt.Errorf("unsupported installation record")};return r,err}
func newest(home,channel string,current installation)string{
 names:=map[string][]string{"stable":{"discord","Discord"},"ptb":{"discordptb","discord-ptb","DiscordPTB"},"canary":{"discordcanary","discord-canary","DiscordCanary"}}[channel]
 best:=current.Resources;var stamp time.Time;if info,err:=os.Stat(best);err==nil{stamp=info.ModTime()}
 visited:=0
 for _,name:=range names {for _,base:=range []string{filepath.Join(home,".local/share"),filepath.Join(home,".local/opt"),"/usr/share","/usr/lib","/usr/lib64","/opt"}{
  seed:=filepath.Join(base,name)
  filepath.WalkDir(seed,func(path string,entry os.DirEntry,err error)error{
   if err!=nil{return nil};if !entry.IsDir(){return nil};visited++;rel,_:=filepath.Rel(seed,path)
   if visited>1200||strings.Count(rel,string(os.PathSeparator))>6{return filepath.SkipDir}
   switch entry.Name(){case "Cache","Code Cache","GPUCache","modules","logs","node_modules":return filepath.SkipDir}
   resource:=path;if filepath.Base(resource)!="resources"{resource=filepath.Join(resource,"resources")}
   if exists(filepath.Join(resource,"app.asar"))||exists(filepath.Join(resource,"_app.asar")){if info,e:=os.Stat(resource);e==nil&&info.ModTime().After(stamp){best=resource;stamp=info.ModTime()};return filepath.SkipDir};return nil
  })
 }}
 return best
}
func run(args []string)error{
 home,err:=os.UserHomeDir();if err!=nil{return err};data:=os.Getenv("XDG_DATA_HOME");if data==""{data=filepath.Join(home,".local/share")};statePath:=filepath.Join(data,"Solcord/linux/installed.json")
 state,err:=load(statePath);if err!=nil{return fmt.Errorf("open Solcord Installer and install first: %w",err)}
 channel:=state.DefaultChannel;if channel==""{channel="stable"};diagnose:=false;forward:=[]string{}
 for i:=0;i<len(args);i++{if args[i]=="--channel"&&i+1<len(args){i++;channel=args[i]}else if args[i]=="--diagnose"{diagnose=true}else{forward=append(forward,args[i])}}
 var chosen installation;for _,item:=range state.Installations{if item.Channel==channel{chosen=item}}
 if chosen.Resources==""{return fmt.Errorf("%s is not installed; open Solcord Installer",channel)}
 resource:=newest(home,channel,chosen);needsRepair:=resource!=chosen.Resources||!healthy(resource)||len(chosen.Command)==0
 if len(chosen.Command)>0&&!exists(chosen.Command[0]){needsRepair=true}
 if diagnose{return json.NewEncoder(os.Stdout).Encode(map[string]interface{}{"nativeLauncher":true,"repairNeeded":needsRepair,"channel":channel,"resources":resource})}
 if needsRepair{
  if !exists(state.Manager){return fmt.Errorf("open Solcord Installer to repair this Discord update")}
  command:=exec.Command(state.Manager,"repair","--channel",channel,"--path",resource);command.Stdout=os.Stdout;command.Stderr=os.Stderr
  if err=command.Run();err!=nil{return fmt.Errorf("open Solcord Installer and choose Repair; administrator access may be required")}
  state,err=load(statePath);if err!=nil{return err};for _,item:=range state.Installations{if item.Channel==channel&&item.Resources==resource{chosen=item}}
 }
 if len(chosen.Command)==0{return fmt.Errorf("the Discord runtime is missing; repair Solcord using its installer")}
 binary,err:=exec.LookPath(chosen.Command[0]);if err!=nil{return err};environment:=os.Environ();if state.Config!=""{environment=append(environment,"SOLCORD_USER_DATA_DIR="+state.Config)}
 // Replace this process. No Python interpreter, monitor or helper remains resident during Discord use.
 return syscall.Exec(binary,append(chosen.Command,forward...),environment)
}
func main(){if err:=run(os.Args[1:]);err!=nil{message:="Solcord: "+err.Error();fmt.Fprintln(os.Stderr,message);if program,e:=exec.LookPath("kdialog");e==nil{exec.Command(program,"--error",message,"--title","Solcord").Run()}else if program,e:=exec.LookPath("zenity");e==nil{exec.Command(program,"--error","--title=Solcord","--text="+message).Run()};os.Exit(1)}}
