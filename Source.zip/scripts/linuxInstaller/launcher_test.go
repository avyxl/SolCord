//go:build linux
package main
import("os";"path/filepath";"testing";"encoding/json";"os/exec";"strconv";"strings")
func TestHealth(t *testing.T){d:=t.TempDir();os.MkdirAll(filepath.Join(d,"app"),0755);os.WriteFile(filepath.Join(d,"_app.asar"),[]byte("fixture"),0644);os.WriteFile(filepath.Join(d,"app/.solcord-loader.json"),[]byte("SOLCORD-LINUX-LOADER:1"),0644);if !healthy(d){t.Fatal("loader not detected")};os.WriteFile(filepath.Join(d,"app.asar"),[]byte("host update"),0644);if healthy(d){t.Fatal("new host needs repair")}}
func TestState(t *testing.T){p:=filepath.Join(t.TempDir(),"state");os.WriteFile(p,[]byte("{bad"),0644);if _,e:=load(p);e==nil{t.Fatal("malformed state accepted")};os.WriteFile(p,[]byte("{\"schema\":2}"),0644);if _,e:=load(p);e==nil{t.Fatal("wrong schema accepted")}}
func TestExecReplacement(t *testing.T){
 if os.Getenv("SOLCORD_LAUNCH_TEST")=="1"{if err:=run([]string{"--fixture-argument"});err!=nil{panic(err)};return}
 base:=t.TempDir();data:=filepath.Join(base,"data");resource:=filepath.Join(base,"Discord/resources");os.MkdirAll(filepath.Join(resource,"app"),0755);os.MkdirAll(filepath.Join(data,"Solcord/linux"),0755);os.WriteFile(filepath.Join(resource,"_app.asar"),[]byte("fixture"),0644);os.WriteFile(filepath.Join(resource,"app/.solcord-loader.json"),[]byte("SOLCORD-LINUX-LOADER:1"),0644)
 host:=filepath.Join(base,"host");os.WriteFile(host,[]byte("#!/bin/sh\nprintf '%s|%s|%s' \"$$\" \"$SOLCORD_USER_DATA_DIR\" \"$1\"\n"),0755)
 state:=record{Schema:1,Config:filepath.Join(base,"config"),DefaultChannel:"stable",Installations:[]installation{{Resources:resource,Channel:"stable",Command:[]string{host}}}};b,_:=json.Marshal(state);os.WriteFile(filepath.Join(data,"Solcord/linux/installed.json"),b,0644)
 command:=exec.Command(os.Args[0],"-test.run=TestExecReplacement");command.Env=append(os.Environ(),"SOLCORD_LAUNCH_TEST=1","HOME="+base,"XDG_DATA_HOME="+data);var output strings.Builder;command.Stdout=&output;command.Stderr=os.Stderr;if err:=command.Start();err!=nil{t.Fatal(err)};pid:=command.Process.Pid;if err:=command.Wait();err!=nil{t.Fatal(err)};want:=strconv.Itoa(pid)+"|"+state.Config+"|--fixture-argument";if output.String()!=want{t.Fatalf("process replacement/args/config: %q != %q",output.String(),want)}
}
