/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

// Disposable Linux runner only. No Discord login, account data or remote page is used.
import assert from "node:assert/strict";
import { execFileSync } from "node:child_process";
import { mkdir, readFile, rename, rm, writeFile } from "node:fs/promises";
import { createRequire } from "node:module";
import { join, resolve } from "node:path";
const require=createRequire(import.meta.url),asar=require("@electron/asar"),temp=process.env.RUNNER_TEMP;
if(process.platform!=="linux"||!temp)throw new Error("Use a disposable Linux runner with RUNNER_TEMP.");
const release=resolve(process.argv[2]),electron=require("electron"),runtime=resolve(electron,".."),resources=join(runtime,"resources");
await rename(electron,join(runtime,"Discord"));
const source=join(temp,"solcord-fixture-app");await mkdir(source,{recursive:true});
await writeFile(join(source,"package.json"),JSON.stringify({name:"discord",version:"1.0.0",main:"index.js"}));
await writeFile(join(source,"preload.js"),"require('fs').writeFileSync(process.env.SOLCORD_SMOKE_PRELOAD,JSON.stringify({originalExecuted:true,originalPreload:process.env.DISCORD_PRELOAD||null}));\n");
await writeFile(join(source,"index.js"),[
"const {app,BrowserWindow}=require('electron');const fs=require('fs'),path=require('path');",
"app.whenReady().then(async()=>{",
"const options={show:false,webPreferences:{sandbox:false,preload:path.join(__dirname,'preload.js')}};const win=new BrowserWindow(options);",
"await win.loadURL('about:blank');",
"fs.writeFileSync(process.env.SOLCORD_SMOKE_RESULT,JSON.stringify({platform:process.platform,preload:options.webPreferences.preload,appPath:app.getAppPath(),nativeLoaded:Object.keys(require.cache).some(file=>file===path.join(process.env.SOLCORD_USER_DATA_DIR||'', 'dist','patcher.js'))}));",
"win.destroy();app.exit(0);}).catch(error=>{console.error(error);app.exit(1);});"
].join("\n"));
await asar.createPackage(source,join(resources,"app.asar"));
const resultPath=join(temp,"solcord-native-smoke.json"),preloadResult=join(temp,"solcord-preload-smoke.json");
const env={...process.env,XDG_CONFIG_HOME:join(temp,"solcord-smoke-config"),XDG_DATA_HOME:join(temp,"solcord-smoke-data"),SOLCORD_SMOKE_RESULT:resultPath,SOLCORD_SMOKE_PRELOAD:preloadResult};
const native=process.argv[3];
const manager=native||"python3", prefix=native?[]:[join(release,"solcord_linux.py")];
execFileSync(manager,[...prefix,"install","--path",runtime],{env,stdio:"inherit"});
execFileSync("timeout",["45","xvfb-run","-a",join(process.env.HOME,".local/bin/solcord"),"--no-sandbox","--disable-gpu"],{env,stdio:"inherit"});
const result=JSON.parse(await readFile(resultPath,"utf8"));console.log("Patched native boot:",result);
assert.equal(result.platform,"linux");assert.equal(result.nativeLoaded,true);assert.equal(result.preload,join(env.XDG_CONFIG_HOME,"Solcord/dist/preload.js"));assert.equal(result.appPath,join(resources,"_app.asar"));
const executed=JSON.parse(await readFile(preloadResult,"utf8"));assert.equal(executed.originalExecuted,true);assert.equal(executed.originalPreload,join(resources,"_app.asar/preload.js"));
await rm(preloadResult);
execFileSync(manager,[...prefix,"uninstall","--path",runtime],{env,stdio:"inherit"});
execFileSync("timeout",["45","xvfb-run","-a",join(runtime,"Discord"),"--no-sandbox","--disable-gpu"],{env,stdio:"inherit"});
const vanilla=JSON.parse(await readFile(resultPath,"utf8"));console.log("Restored vanilla boot:",vanilla);
assert.equal(vanilla.nativeLoaded,false);assert.equal(vanilla.appPath,join(resources,"app.asar"));assert.equal(vanilla.preload,join(resources,"app.asar/preload.js"));
const original=JSON.parse(await readFile(preloadResult,"utf8"));assert.equal(original.originalExecuted,true);assert.equal(original.originalPreload,null);
console.log("Native Linux Electron: installed loader, actual main-process patcher, BrowserWindow/preload replacement, actual preload execution, original ASAR boot, uninstall and vanilla boot passed. No live Discord account was used.");
