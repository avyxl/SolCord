/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { createHash } from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { join } from "node:path";

const root = join(import.meta.dirname, "..");
const pkg = JSON.parse(readFileSync(join(root, "package.json"), "utf8"));
const gui = readFileSync(join(root, "installer/InstallerGUI.cs"), "utf8");
if (!gui.includes(`AssemblyInformationalVersion("${pkg.version}")`))
    throw new Error("Installer source version and package version differ.");
function describe(relative, name) {
    const bytes = readFileSync(join(root, relative));
    return { name, sizeBytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex") };
}
const manifest = {
    manifestType: "solcord-local-build",
    name: "Solcord",
    version: pkg.version,
    repository: "https://github.com/avyxl/SolCord",
    distribution: "local",
    published: false,
    automaticUpdates: /Updater Disabled: false/.test(readFileSync(join(root, "dist/patcher.js"), "utf8")),
    updatePolicy: "signed-releases-only",
    installer: describe("SolcordInstaller.exe", "SolcordInstaller.exe"),
    embeddedPayloads: ["patcher.js", "preload.js", "renderer.js", "renderer.css"].map(name => describe(`dist/${name}`, name))
};
// This is local build information, not a signed online update feed.
writeFileSync(join(root, "version.json"), `${JSON.stringify(manifest, null, 2)}\n`);
console.log(`Local build metadata written for Solcord ${pkg.version}.`);
