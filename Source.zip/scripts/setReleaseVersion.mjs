/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { readFileSync, writeFileSync } from "node:fs";
import { resolve } from "node:path";
import { fileURLToPath } from "node:url";
const root=resolve(fileURLToPath(new URL("..",import.meta.url))),version=process.argv[2];
if(!/^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-[A-Za-z0-9.-]+)?$/.test(version??""))throw Error("Use a version such as 3.0.1 or 3.1.0-beta.1.");
const packageFile=resolve(root,"package.json"),pkg=JSON.parse(readFileSync(packageFile,"utf8")),assemblyFile=resolve(root,"installer/InstallerGUI.cs");
let assembly=readFileSync(assemblyFile,"utf8");const numeric=version.split("-")[0];
if(numeric.split(".").some(n=>Number(n)>65534))throw Error("Windows version parts must be below 65535.");
assembly=assembly.replace(/(AssemblyVersion|AssemblyFileVersion)\("[\d.]+"\)/g,'$1("'+numeric+'.0")').replace(/AssemblyInformationalVersion\("[^"]+"\)/,'AssemblyInformationalVersion("'+version+'")');
pkg.version=version;writeFileSync(packageFile,JSON.stringify(pkg,null,4)+"\n");writeFileSync(assemblyFile,assembly);
console.log("Release version set to "+version);
