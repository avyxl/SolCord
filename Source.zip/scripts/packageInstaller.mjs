/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { join, resolve } from "node:path";

import { strToU8, unzipSync, zipSync } from "fflate";

const root=resolve(import.meta.dirname,".."),output=resolve(root,"../../outputs");
const pkg=JSON.parse(await readFile(join(root,"package.json"),"utf8")),manifest=JSON.parse(await readFile(join(root,"version.json"),"utf8"));
assert.equal(manifest.version,pkg.version);assert.equal(manifest.manifestType,"solcord-local-build");assert.equal(manifest.published,false);assert.equal(manifest.automaticUpdates,true);
const status = await readFile(join(root, "docs/SOLCORD-3.0-STATUS.md"), "utf8");
const counts = /^Implemented: (\d+) · In progress: (\d+) · Already covered: (\d+) · Planned: (\d+)$/m.exec(status)?.slice(1).map(Number);
if (!counts || counts.reduce((sum, value) => sum + value, 0) !== 200) throw new Error("Generate the current feature status before packaging.");
const exe=new Uint8Array(await readFile(join(root,"SolcordInstaller.exe"))),sha=bytes=>createHash("sha256").update(bytes).digest("hex");
assert.equal(sha(exe),manifest.installer.sha256);assert.equal(exe.length,manifest.installer.sizeBytes);
for(const asset of manifest.embeddedPayloads)assert.equal(sha(await readFile(join(root,"dist",asset.name))),asset.sha256);
const manager=new Uint8Array(await readFile(join(root,"SolcordPublisher.exe")));
const source=unzipSync(await readFile(join(output,`Solcord-${pkg.version}-source.zip`))),prefix=`Solcord-${pkg.version}/`,files={ "SolcordInstaller.exe":exe,"SolcordPublisher.exe":manager,"build-info.json":strToU8(`${JSON.stringify(manifest,null,2)}\n`) };
for(const [name,bytes] of Object.entries(source)){ if(!name.startsWith(prefix))throw Error("Unexpected source archive root");files[`Source/Solcord/${name.slice(prefix.length)}`]=bytes; }
files["Source/Solcord/version.json"]=files["build-info.json"];
files["SHA256SUMS.txt"]=strToU8(`${manifest.installer.sha256}  SolcordInstaller.exe\n${sha(manager)}  SolcordPublisher.exe\n`);
files["PUBLISHING-UPDATES.md"]=new Uint8Array(await readFile(join(root,"docs/PUBLISHING-UPDATES.md")));
files["CHANGELOG.md"]=new Uint8Array(await readFile(join(root,"CHANGELOG.md")));
files["FEATURE-STATUS.md"]=new Uint8Array(await readFile(join(root,"docs/SOLCORD-3.0-STATUS.md")));
files.LICENSE=new Uint8Array(await readFile(join(root,"LICENSE")));
files["THIRD_PARTY_NOTICES.md"]=new Uint8Array(await readFile(join(root,"THIRD_PARTY_NOTICES.md")));
files["README.txt"]=strToU8(`Solcord ${pkg.version} - Windows installer

Extract this ZIP, run SolcordInstaller.exe, choose your Discord installation and use Install/Update. Restart Discord afterwards. Windows 10/11 with .NET Framework 4.8 is required. No Node.js or build tools are needed to install.

Solcord 3.0.3 adds 16 plugin-library and updater improvements, native Linux setup and a new Windows publisher. Existing desktop plugins and profile/badge formats are retained. Favorites, recent plugins, intent search, saved sorting and bounded pages make the full library easier to browse. See CHANGELOG.md.

Enable SolcordBot in Settings > Solcord > Plugins. Open its settings and redeem the activation key supplied separately. Type ,sol help. Purge only your own messages with ,sol purge 50 or ,sol purge all; a read-only scan and typed DELETE confirmation come first. Use ,sol stop and ,sol status. Replies stay local.

Existing proposal inventory: ${counts[0]} implemented additions, ${counts[1]} partial, ${counts[2]} covered, ${counts[3]} planned. Planned rows are not installed plugins. See FEATURE-STATUS.md.

The signed Solcord updater and your public update key remain included. No online update was published while packaging this download. For owner publishing, open SolcordPublisher.exe, choose the complete installer ZIP, use Check update, then Publish update. Follow PUBLISHING-UPDATES.md. No Node.js or rebuild is needed in the publisher. Private signing keys and the original SolcordBot activation code are not included in this public archive.

Validation: all packed plugin chunks parse and their imports resolve; TypeScript passed; SolcordBot, plugin-library and updater tests use explicit Discord adapters. The installer compiled for Windows and all ten self-test groups passed. Live Discord purges and real hardware integration have not been tested.

Source/Solcord contains corresponding source and rebuild instructions. Original license notices and the Sora/Manrope font licenses are preserved.
`);
await mkdir(output,{ recursive:true });const target=join(output,`SolcordInstaller-${pkg.version}.zip`),bytes=zipSync(files,{ level:6 });await writeFile(target,bytes);
console.log(JSON.stringify({ target,bytes:bytes.length,sha256:sha(bytes),installerSha256:manifest.installer.sha256,files:Object.keys(files).length }));
