/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

// Cross-compiles the existing Windows WPF installer without changing its UI or installation engine.
// Requires an installed Microsoft .NET SDK and Microsoft's net48 reference-assembly package.
// This command does not run Windows GUI/CNG self-tests. Run SolcordInstaller.exe --self-test on Windows.
import { spawnSync } from "node:child_process";
import { createHash } from "node:crypto";
import { copyFile, mkdir, readdir, readFile, realpath, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";

const root = resolve(import.meta.dirname, ".."), args = process.argv.slice(2);
function option(name) { const at = args.indexOf(name); if (at < 0 || !args[at + 1]) throw new Error(`Specify ${name} PATH. See docs/BUILD-WINDOWS-INSTALLER.md.`); return resolve(args[at + 1]); }
const dotnet = await realpath(option("--dotnet")), references = option("--references");
const sdks = (await readdir(join(dirname(dotnet), "sdk"))).filter(name => /^\d+\.\d+\.\d+$/.test(name)).sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));
if (!sdks.length) throw new Error("No .NET SDK compiler was found beside the dotnet host.");
const compiler = join(dirname(dotnet), "sdk", sdks.at(-1), "Roslyn/bincore/csc.dll");
const pkg = JSON.parse(await readFile(join(root, "package.json"), "utf8")), gui = await readFile(join(root, "installer/InstallerGUI.cs"), "utf8");
if (!gui.includes(`AssemblyInformationalVersion("${pkg.version}")`)) throw new Error("Installer/package versions differ.");
const numericVersion = `${pkg.version.split(/[+-]/)[0]}.0`;
if (!(await readFile(join(root, "installer/app.manifest"), "utf8")).includes(`version="${numericVersion}" name="SolcordInstaller"`)) throw new Error("Installer manifest version differs.");
const payload = ["patcher.js", "preload.js", "renderer.js", "renderer.css"], hashes = [];
for (const name of payload) {
    const bytes = await readFile(join(root, "dist", name)); if (!bytes.length) throw new Error(`Empty payload: ${name}`);
    if (name === "patcher.js" && !bytes.subarray(0, 300).toString().includes(`// Version: ${pkg.version}\n`)) throw new Error("Build the current client before compiling the installer.");
    hashes.push(`${createHash("sha256").update(bytes).digest("hex")}  ${name}`);
}
await writeFile(join(root, "dist/payload.sha256"), `${hashes.join("\n")}\n`);
const sources = [];
async function walk(dir) { for (const entry of await readdir(dir, { withFileTypes: true })) { const path = join(dir, entry.name); if (entry.isDirectory()) await walk(path); else if (entry.name.endsWith(".cs")) sources.push(path); } }
await walk(join(root, "installer"));
const output = join(root, "SolcordInstaller.exe");
const libs = ["mscorlib", "System", "System.Core", "System.IO.Compression", "System.Drawing", "System.Windows.Forms", "System.Web.Extensions", "System.Xaml", "WindowsBase", "PresentationCore", "PresentationFramework"];
const compile = spawnSync(dotnet, [compiler, "/nologo", "/noconfig", "/nostdlib+", "/target:winexe", "/platform:anycpu", "/optimize+", "/deterministic+", "/utf8output", `/pathmap:${root}=/Solcord`, `/out:${output}`, `/win32icon:${join(root, "assets/app_icon.ico")}`, `/win32manifest:${join(root, "installer/app.manifest")}`,
    ...libs.map(name => `/reference:${join(references, `${name}.dll`)}`), ...payload.map(name => `/resource:${join(root, "dist", name)},${name}`), `/resource:${join(root, "dist/payload.sha256")},payload.sha256`, `/resource:${join(root, "assets/app_logo.png")},app_logo.png`, ...sources.sort()], { cwd: root, stdio: "inherit", env: { ...process.env, DOTNET_CLI_TELEMETRY_OPTOUT: "1", DOTNET_SKIP_FIRST_TIME_EXPERIENCE: "1" } });
if (compile.status !== 0) throw new Error(`Windows installer compilation failed (${compile.status}).`);
const describe = async (path, name) => { const bytes = await readFile(path); return { name, sizeBytes: bytes.length, sha256: createHash("sha256").update(bytes).digest("hex") }; };
const manifest = { manifestType: "solcord-local-build", name: "Solcord", version: pkg.version, repository: "https://github.com/avyxl/SolCord", distribution: "local", published: false, automaticUpdates: false, installer: await describe(output, "SolcordInstaller.exe"), embeddedPayloads: await Promise.all(payload.map(name => describe(join(root, "dist", name), name))) };
await writeFile(join(root, "version.json"), `${JSON.stringify(manifest, null, 2)}\n`);
await mkdir(join(root, "dist/Installer"), { recursive: true }); await copyFile(output, join(root, "dist/Installer/SolcordInstaller.exe"));
console.log(JSON.stringify({ ...manifest.installer, version: pkg.version, target: "Windows .NET Framework 4.8 / WPF", windowsSelfTests: "not run on this host" }));
