/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { execFileSync } from "node:child_process";
import { createHash, createPrivateKey, createPublicKey, sign, verify } from "node:crypto";
import { copyFileSync, existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { join, resolve } from "node:path";
export const WINDOWS_FILES = ["patcher.js", "preload.js", "renderer.js", "renderer.css"];
export const sha256 = file => createHash("sha256").update(readFileSync(file)).digest("hex");
export function checkedSigningKey(privatePem, publicPem) {
    const key = createPrivateKey(privatePem), trusted = createPublicKey(publicPem);
    if (key.asymmetricKeyType !== "ec" || key.asymmetricKeyDetails?.namedCurve !== "prime256v1") throw Error("Use the Solcord P-256 update key.");
    if (!createPublicKey(key).export({format:"der",type:"spki"}).equals(trusted.export({format:"der",type:"spki"}))) throw Error("The private key does not match this build's public update key. Nothing was published.");
    return key;
}
export const signaturePayload = manifest => Buffer.from([manifest.version,manifest.hash,manifest.updatedAt,manifest.installerSha256,...manifest.assets.map(asset=>asset.name+" "+asset.sha256).sort()].join("\n"));
export function windowsManifest({ version, hash, updatedAt, files, installer, commit, repository = "avyxl/SolCord" }, key) {
    if (!/^\d+\.\d+\.\d+(?:-[\w.-]+)?$/.test(version) || !/^[\w.-]{1,64}$/.test(hash) || !Number.isSafeInteger(updatedAt) || updatedAt <= 0 || !/^[a-f0-9]{40}$/.test(commit)) throw Error("Invalid release identity.");
    if (files.length !== WINDOWS_FILES.length || new Set(files.map(file=>file.name)).size !== WINDOWS_FILES.length || files.some(file=>!WINDOWS_FILES.includes(file.name))) throw Error("A Windows release needs exactly its four payload files.");
    const manifest = { version, hash, updatedAt, installerSha256:sha256(installer), downloadUrl:"https://raw.githubusercontent.com/"+repository+"/"+commit+"/SolcordInstaller.exe", assets:files.map(file=>({name:file.name,url:"https://raw.githubusercontent.com/"+repository+"/"+commit+"/dist/"+file.name,sha256:sha256(file.path)})) };
    manifest.signature = sign("sha256",signaturePayload(manifest),key).toString("base64");
    if (!verify("sha256",signaturePayload(manifest),createPublicKey(key),Buffer.from(manifest.signature,"base64"))) throw Error("Release signature self-check failed.");
    return manifest;
}
/** A staging repository is separate from source, so publishing never switches or overwrites the source checkout. */
export function stageWindowsRelease({ directory, remote, version, hash, updatedAt, files, installer, key, publish = false }) {
    const git = (...args) => execFileSync("git",args,{cwd:directory,encoding:"utf8",stdio:["ignore","pipe","pipe"]}).trim();
    mkdirSync(directory,{recursive:true});
    if (existsSync(join(directory,".git"))) throw Error("Choose a fresh publication staging folder.");
    git("init","--initial-branch=updates");
    git("config","user.name","avyxl"); git("config","user.email","avyxl@users.noreply.github.com");
    if (remote) {
        git("remote","add","origin",remote);
        const branch = git("ls-remote","--heads","origin","refs/heads/updates");
        if (branch) { git("fetch","--depth=1","origin","updates"); git("checkout","-B","updates","FETCH_HEAD"); }
    }
    mkdirSync(join(directory,"dist"),{recursive:true});
    for(const file of files) copyFileSync(file.path,join(directory,"dist",file.name));
    copyFileSync(installer,join(directory,"SolcordInstaller.exe"));
    git("add","--","dist","SolcordInstaller.exe");
    git("commit","--allow-empty","-m","Solcord "+version+" payload "+hash);
    const commit = git("rev-parse","HEAD");
    const stagedFiles = WINDOWS_FILES.map(name=>({name,path:join(directory,"dist",name)}));
    const manifest = windowsManifest({version,hash,updatedAt,files:stagedFiles,installer:join(directory,"SolcordInstaller.exe"),commit},key);
    writeFileSync(join(directory,"version.json"),JSON.stringify(manifest,null,4)+"\n");
    writeFileSync(join(directory,"README.md"),"# Solcord updates\n\nSigned Windows client updates published by avyxl. Payload URLs name their immutable Git commit. Source: https://github.com/avyxl/SolCord\n");
    git("add","--","version.json","README.md"); git("commit","-m","Publish signed Solcord "+version);
    if(publish){ if(!remote)throw Error("No publication remote configured."); git("push","origin","HEAD:refs/heads/updates"); }
    return { directory:resolve(directory), manifest, published:publish, commit:git("rev-parse","HEAD") };
}
