/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { execFileSync } from "node:child_process";
import { randomBytes } from "node:crypto";
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { homedir } from "node:os";
import { dirname, join, resolve, relative, isAbsolute } from "node:path";
import { fileURLToPath } from "node:url";
import { checkedSigningKey, stageWindowsRelease, WINDOWS_FILES } from "./updatePublisher.mjs";
const root=resolve(fileURLToPath(new URL("..",import.meta.url))),args=process.argv.slice(2);
const publish=args.includes("--publish"), versionAt=args.indexOf("--version"),version=versionAt<0?JSON.parse(readFileSync(join(root,"package.json"),"utf8")).version:args[versionAt+1];
const keyFile=process.env.SOLCORD_UPDATE_KEY??join(homedir(),".solcord/update-signing-key.pem");
const keyRelative=relative(root,resolve(keyFile));
if(!keyRelative.startsWith("..") && !isAbsolute(keyRelative)) throw Error("Keep the private signing key outside the source project, such as in your user profile's .solcord folder.");
// The key never enters the publication folder, process arguments, console output or repository.
const key=checkedSigningKey(readFileSync(keyFile),readFileSync(join(root,"src/main/updater/updateKey.pem")));
const hash=randomBytes(8).toString("hex"),updatedAt=Date.now(),env={...process.env,SOLCORD_HASH:hash,SOURCE_DATE_EPOCH:String(updatedAt)};
const run=(program,options)=>execFileSync(program,options,{cwd:root,env,stdio:"inherit"});
if(versionAt>=0)run(process.execPath,["scripts/setReleaseVersion.mjs",version]);
if(process.platform!=="win32")throw Error("This publisher builds the Windows installer. Run it on Windows.");
if(!existsSync(join(root,"node_modules/esbuild"))) {
    console.log("Installing the pinned build dependencies (first run)...");
    run(process.execPath,[join(dirname(process.execPath),"node_modules/npm/bin/npm-cli.js"),"exec","--yes","--package=pnpm@11.9.0","--","pnpm","install","--frozen-lockfile","--ignore-scripts"]);
}
run(process.execPath,["--require=./scripts/suppressExperimentalWarnings.js","scripts/build/build.mjs","--standalone"]);
run(process.execPath,["node_modules/typescript/bin/tsc","--noEmit"]);
run(process.execPath,["test/chunks-dynamic.mjs"]);run(process.execPath,["test/chunks.mjs"]);run(process.execPath,["test/updater-release.mjs"]);
run("powershell.exe",["-NoProfile","-ExecutionPolicy","Bypass","-File",join(root,"scripts/buildInstaller.ps1")]);
mkdirSync(join(root,"dist/releases"),{recursive:true});
const result=stageWindowsRelease({directory:join(root,"dist/releases",version+"-"+hash),remote:publish?"https://github.com/avyxl/SolCord.git":undefined,version,hash,updatedAt,files:WINDOWS_FILES.map(name=>({name,path:join(root,"dist",name)})),installer:join(root,"SolcordInstaller.exe"),key,publish});
console.log(publish?"Published signed Solcord "+version+". Installations will find it during their update checks.":"Prepared and signed Solcord "+version+" locally. Nothing was uploaded. Review "+result.directory);
