using System;
using System.Collections.Generic;
using System.Globalization;

namespace SolcordInstaller.Localization
{
    public sealed class LanguageOption
    {
        public string Code { get; private set; }
        public string NativeName { get; private set; }
        public string Subtitle { get; private set; }
        public string ShortBadge { get; private set; }

        public LanguageOption(string code, string nativeName, string subtitle, string shortBadge)
        {
            Code = code;
            NativeName = nativeName;
            Subtitle = subtitle;
            ShortBadge = shortBadge;
        }
    }

    public static class Loc
    {
        public static readonly LanguageOption[] SupportedLanguages =
        {
            new LanguageOption("en", "English", "United States / International", "EN"),
            new LanguageOption("tr", "Türkçe", "Türkiye", "TR"),
            new LanguageOption("ru", "Русский", "Россия / СНГ", "RU"),
            new LanguageOption("es", "Español", "España / Latinoamérica", "ES"),
            new LanguageOption("fr", "Français", "France / International", "FR")
        };

        static readonly Dictionary<string, Dictionary<string, string>> Tables = BuildTables();
        static string _current = "en";

        public static event Action LanguageChanged;

        public static string CurrentLanguage
        {
            get { return _current; }
        }

        public static LanguageOption CurrentOption
        {
            get
            {
                foreach (var l in SupportedLanguages)
                    if (l.Code == _current) return l;
                return SupportedLanguages[0];
            }
        }

        public static void SetLanguage(string code)
        {
            string norm = NormalizeCode(code);
            if (!Tables.ContainsKey(norm)) norm = "en";
            if (_current == norm) return;
            _current = norm;
            var h = LanguageChanged;
            if (h != null) h();
        }

        public static void Initialize(string savedLanguage)
        {
            if (!string.IsNullOrEmpty(savedLanguage) && Tables.ContainsKey(NormalizeCode(savedLanguage)))
            {
                _current = NormalizeCode(savedLanguage);
                return;
            }
            _current = "en";
        }

        static string NormalizeCode(string code)
        {
            if (string.IsNullOrEmpty(code)) return "en";
            code = code.Trim().ToLowerInvariant();
            if (code.Length >= 2) code = code.Substring(0, 2);
            return code;
        }

        public static string T(string key)
        {
            if (string.IsNullOrEmpty(key)) return "";
            Dictionary<string, string> langMap;
            string val;
            if (Tables.TryGetValue(_current, out langMap) && langMap.TryGetValue(key, out val) && !string.IsNullOrEmpty(val))
                return val;
            if (Tables["en"].TryGetValue(key, out val))
                return val;
            return key;
        }

        public static string F(string key, params object[] args)
        {
            string fmt = T(key);
            if (args == null || args.Length == 0) return fmt;
            try
            {
                return string.Format(CultureInfo.InvariantCulture, fmt, args);
            }
            catch
            {
                return fmt;
            }
        }

        public static List<string> FindMissingTranslations()
        {
            var missing = new List<string>();
            var enKeys = Tables["en"].Keys;
            foreach (var lang in SupportedLanguages)
            {
                var table = Tables[lang.Code];
                foreach (var k in enKeys)
                {
                    string v;
                    if (!table.TryGetValue(k, out v) || string.IsNullOrEmpty(v))
                        missing.Add(lang.Code + ":" + k);
                }
            }
            return missing;
        }

        delegate void AddEntryDelegate(string key, string vEn, string vTr, string vRu, string vEs, string vFr);

        static Dictionary<string, Dictionary<string, string>> BuildTables()
        {
            var root = new Dictionary<string, Dictionary<string, string>>(StringComparer.OrdinalIgnoreCase);

            var en = new Dictionary<string, string>(StringComparer.Ordinal);
            var tr = new Dictionary<string, string>(StringComparer.Ordinal);
            var ru = new Dictionary<string, string>(StringComparer.Ordinal);
            var es = new Dictionary<string, string>(StringComparer.Ordinal);
            var fr = new Dictionary<string, string>(StringComparer.Ordinal);

            AddEntryDelegate Add = (key, vEn, vTr, vRu, vEs, vFr) =>
            {
                en[key] = vEn;
                tr[key] = vTr;
                ru[key] = vRu;
                es[key] = vEs;
                fr[key] = vFr;
            };

            // Intro and language screen
            Add("app.title",
                "Solcord Installer",
                "Solcord Kurulumu",
                "Установщик Solcord",
                "Instalador de Solcord",
                "Installateur Solcord");

            Add("app.subtitle",
                "A lightweight, friendly Discord mod",
                "Hafif ve sevimli bir Discord modu",
                "Лёгкий и дружелюбный мод для Discord",
                "Un mod de Discord ligero y amigable",
                "Un mod Discord léger et sympa");

            Add("lang.welcome",
                "Hey, welcome!",
                "Selam, hoş geldin!",
                "Привет, добро пожаловать!",
                "¡Hola, bienvenido!",
                "Coucou, bienvenue !");

            Add("lang.choosePrompt",
                "Pick a language to get started",
                "Başlamak için bir dil seç",
                "Выберите язык, чтобы начать",
                "Elige un idioma para empezar",
                "Choisissez une langue pour commencer");

            Add("lang.btn.continue",
                "Let's go",
                "Hadi başlayalım",
                "Поехали",
                "¡Vamos!",
                "C'est parti");

            // Migration screen
            Add("mig.welcomeTitle",
                "Oh, a familiar face!",
                "Aa, tanıdık bir yüz!",
                "О, знакомое лицо!",
                "¡Oh, una cara conocida!",
                "Oh, une tête connue !");

            Add("mig.switchedShort",
                "Looks like you’ve switched from {0}.",
                "Görünüşe göre {0} istemcisinden geçtiniz.",
                "Похоже, вы перешли с {0}.",
                "Parece que te has cambiado desde {0}.",
                "Il semble que vous veniez de {0}.");

            Add("mig.banner.prompt",
                "You came over from {0}. Want Solcord to bring your settings along?",
                "{0} kullanıyormuşsun. Solcord ayarlarını da beraberinde getirsin mi?",
                "Вы пришли с {0}. Перенести ваши настройки в Solcord?",
                "Vienes de {0}. ¿Quieres que Solcord traiga tus ajustes contigo?",
                "Vous venez de {0}. Solcord peut emporter vos paramètres, ça vous dit ?");

            Add("mig.card.title",
                "Pack your settings?",
                "Ayarlar bavula girsin mi?",
                "Собрать настройки в дорогу?",
                "¿Empacamos tus ajustes?",
                "On fait vos valises ?");

            Add("mig.card.body",
                "Your previous settings were found. You can import compatible preferences and plugin configurations into Solcord.",
                "Önceki ayarların bulundu. Uyumlu tercihlerini, temalarını ve eklenti yapılandırmalarını Solcord'a aktarabilirsin.",
                "Найдены ваши предыдущие настройки. Вы можете импортировать совместимые параметры и конфигурации плагинов в Solcord.",
                "Se encontraron tus ajustes anteriores. Puedes importar las preferencias compatibles y configuraciones de plugins en Solcord.",
                "Vos anciens paramètres ont été trouvés. Vous pouvez importer vos préférences et configurations de plugins compatibles dans Solcord.");

            Add("mig.card.stats",
                "{0} plugins and {1} themes can come along. A backup is made first, just in case.",
                "{0} eklenti ve {1} tema seninle gelebilir. Her ihtimale karşı önce yedek alınır.",
                "С вами переедут плагины ({0}) и темы ({1}). Сначала сделаем бэкап, на всякий случай.",
                "Pueden venir {0} plugins y {1} temas. Antes hacemos una copia, por si acaso.",
                "{0} plugins et {1} thèmes peuvent suivre. Une sauvegarde est faite avant, au cas où.");

            Add("mig.card.inspectLink",
                "Peek inside ({0} coming, {1} staying behind)",
                "İçine göz at ({0} geliyor, {1} kalıyor)",
                "Заглянуть внутрь ({0} переедут, {1} останутся)",
                "Echar un vistazo ({0} vienen, {1} se quedan)",
                "Jeter un œil ({0} suivent, {1} restent)");

            Add("mig.card.hideInspect",
                "Close the suitcase",
                "Bavulu kapat",
                "Закрыть чемодан",
                "Cerrar la maleta",
                "Fermer la valise");

            Add("mig.btn.importSettings",
                "Bring them along",
                "Getir gelsin",
                "Перенести",
                "Tráelos",
                "On les emmène");

            Add("mig.btn.startFresh",
                "Start fresh",
                "Sıfırdan başla",
                "Начать с нуля",
                "Empezar de cero",
                "Repartir à zéro");

            // Client choice and install mode
            Add("main.title",
                "Choose a Discord client",
                "Bir Discord istemcisi seçin",
                "Выберите клиент Discord",
                "Elige un cliente de Discord",
                "Choisissez un client Discord");

            Add("main.subtitle",
                "Select where to install, update or repair Solcord.",
                "Solcord kurulacak, güncellenecek veya onarılacak konumu seçin.",
                "Выберите, где установить, обновить или восстановить Solcord.",
                "Selecciona dónde instalar, actualizar o reparar Solcord.",
                "Choisissez où installer, mettre à jour ou réparer Solcord.");

            // Under the install list and on Solcord Desktop's setup: what goes over the network (solcord.com/code-signing-policy)
            Add("privacy.note",
                "Settings and backups stay on this PC. Enabled online features use their configured services.",
                "Ayarlar ve yedekler bu bilgisayarda kalır. Açık çevrimiçi özellikler yapılandırılmış hizmetlerini kullanır.",
                "Настройки и резервные копии остаются на этом ПК. Онлайн-функции используют настроенные сервисы.",
                "Los ajustes y las copias se guardan en este PC. Las funciones en línea usan sus servicios configurados.",
                "Les réglages et sauvegardes restent sur ce PC. Les fonctions en ligne utilisent leurs services configurés.");

            Add("tab.install",
                "Install",
                "Kurulum",
                "Установка",
                "Instalar",
                "Installer");

            Add("tab.repair",
                "Repair",
                "Onar",
                "Починка",
                "Reparar",
                "Réparer");

            Add("tab.uninstall",
                "Uninstall",
                "Kaldır",
                "Удалить",
                "Desinstalar",
                "Désinstaller");

            Add("tab.backups",
                "Backups",
                "Yedekler",
                "Бэкапы",
                "Copias",
                "Sauvegardes");

            Add("btn.addCustomPath",
                "+ Custom Path",
                "+ Özel Konum",
                "+ Свой путь",
                "+ Otra ruta",
                "+ Autre chemin");

            Add("btn.refresh",
                "Refresh",
                "Yenile",
                "Обновить",
                "Actualizar",
                "Actualiser");

            Add("chk.relaunch",
                "Open Discord again when done",
                "Bitince Discord'u tekrar aç",
                "Открыть Discord после завершения",
                "Abrir Discord al terminar",
                "Rouvrir Discord à la fin");

            Add("action.install",
                "Install Solcord",
                "Solcord'u Kur",
                "Установить Solcord",
                "Instalar Solcord",
                "Installer Solcord");

            Add("action.update",
                "Update Solcord",
                "Solcord'u Güncelle",
                "Обновить Solcord",
                "Actualizar Solcord",
                "Mettre à jour Solcord");

            Add("action.repair",
                "Repair Solcord",
                "Kurulumu Onar",
                "Восстановить Solcord",
                "Reparar Solcord",
                "Réparer Solcord");

            Add("action.uninstall",
                "Uninstall Solcord",
                "Solcord'u Kaldır",
                "Удалить Solcord",
                "Desinstalar Solcord",
                "Désinstaller Solcord");

            Add("action.cancel",
                "Cancel",
                "İptal Et",
                "Отмена",
                "Cancelar",
                "Annuler");

            // Badges and card states
            Add("card.running", "Running", "Çalışıyor", "Запущен", "Abierto", "En cours");
            Add("card.closed", "Closed", "Kapalı", "Закрыт", "Cerrado", "Fermé");
            Add("card.status.solcord",
                "Has Solcord",
                "Solcord'lu",
                "С Solcord",
                "Con Solcord",
                "Avec Solcord");
            Add("card.status.vanilla",
                "Ready",
                "Hazır",
                "Готов",
                "Listo",
                "Prêt");
            Add("card.status.conflict", "{0}", "{0}", "{0}", "{0}", "{0}");
            Add("card.status.damaged",
                "Needs a fix",
                "Onarım lazım",
                "Нужен ремонт",
                "Necesita arreglo",
                "À réparer");

            Add("empty.noDiscord.title",
                "Discord was not found",
                "Discord bulunamadı",
                "Discord не найден",
                "No se encontró Discord",
                "Discord introuvable");

            Add("empty.noDiscord.desc",
                "Install Discord first, or choose Custom Path to locate an existing installation.",
                "Önce Discord kurun veya mevcut kurulumu Özel Konum ile seçin.",
                "Установите Discord или укажите существующую установку через «Свой путь».",
                "Instala Discord o usa Otra ruta para encontrar una instalación existente.",
                "Installez Discord ou indiquez une installation existante avec Autre chemin.");

            // Progress and done screens
            Add("prog.installingTitle",
                "Installing Solcord",
                "Solcord Kuruluyor",
                "Установка Solcord",
                "Instalando Solcord",
                "Installation d'Solcord");

            Add("prog.updatingTitle",
                "Updating Solcord",
                "Solcord Güncelleniyor",
                "Обновление Solcord",
                "Actualizando Solcord",
                "Mise à jour d'Solcord");

            Add("prog.repairingTitle",
                "Repairing Solcord",
                "Solcord Onarılıyor",
                "Восстановление Solcord",
                "Reparando Solcord",
                "Réparation d'Solcord");

            Add("prog.uninstallingTitle",
                "Restoring Vanilla Discord",
                "Orijinal Discord'a Dönülüyor",
                "Удаление Solcord",
                "Restaurando Discord",
                "Désinstallation d'Solcord");

            Add("status.preparingInstall",
                "Fluffing the pillows...",
                "Yastıklar kabartılıyor...",
                "Взбиваем подушки...",
                "Mullendo las almohadas...",
                "On tapote les coussins...");
            Add("status.preparingUpdate",
                "Fetching fresh bamboo...",
                "Taze bambu getiriliyor...",
                "Несём свежий бамбук...",
                "Trayendo bambú fresco...",
                "On apporte du bambou frais...");
            Add("status.preparingRepair",
                "Grabbing the toolbox...",
                "Alet çantası alınıyor...",
                "Достаём инструменты...",
                "Buscando la caja de herramientas...",
                "On sort la boîte à outils...");
            Add("status.closingClient", "Closing {0}...", "{0} kapatılıyor...", "Закрытие {0}...", "Cerrando {0}...", "Fermeture de {0}...");
            Add("status.extractingAsset", "Deploying {0}...", "{0} aktarılıyor...", "Распаковка {0}...", "Desplegando {0}...", "Déploiement de {0}...");
            Add("status.cleaningForeignMod", "Unhooking {0} from {1}...", "{1} içinden {0} kaldırılıyor...", "Отключение {0} из {1}...", "Desactivando {0} de {1}...", "Décrochage de {0} dans {1}...");
            Add("status.patchingClient", "Patching {0} ({1})...", "{0} ({1}) yamalanıyor...", "Патчинг {0} ({1})...", "Parcheando {0} ({1})...", "Patch de {0} ({1})...");
            Add("status.restoringClient", "Restoring {0} ({1})...", "{0} ({1}) geri yükleniyor...", "Восстановление {0} ({1})...", "Restaurando {0} ({1})...", "Restauration de {0} ({1})...");
            Add("status.verifyingClient", "Verifying {0}...", "{0} doğrulanıyor...", "Проверка {0}...", "Verificando {0}...", "Vérification de {0}...");
            Add("status.relaunchingClient", "Launching {0}...", "{0} başlatılıyor...", "Запуск {0}...", "Iniciando {0}...", "Lancement de {0}...");
            Add("status.rollingBack",
                "Putting everything back the way it was...",
                "Her şey eski haline getiriliyor...",
                "Возвращаем всё как было...",
                "Dejando todo como estaba...",
                "On remet tout comme avant...");
            Add("status.checkingRelease",
                "Checking the installed Solcord {0} against the current release...",
                "Kurulu Solcord {0} güncel sürümle karşılaştırılıyor...",
                "Сверяем установленный Solcord {0} с текущим выпуском...",
                "Comprobando el Solcord {0} instalado con la versión actual...",
                "Vérification de l'Solcord {0} installé avec la version actuelle...");
            Add("status.keepingNewer",
                "Keeping Solcord {0}, newer than this installer's {1}...",
                "Solcord {0} korunuyor, bu installer'daki {1} sürümünden yeni...",
                "Оставляем Solcord {0}: он новее, чем {1} в установщике...",
                "Conservando Solcord {0}, más nuevo que el {1} de este instalador...",
                "On garde Solcord {0}, plus récent que la {1} de cet installateur...");
            Add("status.waitingLockedFile", "Waiting for locked file: {0}", "Kilitli dosya bekleniyor: {0}", "Ожидание файла: {0}", "Esperando archivo: {0}", "Attente du fichier : {0}");

            Add("status.installComplete",
                "All set! Solcord is here",
                "Hepsi tamam! Solcord burada",
                "Готово! Solcord на месте",
                "¡Listo! Solcord ya está aquí",
                "Et voilà ! Solcord est là");
            Add("status.updateComplete",
                "Fresh and updated!",
                "Tertemiz güncellendi!",
                "Свежо и обновлено!",
                "¡Recién actualizado!",
                "Tout frais, à jour !");
            Add("status.repairComplete",
                "Good as new!",
                "Yepyeni gibi!",
                "Как новенький!",
                "¡Como nuevo!",
                "Comme neuf !");
            Add("status.uninstallComplete",
                "Back to plain Discord",
                "Sade Discord'a dönüldü",
                "Снова обычный Discord",
                "De vuelta a Discord normal",
                "Retour au Discord d'origine");

            Add("done.banner.installed",
                "Solcord is on {0} Discord install(s). Open Discord and say hi!",
                "Solcord {0} Discord kurulumunda hazır. Discord'u aç ve merhaba de!",
                "Solcord установлен ({0}). Откройте Discord и поздоровайтесь!",
                "Solcord está en {0} Discord. ¡Abre Discord y saluda!",
                "Solcord est sur {0} Discord. Ouvrez Discord et dites bonjour !");

            Add("done.banner.keptNewer",
                "Your Solcord {0} is newer than this installer ({1}), so it stayed. Discord is hooked up again on {2} install(s).",
                "Solcord {0} bu installer'dan ({1}) daha yeni, o yüzden korundu. Discord {2} kurulumda yeniden bağlandı.",
                "Ваш Solcord {0} новее этого установщика ({1}), поэтому он оставлен. Discord снова подключён ({2}).",
                "Tu Solcord {0} es más nuevo que este instalador ({1}), así que se quedó. Discord está conectado de nuevo en {2}.",
                "Votre Solcord {0} est plus récent que cet installateur ({1}), il a donc été gardé. Discord est reconnecté sur {2}.");

            Add("done.banner.migrated",
                "Brought over {0} plugins, {1} preferences and {2} themes from {3}.",
                "{3} içinden {0} eklenti, {1} tercih ve {2} tema taşındı.",
                "Перенесено из {3}: плагинов {0}, настроек {1}, тем {2}.",
                "Traídos desde {3}: {0} plugins, {1} ajustes y {2} temas.",
                "Depuis {3} : {0} plugins, {1} préférences et {2} thèmes emménagés.");

            Add("done.cleanupOffer",
                "Tidy up the leftover {0} files (your settings stay safe)",
                "Kalan {0} dosyalarını topla (ayarların güvende kalır)",
                "Убрать остатки {0} (настройки сохранятся)",
                "Recoger los restos de {0} (tus ajustes están a salvo)",
                "Ranger les restes de {0} (vos paramètres restent)");

            Add("done.btn.finish",
                "Back to start",
                "Başa dön",
                "В начало",
                "Volver al inicio",
                "Retour au début");

            Add("done.btn.closeApp",
                "Done, see you!",
                "Tamam, görüşürüz!",
                "Готово, пока!",
                "¡Listo, nos vemos!",
                "Fini, à plus !");

            // Conflicts and errors
            Add("conflict.title",
                "Swap out {0}?",
                "{0} yerine geçelim mi?",
                "Заменить {0}?",
                "¿Cambiamos {0}?",
                "On remplace {0} ?");

            Add("conflict.message",
                "{0} is living in {1} right now. Solcord will gently move it aside and take its spot. Your {0} settings stay untouched.",
                "{0} şu an {1} içinde yaşıyor. Solcord onu nazikçe kenara alıp yerine geçecek. {0} ayarlarına hiç dokunulmaz.",
                "{0} сейчас живёт в {1}. Solcord аккуратно подвинет его и займёт место. Настройки {0} останутся как есть.",
                "{0} vive ahora en {1}. Solcord lo apartará con cuidado y ocupará su lugar. Tus ajustes de {0} no se tocan.",
                "{0} habite dans {1} en ce moment. Solcord va le pousser doucement et prendre sa place. Vos paramètres {0} restent intacts.");

            Add("conflict.btn.confirm",
                "Swap and install",
                "Değiştir ve kur",
                "Заменить и установить",
                "Cambiar e instalar",
                "Remplacer et installer");

            Add("conflict.btn.cancel",
                "Not now",
                "Şimdi değil",
                "Не сейчас",
                "Ahora no",
                "Pas maintenant");

            Add("err.cancelled.title",
                "Okay, stopped",
                "Tamam, durduruldu",
                "Хорошо, остановлено",
                "Vale, detenido",
                "D'accord, arrêté");
            Add("err.cancelled.body",
                "Nothing was left half-done. Everything is back the way it was.",
                "Yarım kalan bir şey yok. Her şey eski haline döndü.",
                "Ничего не осталось недоделанным. Всё как было.",
                "No quedó nada a medias. Todo está como antes.",
                "Rien n'est resté à moitié fait. Tout est comme avant.");

            Add("err.permission.title",
                "Needs a bit more permission",
                "Biraz daha izin lazım",
                "Нужно чуть больше прав",
                "Faltan permisos",
                "Il faut un peu plus de droits");
            Add("err.permission.body",
                "Solcord can't write to '{0}'. Right-click the installer and choose Run as administrator.",
                "Solcord '{0}' konumuna yazamıyor. Kurulum dosyasına sağ tıklayıp Yönetici olarak çalıştır'ı seç.",
                "Solcord не может записать в «{0}». Нажмите правой кнопкой на установщик и выберите «Запуск от имени администратора».",
                "Solcord no puede escribir en '{0}'. Haz clic derecho en el instalador y elige Ejecutar como administrador.",
                "Solcord ne peut pas écrire dans « {0} ». Faites un clic droit sur l'installateur et choisissez Exécuter en tant qu'administrateur.");

            Add("err.locked.title",
                "Discord is still busy",
                "Discord hâlâ meşgul",
                "Discord ещё занят",
                "Discord sigue ocupado",
                "Discord est encore occupé");
            Add("err.locked.body",
                "'{0}' is still in use. Close Discord fully (check the tray too) and try again.",
                "'{0}' hâlâ kullanımda. Discord'u tamamen kapat (sistem tepsisine de bak) ve tekrar dene.",
                "«{0}» всё ещё занят. Полностью закройте Discord (проверьте и трей) и попробуйте снова.",
                "'{0}' sigue en uso. Cierra Discord del todo (mira también la bandeja) e inténtalo otra vez.",
                "« {0} » est encore utilisé. Fermez complètement Discord (vérifiez aussi la zone de notification) et réessayez.");

            Add("err.damaged.title",
                "This Discord looks broken",
                "Bu Discord bozuk görünüyor",
                "Этот Discord повреждён",
                "Este Discord parece roto",
                "Ce Discord semble cassé");
            Add("err.damaged.body",
                "{0} is missing its original 'app.asar' archive. Please reinstall {0} from discord.com first.",
                "{0} içinde orijinal 'app.asar' arşivi eksik. Lütfen önce discord.com'dan {0} sürümünü yeniden kurun.",
                "В {0} отсутствует архив «app.asar». Переустановите {0} с сайта discord.com.",
                "A {0} le falta 'app.asar'. Reinstala {0} desde discord.com primero.",
                "L'archive « app.asar » manque dans {0}. Réinstallez {0} depuis discord.com.");

            Add("err.generic.title",
                "Something went wrong",
                "Bir şeyler ters gitti",
                "Что-то пошло не так",
                "Algo salió mal",
                "Quelque chose a coincé");

            // Compatibility and backup reasons
            Add("mig.reason.compatibleCore", "Compatible preference", "Uyumlu tercih", "Совместимая настройка", "Preferencia compatible", "Préférence compatible");
            Add("mig.reason.compatiblePlugin", "Supported plugin", "Desteklenen eklenti", "Поддерживаемый плагин", "Plugin compatible", "Plugin pris en charge");
            Add("mig.reason.compatibleCss", "QuickCSS stylesheet", "QuickCSS stil dosyası", "Стили QuickCSS", "Hoja QuickCSS", "Feuille QuickCSS");
            Add("mig.reason.compatibleTheme", "CSS Theme", "CSS Teması", "Тема CSS", "Tema CSS", "Thème CSS");
            Add("mig.reason.unsupportedPlugin", "Not in Solcord", "Solcord'da yok", "Нет в Solcord", "No está en Solcord", "Absent d'Solcord");
            Add("mig.reason.clientSpecificSetting", "Client-specific flag", "İstemciye özgü ayar", "Опция другого клиента", "Opción de otro cliente", "Option spécifique");
            Add("mig.reason.cloudAuth", "External cloud token (skipped)", "Harici bulut anahtarı (atlandı)", "Токен облака (пропущен)", "Token en la nube (omitido)", "Jeton cloud (ignoré)");
            Add("mig.reason.bdPluginFormat", "BetterDiscord JS incompatible", "BetterDiscord JS uyumsuz", "BD JS несовместим", "BD JS incompatible", "BD JS incompatible");
            Add("mig.reason.corruptJson", "Malformed JSON", "Bozuk JSON", "Ошибка JSON", "JSON dañado", "JSON corrompu");

            Add("backup.createBtn",
                "Save a snapshot",
                "Yedek al",
                "Сохранить копию",
                "Guardar copia",
                "Faire une copie");
            Add("backup.restoreBtn", "Restore", "Yükle", "Восстановить", "Restaurar", "Restaurer");
            Add("backup.empty",
                "No snapshots yet. One is saved automatically before any settings move.",
                "Henüz yedek yok. Ayarlar taşınmadan önce otomatik olarak alınır.",
                "Копий пока нет. Она создаётся автоматически перед переносом настроек.",
                "Aún no hay copias. Se guarda una automáticamente antes de mover ajustes.",
                "Pas encore de copie. Une est faite automatiquement avant tout transfert.");

            // Solcord Desktop's setup (UI/DesktopSetupWindow.cs)
            Add("desktop.tagline", "Discord in Solcord's own window: lighter than Discord's app, with all of Solcord's plugins and themes.", "Discord, Solcord'un kendi penceresinde: Discord uygulamasından hafif, Solcord'un tüm eklentileri ve temalarıyla.", "Discord в собственном окне Solcord: легче приложения Discord, со всеми плагинами и темами Solcord.", "Discord en la ventana propia de Solcord: más ligero que la app de Discord, con todos los plugins y temas de Solcord.", "Discord dans la fenêtre d'Solcord : plus léger que l'appli Discord, avec tous les plugins et thèmes d'Solcord.");
            Add("desktop.note", "Windows 10 and 11, 64-bit. A 140 MB download. Your Solcord settings come along.", "Windows 10 ve 11, 64 bit. 140 MB'lık bir indirme. Solcord ayarların da gelir.", "Windows 10 и 11, 64 бит. Загрузка 140 МБ. Настройки Solcord переносятся.", "Windows 10 y 11, 64 bits. Una descarga de 140 MB. Tus ajustes de Solcord vienen contigo.", "Windows 10 et 11, 64 bits. Un téléchargement de 140 Mo. Vos réglages Solcord suivent.");
            Add("desktop.btn.install", "Install Solcord Desktop", "Solcord Desktop'ı kur", "Установить Solcord Desktop", "Instalar Solcord Desktop", "Installer Solcord Desktop");
            Add("desktop.btn.update", "Update Solcord Desktop", "Solcord Desktop'ı güncelle", "Обновить Solcord Desktop", "Actualizar Solcord Desktop", "Mettre à jour Solcord Desktop");
            Add("desktop.btn.remove", "Remove Solcord Desktop", "Solcord Desktop'ı kaldır", "Удалить Solcord Desktop", "Quitar Solcord Desktop", "Supprimer Solcord Desktop");
            Add("desktop.btn.open", "Open Solcord Desktop", "Solcord Desktop'ı aç", "Открыть Solcord Desktop", "Abrir Solcord Desktop", "Ouvrir Solcord Desktop");
            Add("desktop.btn.close", "Close", "Kapat", "Закрыть", "Cerrar", "Fermer");
            Add("desktop.btn.retry", "Try again", "Tekrar dene", "Повторить", "Reintentar", "Réessayer");
            Add("desktop.btn.cancel", "Cancel", "Vazgeç", "Отмена", "Cancelar", "Annuler");
            Add("desktop.done.title", "Solcord Desktop is ready", "Solcord Desktop hazır", "Solcord Desktop готов", "Solcord Desktop está listo", "Solcord Desktop est prêt");
            Add("desktop.done.body", "It's in the Start menu and updates itself from now on.", "Başlat menüsünde. Bundan sonra kendini kendisi günceller.", "Он в меню «Пуск» и дальше обновляется сам.", "Está en el menú Inicio y a partir de ahora se actualiza solo.", "Il est dans le menu Démarrer et se met à jour tout seul désormais.");
            Add("desktop.remove.title", "Remove Solcord Desktop?", "Solcord Desktop kaldırılsın mı?", "Удалить Solcord Desktop?", "¿Quitar Solcord Desktop?", "Supprimer Solcord Desktop ?");
            Add("desktop.remove.body", "The app and its shortcuts go. Solcord in Discord's own app stays as it is.", "Uygulama ve kısayolları silinir. Discord uygulamasındaki Solcord olduğu gibi kalır.", "Приложение и его ярлыки будут удалены. Solcord в приложении Discord останется как есть.", "Se borran la app y sus accesos directos. Solcord en la app de Discord se queda como está.", "L'appli et ses raccourcis sont supprimés. Solcord dans l'appli Discord reste tel quel.");
            Add("desktop.remove.data", "Also delete its sign-in, settings and themes", "Oturumunu, ayarlarını ve temalarını da sil", "Удалить также вход, настройки и темы", "Borrar también la sesión, los ajustes y los temas", "Supprimer aussi la connexion, les réglages et les thèmes");
            Add("desktop.removed.title", "Solcord Desktop was removed", "Solcord Desktop kaldırıldı", "Solcord Desktop удалён", "Solcord Desktop se ha quitado", "Solcord Desktop a été supprimé");
            Add("desktop.err.title", "Couldn't finish", "Tamamlanamadı", "Не удалось завершить", "No se pudo terminar", "Impossible de terminer");
            Add("desktop.status.checking", "Checking the release…", "Sürüm denetleniyor…", "Проверка выпуска…", "Comprobando la versión…", "Vérification de la version…");
            Add("desktop.status.downloading", "Downloading Solcord Desktop…", "Solcord Desktop indiriliyor…", "Загрузка Solcord Desktop…", "Descargando Solcord Desktop…", "Téléchargement d'Solcord Desktop…");
            Add("desktop.status.unpacking", "Unpacking…", "Dosyalar çıkarılıyor…", "Распаковка…", "Descomprimiendo…", "Décompression…");
            Add("desktop.status.files", "Getting the newest Solcord…", "En yeni Solcord alınıyor…", "Получение новейшего Solcord…", "Obteniendo el Solcord más reciente…", "Récupération du dernier Solcord…");
            Add("desktop.status.closing", "Closing Solcord Desktop…", "Solcord Desktop kapatılıyor…", "Закрытие Solcord Desktop…", "Cerrando Solcord Desktop…", "Fermeture d'Solcord Desktop…");
            Add("desktop.status.installing", "Installing…", "Kuruluyor…", "Установка…", "Instalando…", "Installation…");
            Add("desktop.status.shortcuts", "Adding it to the Start menu…", "Başlat menüsüne ekleniyor…", "Добавление в меню «Пуск»…", "Añadiéndolo al menú Inicio…", "Ajout au menu Démarrer…");
            Add("desktop.status.done", "Done", "Bitti", "Готово", "Listo", "Terminé");
            Add("desktop.status.removing", "Removing…", "Kaldırılıyor…", "Удаление…", "Quitando…", "Suppression…");
            Add("desktop.status.removed", "Removed", "Kaldırıldı", "Удалено", "Quitado", "Supprimé");
            Add("desktop.err.offline", "Couldn't reach GitHub, where Solcord Desktop is downloaded from. Check your connection and try again.", "Solcord Desktop'ın indirildiği GitHub'a ulaşılamadı. Bağlantını kontrol edip tekrar dene.", "Не удалось связаться с GitHub, откуда загружается Solcord Desktop. Проверьте подключение и повторите.", "No se pudo conectar con GitHub, desde donde se descarga Solcord Desktop. Revisa la conexión y reintenta.", "Impossible de joindre GitHub, d'où Solcord Desktop est téléchargé. Vérifiez la connexion et réessayez.");
            Add("desktop.err.unsigned", "The release on GitHub isn't signed with Solcord's key, so nothing was installed.", "GitHub'daki sürüm Solcord'un anahtarıyla imzalı değil, bu yüzden hiçbir şey kurulmadı.", "Выпуск на GitHub не подписан ключом Solcord, поэтому ничего не установлено.", "La versión de GitHub no está firmada con la clave de Solcord, así que no se instaló nada.", "La version sur GitHub n'est pas signée avec la clé d'Solcord, rien n'a été installé.");
            Add("desktop.err.badDownload", "The download doesn't match the signed release, so nothing was installed. Try again.", "İndirilen dosya imzalı sürümle eşleşmiyor, bu yüzden hiçbir şey kurulmadı. Tekrar dene.", "Загруженный файл не совпадает с подписанным выпуском, поэтому ничего не установлено. Повторите.", "La descarga no coincide con la versión firmada, así que no se instaló nada. Reintenta.", "Le téléchargement ne correspond pas à la version signée, rien n'a été installé. Réessayez.");
            Add("desktop.err.failed", "Something went wrong: {0}", "Bir sorun çıktı: {0}", "Что-то пошло не так: {0}", "Algo salió mal: {0}", "Un problème est survenu : {0}");

            root["en"] = en;
            root["tr"] = tr;
            root["ru"] = ru;
            root["es"] = es;
            root["fr"] = fr;
            return root;
        }
    }
}
