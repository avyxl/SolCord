// Copyright (c) 2026 avyxl. SPDX-License-Identifier: GPL-3.0-or-later
using System;
using System.Text.RegularExpressions;

namespace SolcordInstaller.Core
{
    /// <summary>SemVer ordering, including development releases. Build metadata never changes precedence.</summary>
    public sealed class PayloadRelease : IComparable<PayloadRelease>
    {
        public readonly Version Version;
        public readonly string Prerelease;
        public readonly string Display;
        PayloadRelease(Version version, string prerelease, string display)
        {
            Version = version; Prerelease = prerelease; Display = display;
        }
        public static PayloadRelease Parse(string text)
        {
            if (text == null || text.Length > 120) return null;
            var match = Regex.Match(text, @"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)(?:-([0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*))?(?:\+[0-9A-Za-z-]+(?:\.[0-9A-Za-z-]+)*)?$");
            if (!match.Success) return null;
            Version core;
            if (!Version.TryParse(match.Groups[1].Value + "." + match.Groups[2].Value + "." + match.Groups[3].Value, out core)) return null;
            string pre = match.Groups[4].Value;
            foreach (var part in pre.Split('.')) if (Numeric(part) && part.Length > 1 && part[0] == '0') return null;
            return new PayloadRelease(core, pre, text);
        }
        static bool Numeric(string text)
        {
            if (text.Length == 0) return false;
            foreach (char c in text) if (c < '0' || c > '9') return false;
            return true;
        }
        public int CompareTo(PayloadRelease other)
        {
            if (other == null) return 1;
            int core = Version.CompareTo(other.Version); if (core != 0) return core;
            if (Prerelease == other.Prerelease) return 0;
            if (Prerelease.Length == 0) return 1;
            if (other.Prerelease.Length == 0) return -1;
            var left = Prerelease.Split('.'); var right = other.Prerelease.Split('.');
            for (int i = 0; i < Math.Min(left.Length, right.Length); i++)
            {
                bool a = Numeric(left[i]), b = Numeric(right[i]);
                int compared = a && b ? (left[i].Length == right[i].Length ? string.CompareOrdinal(left[i], right[i]) : left[i].Length.CompareTo(right[i].Length)) : a != b ? (a ? -1 : 1) : string.CompareOrdinal(left[i], right[i]);
                if (compared != 0) return compared;
            }
            return left.Length.CompareTo(right.Length);
        }
        public override string ToString() { return Display; }
    }
}
