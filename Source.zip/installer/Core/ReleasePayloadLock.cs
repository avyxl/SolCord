using System;
using System.Diagnostics;
using System.IO;
using System.Text;

namespace SolcordInstaller.Core
{
    /// <summary>Shared with the running client's signed updater. Repair can release a proven dead process's lock.</summary>
    public sealed class ReleasePayloadLock : IDisposable
    {
        readonly string file;
        readonly FileStream stream, repairGuard;
        readonly string repairPath;
        ReleasePayloadLock(string path, FileStream handle, string guardPath, FileStream guard) { file = path; stream = handle; repairPath = guardPath; repairGuard = guard; }
        public static ReleasePayloadLock Acquire(string root)
        {
            Directory.CreateDirectory(root);
            string file = Path.Combine(root, ".solcord-update.lock");
            string guardPath = Path.Combine(root, ".solcord-update.repair-lock");
            var guard = new FileStream(guardPath, FileMode.OpenOrCreate, FileAccess.ReadWrite, FileShare.None);
            try {
            if (File.Exists(file)) {
                if ((File.GetAttributes(file) & FileAttributes.ReparsePoint) != 0 || new FileInfo(file).Length > 2048)
                    throw new IOException("The update lock is invalid. Close all Discord clients and inspect the Solcord update lock before repairing.");
                var record = Json.ParseObject(File.ReadAllText(file));
                var pid = record["pid"] as JsonNumber;
                int processId;
                if ((record["format"] as string) != "solcord-update-lock-v1" || pid == null || !int.TryParse(pid.Raw, out processId) || processId <= 0)
                    throw new IOException("The interrupted update lock cannot be identified. Close Discord and remove only .solcord-update.lock from the Solcord folder, then repair.");
                bool alive = true;
                try { using (var process = Process.GetProcessById(processId)) alive = !process.HasExited; }
                catch (ArgumentException) { alive = false; }
                if (alive) throw new IOException("Another Solcord update is running. Close all Discord clients before repairing.");
                File.Delete(file);
            }
            var handle = new FileStream(file, FileMode.CreateNew, FileAccess.ReadWrite, FileShare.None);
            try {
                string record = "{\"format\":\"solcord-update-lock-v1\",\"pid\":" + Process.GetCurrentProcess().Id + ",\"token\":\"" + Guid.NewGuid().ToString("N") + "\"}";
                byte[] bytes = Encoding.UTF8.GetBytes(record); handle.Write(bytes, 0, bytes.Length); handle.Flush(true);
                return new ReleasePayloadLock(file, handle, guardPath, guard);
            } catch { handle.Dispose(); File.Delete(file); throw; }
            } catch { guard.Dispose(); try { File.Delete(guardPath); } catch { } throw; }
        }
        public void Dispose() {
            stream.Dispose(); try { File.Delete(file); } catch { }
            repairGuard.Dispose(); try { File.Delete(repairPath); } catch { }
        }
    }
}
