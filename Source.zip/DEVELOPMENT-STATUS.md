# Solcord 3.0 development status

This is development source, not a stable 3.0 release. Planned requirements are not working plugins.

Implemented: 144 · In progress: 1 · Already covered: 1 · Planned: 54

Changelog: top-right toolbar, control center, Settings > Changelog.

Validation limits: component fixtures mock Discord adapters; native fixtures mock OS encryption, windows and network. Live Discord, real microphone hardware, native voice processing and optional model downloads need integration verification.

Performance: new tools are optional. Heavy models and engines are loaded on request. The shared read index is bounded; Busy Hours retains metadata only.

Configuration: public-resource tools require allowed HTTPS origins and daily request budgets in Integration controls. Credentials use available OS encryption. Some capabilities are desktop-only.

## Implemented

- 1. **Wrong Chat Guard** — Warn before posting in a marked sensitive or confusing channel.
- 2. **Attachment Reminder** — Catch messages referring to an attachment when none is attached.
- 3. **Mention Budget** — Confirm messages exceeding a chosen mention limit.
- 4. **Draft Timeline** — Keep and recover earlier draft versions across restarts.
- 5. **Edit Review** — Review changes before saving an edited message.
- 6. **Keyboard Layout Rescue** — Convert text typed using the wrong keyboard layout.
- 8. **Mixed Language Layout** — Improve mixed right-to-left and left-to-right message layout.
- 9. **Redirect Inspector** — Inspect a link's redirect chain before opening it.
- 10. **Quote Check** — Compare quoted text with a referenced original.
- 11. **Reply Inbox** — Collect replies to your messages, including replies without pings.
- 12. **Open Questions** — Track questions awaiting an answer.
- 13. **Thread Checkpoints** — Restore reading positions independently for threads.
- 14. **Search Workspaces** — Save searches, filters, and result positions.
- 15. **Search Compare** — Compare two sets of search results.
- 16. **Reply Branch Map** — Browse branching replies as a conversation tree.
- 17. **Answer Shelf** — Save reusable answers tied to their source messages.
- 18. **Link Index** — Index observed links by domain, channel, and duplicate URL.
- 19. **Catch-up Outline** — Review new threads, pins, and mentions since your last visit.
- 20. **Crosspost Finder** — Group repeated announcements across observed channels.
- 21. **Local Channel Aliases** — Rename channels on your device only.
- 22. **Leave Server Checklist** — Review drafts, references, and notes before leaving a server.
- 23. **Unread Explainer** — Identify channels and messages behind unread indicators.
- 24. **Forum Follow-ups** — Track selected forum posts for resolution or archival.
- 25. **Saved Link Health** — Check saved message links for access or deletion.
- 26. **Personal Server Directory** — Record server purposes and useful channels.
- 27. **Channel Cleanup Planner** — Review rarely used channels before muting or hiding them.
- 28. **Navigation Trail** — Record how searches and links led to a conversation.
- 29. **Busy Hours** — Chart observed channel activity without retaining message content.
- 30. **Attachment Inventory** — Browse observed file metadata by channel, type, size, and date.
- 31. **Image Metadata Cleaner** — Re-encode supported images without camera or location metadata.
- 32. **Upload Size Planner** — Plan compression around the actual upload limit.
- 33. **Screenshot Redactor** — Obscure selected image regions before uploading.
- 34. **Local Image OCR** — Extract image text with an optional on-device engine.
- 35. **Image Compare** — Compare images side by side or with a divider.
- 37. **Color Profile Converter** — Convert supported images to sRGB for sharing.
- 38. **HEIC Converter** — Convert supported phone photos to a common image format.
- 39. **Video Contact Sheets** — Create timestamped thumbnail grids from videos.
- 40. **Subtitle Companion** — Load local subtitle tracks beside attachment playback.
- 41. **PTT Watchdog** — Warn about a potentially stuck push-to-talk state.
- 42. **Clipping Timeline** — Track microphone clipping events during calibration.
- 43. **Audio Device Failover** — Switch to a configured backup audio device after disconnection.
- 44. **Per-device Audio Profiles** — Restore settings for individual microphones and headsets.
- 45. **Audio Clock Doctor** — Diagnose available sample-rate and timing information.
- 46. **Call Quality History** — Keep a local timeline of network quality and dropouts.
- 47. **Talk Balance** — Measure speaking-time distribution without recording speech.
- 56. **Stream Readability Check** — Estimate text readability at a selected sharing resolution.
- 59. **Stream Markers** — Save timestamped notes during a stream.
- 63. **Match Result Cards** — Create shareable cards from manually entered results.
- 64. **Team Balancer** — Balance teams using supplied ratings and role preferences.
- 65. **Session Recap** — Collect entered match results, highlights, and session notes.
- 66. **Availability Overlap** — Find common times in explicitly shared availability.
- 67. **Lobby Code Cards** — Format supported lobby codes with copy actions.
- 69. **Combined Event Agenda** — Combine accessible scheduled server events.
- 70. **LFG Post Builder** — Build consistent looking-for-group posts for review.
- 71. **Private Document Viewer** — Preview supported documents locally without an external viewer.
- 73. **Clipboard Expiry** — Expire clipboard content copied by this feature without erasing newer copies.
- 74. **Encrypted Exports** — Encrypt chosen exported data with a password.
- 75. **Remote Resource Firewall** — Control optional resource requests by hostname.
- 76. **Account Data Isolation** — Separate supported local feature data between accounts.
- 78. **Reading Ruler** — Display an adjustable reading guide over chat.
- 80. **Role Shape Labels** — Distinguish role colors with local shapes or patterns.
- 81. **Plugin Storage Map** — Inspect supported plugins' local storage usage.
- 83. **Selective Settings Import** — Import chosen plugin settings from a backup.
- 84. **Settings Diff** — Compare configuration values before applying changes.
- 85. **Configuration Linter** — Inspect malformed, obsolete, or unknown configuration values.
- 90. **Support Bundle Builder** — Export reviewable diagnostics after removing sensitive fields.
- 91. **Attachment Checksums** — Calculate and compare SHA-256 file checksums.
- 92. **Dependency Diff** — Compare package manifest dependency versions.
- 93. **Log Triage** — Group repeated errors and locate their first appearance.
- 94. **JSON Workbench** — Validate, format, and inspect JSON locally.
- 95. **Code Diff Viewer** — Compare code blocks or text files line by line.
- 96. **Regex Workbench** — Test bounded regular expressions against supplied text.
- 97. **API Reference Cards** — Look up selected programming terms in configured official documentation.
- 98. **File Type Verifier** — Compare a selected file's extension with its detected format.
- 99. **Release Change Digest** — Inspect additions and changes between recorded Solcord releases.
- 100. **Profile Sync Doctor** — Inspect supported profile-sharing and badge-verification state.
- 102. **Double-send Guard** — Stop accidental duplicate outgoing messages during a short window.
- 103. **Text as File** — Save a long draft as a named text or code attachment.
- 104. **Smart Link Titles** — Prepare readable titled links for review before posting.
- 105. **Text Attachment Editor** — Edit a selected text file locally and export the result.
- 107. **Code Fence Repair** — Detect or repair unmatched Markdown code fences.
- 108. **Spreadsheet Paste** — Convert tabular clipboard text to Markdown or CSV.
- 109. **Paste Without Pings** — Neutralize mention syntax in pasted text.
- 110. **Move My Message** — Prepare your own message for reposting in the correct channel.
- 111. **Attachment Contents Search** — Search inside explicitly indexed supported documents.
- 112. **Fuzzy Message Search** — Find locally indexed messages despite small spelling differences.
- 115. **Search by Language** — Filter indexed text by detected writing system or configured language engine.
- 116. **Session Context Search** — Search locally observed messages within a selected session's time window.
- 117. **Multi-message Copy** — Copy selected messages into one attributed document.
- 118. **Calendar Quick Add** — Create a reviewable calendar event from supplied date information.
- 119. **Per-link Embed Controls** — Choose which outgoing links generate previews.
- 120. **Channel Spoiler Defaults** — Apply a configured spoiler default to attachments in chosen channels.
- 123. **Attachment Versions** — Group explicitly associated document revisions.
- 124. **Folder Privacy Check** — Inspect selected upload filenames for sensitive files.
- 125. **Conversation Capture** — Create an image of selected, attributed conversation messages.
- 128. **Audio File Normalizer** — Normalize a selected audio attachment locally.
- 130. **File Reputation Lookup** — Look up a selected checksum in a configured reputation service.
- 131. **Image Collage Builder** — Arrange selected images into a labeled collage.
- 132. **Video Chapters** — Save named playback markers for videos.
- 133. **Playback Memory** — Remember supported media positions across restarts.
- 134. **Media Audio Mixer** — Control active supported media players in one panel.
- 143. **Microphone Access Log** — Log capture requests through supported feature APIs.
- 150. **Notification Rule Tester** — Test local alert predicates without sending notifications.
- 151. **Independent Panel Scaling** — Adjust supported interface panels independently.
- 152. **Monitor Layout Profiles** — Save and restore supported window layouts.
- 153. **Find Visible Text** — Find text in the currently rendered interface.
- 154. **Mouse Gestures** — Run configured navigation actions from mouse gestures.
- 155. **Visual Sound Cues** — Display labeled equivalents of supported sound events.
- 156. **Pronunciation Dictionary** — Apply chosen pronunciation replacements to supported speech.
- 157. **Dictation Composer** — Prepare editable text using an optional speech-recognition engine.
- 158. **Read-aloud Queue** — Queue selected text for personal speech playback.
- 159. **Font Coverage Checker** — Inspect chosen font coverage and fallback behavior.
- 160. **Shortcut Conflict Finder** — Detect duplicate registered shortcut definitions.
- 161. **Common Games Finder** — Compare voluntarily supplied game libraries.
- 162. **Crossplay Planner** — Compare party requirements using supplied compatibility data.
- 163. **Game Server Status** — Query explicitly configured, supported game-server endpoints.
- 164. **Game Patch Notes Feed** — Read configured official update feeds.
- 165. **Game Night Checklist** — Review saved devices, version requirements, and party details.
- 166. **Wishlist Deal Alerts** — Inspect configured store results against explicit price targets.
- 167. **Shared Cost Splitter** — Split supplied costs and track manually confirmed contributions.
- 168. **Tournament Brackets** — Generate and update tournament brackets from entered results.
- 169. **Lobby Rules Cards** — Create clear cards containing entered house rules.
- 170. **Event Attendance** — Record voluntary check-ins for recurring events.
- 171. **Community Help Directory** — Search an explicitly shared directory of offered help topics.
- 172. **Controller Navigation** — Control supported navigation using a gamepad.
- 173. **Permission Simulator** — Preview supplied role and channel permission changes.
- 174. **Role Audit** — Inspect role combinations for redundancy and broad grants.
- 178. **Moderation Evidence Pack** — Export chosen case material with source references and redaction.
- 179. **Moderator Handoff** — Share configured case assignments and handover notes.
- 183. **Channel Redirects** — Offer explicitly configured replacements for retired channels.
- 184. **Announcement Acknowledgments** — Compare explicit acknowledgments with an intended audience.
- 185. **Bug Report Wizard** — Prepare reproduction steps and user-approved diagnostics.
- 187. **Private Local Session** — Pause selected local logging features for a temporary session.
- 188. **Safe Configuration Sharing** — Remove selected secrets and identifiers before configuration export.
- 190. **Integration Credential Vault** — Use an available operating-system credential store for supported integrations.
- 191. **API Usage Budgets** — Cap requests passing through the supported integration client.
- 192. **Integration Health Panel** — Inspect errors, authentication failures, and rate-limit state.
- 193. **Theme Safety Scan** — Inspect custom CSS for remote imports and expensive or disruptive rules.
- 194. **Style Source Inspector** — Inspect the origins of CSS rules affecting a selected element.
- 195. **Link Reputation Lookup** — Check a selected URL with an explicitly configured reputation service.
- 196. **Reproduction Steps Recorder** — Record approved UI actions while omitting typed message contents.
- 198. **Known Issue Lookup** — Match supplied errors against configured maintainer advisories.
- 199. **Scam Message Explainer** — Explain matched scam patterns without treating matches as proof.
- 200. **Deep-link Inspector** — Explain a link's scheme, target application, and supplied parameters.

## In progress

- 176. **AutoMod Regression Tests** — Test proposed rules against a saved sample set. Local JavaScript regression testing works. Discord uses a different regex engine; compatibility testing remains in progress.

## Already covered

- 189. **Installer Signature Verification** — Verify supported signed releases using a configured trusted public key. The signed-release updater already verifies trusted release metadata.

## Planned

- 7. **Server Dictionary** — Maintain server-specific spelling exceptions.
- 36. **Duplicate Upload Guard** — Check outgoing images against earlier uploads.
- 48. **Live Call Captions** — Provide optional on-device captions with participant consent.
- 49. **Voice Shortcuts** — Recognize local spoken commands for chosen actions.
- 50. **Soundboard Balance** — Remember selected soundboard playback levels.
- 51. **Share Preflight** — Review the chosen screen-share source and privacy settings.
- 52. **Share Pause** — Freeze an outgoing picture while keeping voice connected.
- 53. **Stream Privacy Masks** — Cover chosen regions in the actual outgoing stream.
- 54. **Input Overlay** — Display selected keys and clicks in a presentation.
- 55. **Presenter Magnifier** — Magnify a chosen region in an outgoing stream.
- 57. **Share Scene Presets** — Save capture-source, audio-routing, and mask configurations.
- 58. **Viewer Feedback** — Collect explicit quality feedback from participating viewers.
- 60. **Share Audio Probe** — Test whether the intended application's audio is captured.
- 61. **Opt-in Squad Finder** — Match participating players by game, region, and roles.
- 62. **Party Ready Check** — Run an explicit ready check for a selected party.
- 68. **Per-game Setups** — Activate a saved Solcord setup for a configured game.
- 72. **Notification Redactor** — Remove selected sensitive patterns from supported notifications.
- 77. **Flash Guard** — Inspect supported animation for rapid flashing before playback.
- 79. **Screen Reader Chat Mode** — Control supported message announcements and reply context.
- 82. **Plugin Bisect** — Isolate a reproducible plugin problem by testing groups.
- 86. **Runtime Plugin Profiler** — Measure supported plugin activity during normal use.
- 87. **Listener Leak Watch** — Inspect tracked timers and listeners surviving plugin shutdown.
- 88. **Adaptive Effects Budget** — Reduce selected optional effects under sustained frame pressure.
- 89. **Media Data Budget** — Restrict optional media loading using an explicit data allowance.
- 101. **Outbox Recovery** — Preserve failed text and attachment drafts for explicit retry.
- 106. **Draft Conflict Resolver** — Detect conflicting draft edits across cooperating sessions.
- 113. **Semantic Search** — Search an opted-in index with an optional embedding model.
- 114. **Find This Image** — Find matching images in an opted-in local attachment index.
- 121. **Download Manager** — Queue downloads with progress and supported resume behavior.
- 122. **Download Routing** — Choose destinations based on channel or file type.
- 126. **Video Trimmer** — Trim a selected section of a local video before uploading.
- 127. **Clip Track Mixer** — Select and mix supported recording audio tracks.
- 129. **Video Redactor** — Render approved region masks into supported local video.
- 135. **Microphone Input Mixer** — Mix explicitly selected input sources with separate levels.
- 136. **Priority Voice Ducking** — Lower supported media while selected speakers are active.
- 137. **Output Peak Limiter** — Limit peaks in supported audio output paths.
- 138. **Dual Audio Output** — Route supported audio to two selected devices.
- 139. **Feedback Guard** — Warn about likely feedback in a configured audio path.
- 140. **Hold to Disconnect** — Require a short hold before the local disconnect action.
- 141. **Per-person EQ** — Apply local equalization to supported participant audio paths.
- 142. **Audio Video Sync Adjustment** — Adjust timing in supported playback paths.
- 144. **Round-trip Audio Test** — Test transmission with a cooperating, explicitly configured bot.
- 145. **Notification Digest** — Batch supported alerts into periodic summaries.
- 146. **Repeated-call Rules** — Apply explicitly chosen repeated-call exception rules.
- 147. **Context Notifications** — Show approved surrounding context in supported notification previews.
- 148. **Contact Ringtones** — Choose incoming-call tones for selected contacts.
- 149. **Busy Call Replies** — Prepare a chosen message when declining a call.
- 175. **Privilege Change Alerts** — Notify authorized users about observed powerful permission grants.
- 177. **Temporary Roles** — Manage expiring roles through a configured authorized bot.
- 180. **Private Server Report Inbox** — Submit explicit member reports to a configured private review queue.
- 181. **Webhook Activity Monitor** — Summarize observed webhook posting rates and changes.
- 182. **Timed Channel Access** — Schedule supported permission changes through an authorized bot.
- 186. **Appeal Workflow** — Submit and review appeals through a configured authorized service.
- 197. **Community Compatibility Reports** — Submit opted-in plugin and client compatibility reports.
