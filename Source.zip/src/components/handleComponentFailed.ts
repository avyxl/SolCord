/*
 * Solcord, a Discord client mod
 * Copyright (c) 2022 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { t } from "@utils/i18n";
import { maybePromptToUpdate } from "@utils/updater";

export function handleComponentFailed() {
    maybePromptToUpdate(t("This page tripped over itself (｡•́︿•̀｡) A fresh Solcord update might fix it. Want to update and restart now?"));
}
