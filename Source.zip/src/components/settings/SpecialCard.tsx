/*
 * Solcord, a Discord client mod
 * Copyright (c) 2023 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import "./SpecialCard.css";

import { classNameFactory } from "@utils/css";
import { classes } from "@utils/misc";
import type { CSSProperties, PropsWithChildren, ReactNode } from "react";

const cl = classNameFactory("ec-card-");

export type SpecialCardAccent = "ice" | "bamboo" | "honey";

interface SpecialCardProps {
    title: string;
    subtitle?: string;
    description: string;
    /** Artwork shown on the right, usually a <PixelArt /> */
    art?: ReactNode;
    accent?: SpecialCardAccent;
    /** Buttons shown under the text */
    actions?: ReactNode;
}

export function SpecialCard({ title, subtitle, description, art, accent = "ice", actions, children }: PropsWithChildren<SpecialCardProps>) {
    return (
        <section className={cl("root", `accent-${accent}`)}>
            <div className={cl("body")}>
                <div className={cl("text")}>
                    <h2 className={cl("title")}>{title}</h2>
                    {subtitle && <p className={cl("subtitle")}>{subtitle}</p>}
                    <p className={cl("description")}>{description}</p>
                    {children}
                    {actions && <div className={cl("actions")}>{actions}</div>}
                </div>
                {art && <div className={cl("art")} aria-hidden="true">{art}</div>}
            </div>
        </section>
    );
}

/**
 * Crisp pixel art drawn from rows of characters, matching the pixel style of the Solcord logo.
 * Every character maps to a colour in `palette`; "." is transparent.
 */
export function PixelArt({ rows, palette, pixel = 5, className, style }: { rows: string[]; palette: Record<string, string>; pixel?: number; className?: string; style?: CSSProperties; }) {
    const width = Math.max(...rows.map(r => r.length));
    const rects: ReactNode[] = [];
    rows.forEach((row, y) => {
        for (let x = 0; x < row.length; x++) {
            const fill = palette[row[x]];
            if (fill) rects.push(<rect key={`${x}-${y}`} x={x} y={y} width={1.02} height={1.02} fill={fill} />);
        }
    });
    return (
        <svg
            className={classes(cl("pixel-art"), className)}
            aria-hidden="true"
            width={width * pixel}
            height={rows.length * pixel}
            viewBox={`0 0 ${width} ${rows.length}`}
            shapeRendering="crispEdges"
            style={style}
        >
            {rects}
        </svg>
    );
}

export const HEART_ROWS = [
    ".HH...HH.",
    "HLHH.HHHH",
    "HLHHHHHHH",
    "HHHHHHHHH",
    ".HHHHHHH.",
    "..HHHHH..",
    "...HHH...",
    "....H....",
];
export const HEART_PALETTE = { H: "#F0776B", L: "#F8B4AC" };
