/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 Solcord contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { Settings, useSettings } from "@api/Settings";
import { FormSwitch } from "@components/FormSwitch";
import { SOLCORD_ACCENTS, SOLCORD_APPEARANCE_PATHS, toggleSolcordTheme } from "@utils/solcordAppearance";

export function SolcordAppearance() {
    const settings = useSettings([...SOLCORD_APPEARANCE_PATHS]);
    return (
        <section className="sc-appearance" aria-label="Solcord appearance">
            <div className="sc-appearance-heading">
                <div>
                    <span className="sc-eyebrow">MAKE IT YOURS</span>
                    <h2>Your space. Your Solcord.</h2>
                    <p>Solana colors, a quieter interface, and a little more control.</p>
                </div>
                <span className="sc-build-label">SOLCORD {VERSION}</span>
            </div>
            <FormSwitch title="Use Solcord chat colors" description="Turn off to use Discord’s appearance and your own chat themes. Changes apply immediately." value={settings.solcordChatTheme} onChange={value => Settings.solcordChatTheme = value} hideBorder />
            <div className="sc-presets" role="group" aria-label="Accent color">
                {SOLCORD_ACCENTS.map(accent => (
                    <button
                        key={accent.value}
                        className={`sc-preset${settings.solcordAccent === accent.value ? " sc-selected" : ""}`}
                        aria-pressed={settings.solcordAccent === accent.value}
                        onClick={() => Settings.solcordAccent = accent.value}
                    >
                        <span className={`sc-swatch sc-swatch-${accent.value}`} />
                        <strong>{accent.label}</strong>
                        <span>{settings.solcordAccent === accent.value ? "Selected" : "Use accent"}</span>
                    </button>
                ))}
            </div>
            <div className="sc-theme-row">
                <div><strong>Background</strong><p>Midnight purple or true black.</p></div>
                <div className="sc-segmented" role="group" aria-label="Background">
                    {(["midnight", "oled"] as const).map(theme => (
                        <button key={theme} disabled={!settings.solcordChatTheme} aria-pressed={settings.solcordTheme === theme} onClick={() => Settings.solcordTheme = theme}>
                            {theme === "oled" ? "OLED" : "Midnight"}
                        </button>
                    ))}
                </div>
            </div>
            <FormSwitch title="Compact chat" description="Tighter message spacing so more of the conversation fits on screen." value={settings.solcordCompact} onChange={value => Settings.solcordCompact = value} hideBorder />
            <FormSwitch title="Reduced motion" description="Keep the interface still. Your system motion preference is also respected." value={settings.solcordReduceMotion} onChange={value => Settings.solcordReduceMotion = value} hideBorder />
            <FormSwitch title="Quick theme shortcut" description="Press Ctrl+Alt+S to switch between Midnight and OLED anywhere in Discord." value={settings.solcordThemeShortcut} onChange={value => Settings.solcordThemeShortcut = value} hideBorder />
            <div className="sc-appearance-footer">
                <button className="sc-text-button" onClick={toggleSolcordTheme}>Switch background</button>
                <button className="sc-text-button" onClick={() => {
                    Settings.solcordChatTheme = true;
                    Settings.solcordAccent = "aurora";
                    Settings.solcordTheme = "midnight";
                    Settings.solcordCompact = false;
                    Settings.solcordReduceMotion = false;
                    Settings.solcordThemeShortcut = true;
                }}>Reset appearance</button>
            </div>
        </section>
    );
}
