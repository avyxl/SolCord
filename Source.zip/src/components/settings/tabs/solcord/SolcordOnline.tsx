/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { useSettings } from "@api/Settings";
import { FormSwitch } from "@components/FormSwitch";
import { useSolcordPresence } from "@utils/solcordPresence";

export function SolcordOnline() {
    const settings = useSettings(["solcordOnlineParticipation"]);
    const status = useSolcordPresence();
    const text = status.online !== undefined
        ? `${status.online.toLocaleString()} Solcord installation${status.online === 1 ? "" : "s"} online`
        : status.countUnavailable ? "Online count unavailable" : "Loading online count…";
    const participation = {
        off: "This installation is not included.",
        connecting: "Connecting this installation…",
        included: "This installation is included.",
        retrying: "The service is unavailable. Retrying in the background.",
        "storage-error": "Could not save a random ID on this device. Turn participation off and on to retry."
    }[status.participation];

    return <section className="ec-home-group sc-online" aria-label="Solcord online installations">
        <h3 className="ec-home-group-title">Online installations</h3>
        <div className="ec-home-card">
            <div className="ec-home-row sc-online-count">
                <div className="ec-home-row-text">
                    <div className="ec-home-row-title" role="status">{text}</div>
                    <div className="ec-home-row-description">Participating installations seen in the last 3 minutes. Includes idle installations.</div>
                </div>
                <a href="https://avyxl.github.io/SolCord/" target="_blank" rel="noopener noreferrer">Website</a>
            </div>
            <FormSwitch
                title="Include this installation in the online count"
                description="Enabled by default; you can turn it off. Sends a random installation ID about once a minute while Solcord runs. No Discord account information, messages, or tokens."
                value={settings.solcordOnlineParticipation}
                hideBorder
                onChange={value => { settings.solcordOnlineParticipation = value; }}
            />
            <div className="ec-home-row sc-online-status" role="status">{participation} Turning this off removes the local ID and sends a best-effort leave request.</div>
        </div>
    </section>;
}
