/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { useSettings } from "@api/Settings";
import { FormSwitch } from "@components/FormSwitch";
import { refreshChannelProfiles, SOLCORD_INVITE, SOLCORD_PROFILES_URL } from "@utils/solcordProfileChannel";
export function SolcordCommunitySettings() {
    const settings = useSettings(["solcordProfileSharing", "solcordShowStaffBadges"]);
    return <section className="ec-home-group">
        <h3 className="ec-home-group-title">Community profiles</h3>
        <div className="ec-home-card sc-community-editor">
            <div className="ec-home-row sc-community-summary">
                <h3>Profiles and badges other Solcord users can see</h3>
                <p>Join the Solcord server, enable sharing, then save your CustomProfile. There is no separate account-linking step.</p>
                <p>Solcord publishes profile data and image attachments in the profiles channel. Anyone who can read that channel can see those posts. Your Discord message author identifies your profile.</p>
                <p><a href={SOLCORD_INVITE} target="_blank" rel="noopener noreferrer">Join the Solcord server</a> · <a href={SOLCORD_PROFILES_URL} target="_blank" rel="noopener noreferrer">Open profiles</a></p>
            </div>
            <FormSwitch title="Share my CustomProfile with other Solcord users"
                description="Save your CustomProfile after enabling. Email and phone stay local. Turning this off publishes a removal record."
                value={settings.solcordProfileSharing} onChange={value => { settings.solcordProfileSharing = value; }} hideBorder />
            <FormSwitch title="Show Solcord staff badges"
                description="Show staff badges verified by the Solcord key service."
                value={settings.solcordShowStaffBadges} onChange={value => { settings.solcordShowStaffBadges = value; }} hideBorder />
            <div className="ec-home-row sc-community-summary">
                <button onClick={() => { void refreshChannelProfiles(); }}>Refresh profiles</button>
                <p>Upload a badge under <strong>Plugins → CustomBadge</strong>. Redeem a staff key under <strong>Plugins → OwnerBadge</strong>.</p>
                <p>Viewers need this update, the relevant plugins enabled, and access to the profiles channel. Ordinary Discord clients display your official profile.</p>
            </div>
        </div>
    </section>;
}
