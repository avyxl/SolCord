/*
 * Solcord, a Discord client mod
 * Copyright (c) 2022 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import "./PluginModal.css?screen";

import { hasAnyVisibleSettings, isSettingHidden } from "@api/PluginManager";
import { useSettings } from "@api/Settings";
import { BaseText } from "@components/BaseText";
import ErrorBoundary from "@components/ErrorBoundary";
import { SolcordModal } from "@components/SolcordModal";
import { SolcordPeople } from "@components/SolcordPeople";
import { debounce } from "@shared/debounce";
import { hasShmeggCredit } from "@shared/solcordContributorPlugins";
import { RenderModalProps } from "@solcord/discord-types";
import { BAN_RISK, BAN_RISK_LEAD } from "@utils/banRisk";
import { REPO_URL } from "@utils/constants";
import { classNameFactory } from "@utils/css";
import { useI18n } from "@utils/i18n";
import { Margins } from "@utils/margins";
import { classes } from "@utils/misc";
import { OptionType, Plugin, PluginTag } from "@utils/types";
import { Forms, openModal, React, Text, useEffect } from "@webpack/common";

import { PluginMeta } from "~plugins";

import { OptionComponentMap } from "./components";
import { GithubButton } from "./LinkIconButton";
import { PluginPreview } from "./PluginPreview";

const cl = classNameFactory("vc-plugin-modal-");


interface PluginModalProps extends RenderModalProps {
    plugin: Plugin;
    onRestartNeeded(key: string): void;
    /** Setting to scroll to and highlight, when the modal was opened from a search */
    focusSetting?: string;
}

function PluginTags({ tags }: { tags: PluginTag[]; }) {
    const { t } = useI18n();
    return (
        <div className={cl("tags")}>
            {tags.map(tag => (
                <div key={tag} className={cl("tag")}>{t(tag)}</div>
            ))}
        </div>
    );
}

export default function PluginModal({ plugin, onRestartNeeded, onClose, transitionState, focusSetting }: PluginModalProps) {
    const { t, tPluginDesc } = useI18n();
    const pluginSettings = useSettings([`plugins.${plugin.name}.*`]).plugins[plugin.name];
    const hasSettings = hasAnyVisibleSettings(plugin);

    useEffect(() => {
        if (!focusSetting) return;
        // Wait for the modal's open animation so the layout is final
        const timer = setTimeout(() => {
            document.querySelector(`[data-ec-setting="${CSS.escape(focusSetting)}"]`)?.scrollIntoView({ block: "center", behavior: "smooth" });
        }, 200);
        return () => clearTimeout(timer);
    }, [focusSetting]);

    function renderSettings() {
        const { settings } = plugin;
        if (!hasSettings || !settings)
            return <Forms.FormText>{t("There are no settings for this plugin.")}</Forms.FormText>;

        const options = Object.entries(settings.def).map(([key, setting]) => {
            if (setting.type === OptionType.CUSTOM) return null;

            if (isSettingHidden(settings, setting)) return null;

            function onChange(newValue: any) {
                const option = plugin.settings!.def[key];
                if (!option || option.type === OptionType.CUSTOM) return;

                pluginSettings[key] = newValue;

                if (option.restartNeeded) onRestartNeeded(key);
            }

            const Component = OptionComponentMap[setting.type];
            return (
                <div key={key} data-ec-setting={key} className={key === focusSetting ? "ec-setting-found" : undefined}>
                    <ErrorBoundary noop>
                        <Component
                            id={key}
                            setting={setting}
                            onChange={debounce(onChange)}
                            pluginSettings={pluginSettings}
                            definedSettings={settings}
                            closePluginSettings={onClose}
                        />
                    </ErrorBoundary>
                </div>
            );
        });

        return (
            <div className="vc-plugins-settings">
                {options}
            </div>
        );
    }

    const pluginMeta = PluginMeta[plugin.name];

    return (
        <SolcordModal
            transitionState={transitionState}
            onClose={onClose}
            size="lg"
            title={
                <div className={cl("header")}>
                    <BaseText tag="h1" weight="semibold" size="lg">{plugin.name}</BaseText>
                    {!pluginMeta.userPlugin && (
                        <div className="vc-settings-modal-links">
                            <GithubButton
                                text={t("View Source Code")}
                                href={`${REPO_URL}/tree/main/src/plugins/${pluginMeta.folderName}`}
                            />
                        </div>
                    )}
                </div>
            }
            subtitle={
                <div className={cl("info")}>
                    <div>
                        <Forms.FormText>{tPluginDesc(plugin.name, plugin.description)}</Forms.FormText>
                        {!!plugin.tags?.length && <PluginTags tags={plugin.tags} />}
                        {BAN_RISK[plugin.name] && (
                            <div className={cl("ban-risk")} role="note">
                                <BaseText size="sm" weight="semibold">{t("Ban risk")}</BaseText>
                                <BaseText size="sm">{t(BAN_RISK_LEAD)} {t(BAN_RISK[plugin.name])} {t("Use it on an account you can afford to lose.")}</BaseText>
                            </div>
                        )}
                    </div>
                </div>
            }
        >
            <div className={"vc-settings-modal-content"}>
                {!pluginMeta.userPlugin && (
                    <ErrorBoundary noop>
                        <PluginPreview name={plugin.name} />
                    </ErrorBoundary>
                )}

                <section>
                    <Text variant="heading-lg/semibold" className={classes(Margins.top8, Margins.bottom8)}>{t("Authors")}</Text>
                    <SolcordPeople authorOnly={!hasShmeggCredit(plugin.name)} />
                </section>

                {!!plugin.settingsAboutComponent && (
                    <div className={Margins.top16}>
                        <section>
                            <ErrorBoundary message={t("This plugin's info panel tripped over itself, but its settings still work.")}>
                                <plugin.settingsAboutComponent />
                            </ErrorBoundary>
                        </section>
                    </div>
                )}

                <section>
                    <Text variant="heading-lg/semibold" className={classes(Margins.top16, Margins.bottom8)}>{t("Settings")}</Text>
                    {renderSettings()}
                </section>
            </div>
        </SolcordModal>
    );
}

export function openPluginModal(plugin: Plugin, onRestartNeeded?: (pluginName: string, key: string) => void, focusSetting?: string) {
    openModal(modalProps => (
        <PluginModal
            {...modalProps}
            plugin={plugin}
            focusSetting={focusSetting}
            onRestartNeeded={(key: string) => onRestartNeeded?.(plugin.name, key)}
        />
    ));
}

