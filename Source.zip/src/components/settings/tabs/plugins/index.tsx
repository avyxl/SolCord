/*
 * Solcord, a Discord client mod
 * Copyright (c) 2022 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import "./styles.css?screen";

import * as DataStore from "@api/DataStore";
import { isListedPlugin, isPluginEnabled } from "@api/PluginManager";
import { POPULAR_PLUGIN_ORDER } from "@api/PluginProfiles";
import { IS_SAFE_MODE } from "@api/SafeMode";
import { useSettings } from "@api/Settings";
import { Card } from "@components/Card";
import { peek } from "@components/delight";
import { Divider } from "@components/Divider";
import ErrorBoundary from "@components/ErrorBoundary";
import { HeadingTertiary } from "@components/Heading";
import { Paragraph } from "@components/Paragraph";
import { SettingsTab, wrapTab } from "@components/settings/tabs/BaseTab";
import { AppsIcon, PowerIcon, SleepIcon, SolcordMark, SparkleIcon } from "@components/SolcordIcons";
import { ChangeList } from "@utils/ChangeList";
import { classNameFactory } from "@utils/css";
import { isTruthy } from "@utils/guards";
import { t, useI18n } from "@utils/i18n";
import { Logger } from "@utils/Logger";
import { Margins } from "@utils/margins";
import { classes } from "@utils/misc";
import { relaunch } from "@utils/native";
import { useAwaiter, useCleanupEffect } from "@utils/react";
import { IconProps, PluginTag, PluginTags } from "@utils/types";
import { Button, ConfirmModal, lodash, openModal, Parser, React, SearchableSelect, Select, TextInput, Tooltip, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "@webpack/common";
import { ComponentType, JSX, PropsWithChildren } from "react";

import Plugins, { ExcludedPlugins, PluginMeta } from "~plugins";

import { LibrarySort, matchesIntent } from "./libraryModel";
import { editLibrary, librarySnapshot, loadLibrary, watchLibrary } from "./libraryState";
import { listItem } from "./listItems";
import { PluginCard } from "./PluginCard";
import { ProfilesBar } from "./Profiles";
import { searchSettings,SettingEntry } from "./settingsIndex";
import { UIElementsButton } from "./UIElements";

export const cl = classNameFactory("vc-plugins-");
export const logger = new Logger("PluginSettings", "#a6d189");


const POPULAR_PLUGINS = new Set<string>(POPULAR_PLUGIN_ORDER);

function popularRank(name: string) {
    const index = POPULAR_PLUGIN_ORDER.indexOf(name);
    return index === -1 ? Number.POSITIVE_INFINITY : index;
}

function ReloadRequiredCard() {
    const { t } = useI18n();
    return (
        <Card variant="warning" className={cl("info-card")}>
            <HeadingTertiary>{t("Restart required")}</HeadingTertiary>
            <Paragraph className={cl("dep-text")}>
                {t("Restart now to apply new plugins and their settings")}
            </Paragraph>
            <Button onClick={() => location.reload()} className={cl("restart-button")}>
                {t("Restart")}
            </Button>
        </Card>
    );
}

function SafeModeCard() {
    const { t } = useI18n();
    return (
        <Card variant="warning" className={cl("info-card")}>
            <HeadingTertiary>{t("Safe mode")}</HeadingTertiary>
            <Paragraph className={cl("dep-text")}>
                {t("No plugin is running right now. The switches show and change what's on after you restart normally.")}
            </Paragraph>
            <Button onClick={relaunch} className={cl("restart-button")}>
                {t("Restart normally")}
            </Button>
        </Card>
    );
}

const enum SearchStatus {
    ALL,
    ENABLED,
    DISABLED,
    NEW,
    USER_PLUGINS,
    API_PLUGINS,
    FAVORITES,
    RECENT
}

interface StatTileProps {
    Icon: ComponentType<IconProps>;
    label: string;
    value: number;
    selected: boolean;
    tone?: "on";
    wide?: boolean;
    onClick(): void;
}

function StatTile({ Icon, label, value, selected, tone, wide, onClick, children }: PropsWithChildren<StatTileProps>) {
    return (
        <button className={cl("stat", tone && `stat-${tone}`, { "stat-wide": wide, "stat-selected": selected })} aria-pressed={selected} onClick={onClick}>
            <span className={cl("stat-head")}><Icon />{label}</span>
            <span className={cl("stat-value")}>{value}</span>
            {children}
        </button>
    );
}

interface PluginStatsProps {
    enabled: number;
    total: number;
    fresh: number;
    status: SearchStatus;
    onSelect(status: SearchStatus): void;
}

/** Clicking a count filters the list down to those plugins */
function PluginStats({ enabled, total, fresh, status, onSelect }: PluginStatsProps) {
    const { t } = useI18n();

    return (
        <div className={cl("stats")}>
            <StatTile Icon={PowerIcon} label={t("Enabled")} value={enabled} tone="on" wide selected={status === SearchStatus.ENABLED} onClick={() => onSelect(SearchStatus.ENABLED)}>
                <span className="ec-pixel-meter"><span style={{ width: `${enabled / total * 100}%` }} /></span>
            </StatTile>
            <StatTile Icon={SleepIcon} label={t("Disabled")} value={total - enabled} selected={status === SearchStatus.DISABLED} onClick={() => onSelect(SearchStatus.DISABLED)} />
            {fresh > 0 && <StatTile Icon={SparkleIcon} label={t("New")} value={fresh} selected={status === SearchStatus.NEW} onClick={() => onSelect(SearchStatus.NEW)} />}
            <StatTile Icon={AppsIcon} label={t("Total")} value={total} selected={false} onClick={() => onSelect(SearchStatus.ALL)} />
        </div>
    );
}

function EmptyBrand() { return <SolcordMark width={51} />; }

function ExcludedPluginsList({ search }: { search: string; }) {
    const { t } = useI18n();
    const matchingExcludedPlugins = search
        ? Object.entries(ExcludedPlugins)
            .filter(([name]) => name.toLowerCase().includes(search))
        : [];

    const ExcludedReasons: Record<"web" | "discordDesktop" | "solcordDesktop" | "desktop" | "dev", string> = {
        desktop: t("Discord Desktop app or Solcord Desktop"),
        discordDesktop: t("Discord Desktop app"),
        solcordDesktop: t("Solcord Desktop app"),
        web: t("Solcord Desktop app and the Web version of Discord"),
        dev: t("Developer version of Solcord")
    };

    return (
        <Paragraph className={Margins.top16}>
            {matchingExcludedPlugins.length
                ? <>
                    <Paragraph>{t("Are you looking for:")}</Paragraph>
                    <ul>
                        {matchingExcludedPlugins.map(([name, reason]) => (
                            <li key={name}>
                                <b>{name}</b>: {t("Only available on the {reason}", { reason: ExcludedReasons[reason] })}
                            </li>
                        ))}
                    </ul>
                </>
                : t("No plugins meet the search criteria.")
            }
        </Paragraph>
    );
}

/** The card that was just switched and where it was on screen, until the list re-renders */
let held: { card: Element; top: number; until: number; } | undefined;

/**
 * Keeps a card where it is through the re-render its switch causes. Turning a plugin on can add the restart card at
 * the top or move a helper plugin down to Required Plugins, which pushed everything below, the card under the
 * pointer included, by a card's height
 */
export function holdInPlace(card: Element | null) {
    held = card ? { card, top: card.getBoundingClientRect().top, until: Date.now() + 1000 } : undefined;
}

function scrollerOf(el: Element) {
    for (let node = el.parentElement; node; node = node.parentElement)
        if (node.scrollHeight > node.clientHeight && /auto|scroll/.test(getComputedStyle(node).overflowY)) return node;
}

function PluginSettings() {
    const { t, tPluginDesc } = useI18n();
    const settings = useSettings();
    const [library, setLibrary] = useState(librarySnapshot());
    const [deepSearch, setDeepSearch] = useState(false);
    const [page, setPage] = useState(0);
    const [copyStatus, setCopyStatus] = useState("");
    const searchRoot = useRef<HTMLDivElement>(null);
    useEffect(() => { const stop = watchLibrary(() => setLibrary(librarySnapshot())); void loadLibrary(); return stop; }, []);
    const changeRef = useRef<ChangeList<string>>(null);
    const changes = changeRef.current ??= new ChangeList<string>();
    // Stable callback, so the memoised cards don't re-render
    const onRestartNeeded = useCallback((name: string, key: string) => changes.handleChange(`${name}.${key}`), []);

    useCleanupEffect(() => {
        if (changes.hasChanges)
            openModal(props => (
                <ConfirmModal
                    {...props}
                    title={t("Restart required")}
                    confirmText={t("Restart now")}
                    cancelText={t("Later")}
                    variant="primary"
                    onConfirm={() => location.reload()}
                >
                    <>
                        <p>{t("The following plugins require a restart:")}</p>
                        <div>{changes.map((s, i) => (
                            <>
                                {i > 0 && ", "}
                                {Parser.parse(`\`${s.split(".")[0]}\``)}
                            </>
                        ))}</div>
                    </>
                </ConfirmModal>
            ));
    }, []);

    // Plugins whose code isn't loaded are listed from what the build read of them (see ./listItems)
    const basePlugins = useMemo(() => Object.keys(Plugins).map(listItem), []);
    const sortedPlugins = useMemo(() =>
        [...basePlugins].sort((a, b) => {
            if (library.sort === "name") return a.name.localeCompare(b.name);
            if (library.sort === "favorites") { const rank = Number(library.favorites.includes(b.name)) - Number(library.favorites.includes(a.name)); if (rank) return rank; }
            if (library.sort === "recent") { const rank = (library.recent.indexOf(a.name) < 0 ? 1000 : library.recent.indexOf(a.name)) - (library.recent.indexOf(b.name) < 0 ? 1000 : library.recent.indexOf(b.name)); if (rank) return rank; }
            const rank = popularRank(a.name) - popularRank(b.name);
            return Number.isNaN(rank) || rank === 0 ? a.name.localeCompare(b.name) : rank;
        }),
        [basePlugins, library]
    );

    const depMap = useMemo(() => {
        const o = {} as Record<string, string[]>;
        for (const plugin of sortedPlugins) {
            for (const dep of plugin.dependencies ?? []) {
                o[dep] ??= [];
                o[dep].push(plugin.name);
            }
        }
        return o;
    }, []);

    const enabledCount = useMemo(() => sortedPlugins.filter(p => isPluginEnabled(p.name)).length, [settings]);

    const hasUserPlugins = useMemo(() => !IS_STANDALONE && Object.values(PluginMeta).some(m => m.userPlugin), []);

    const [searchValue, setSearchValue] = useState({ value: "", tags: [] as PluginTag[], status: SearchStatus.ALL });

    const search = searchValue.value.toLowerCase();
    const onSearch = (query: string) => {
        setSearchValue(prev => ({ ...prev, value: query }));
        const word = query.trim().toLowerCase();
        if (word === "solcord") peek(t("Welcome to Solcord"));
    };
    const onStatSelect = (status: SearchStatus) => setSearchValue(prev => ({ ...prev, status: prev.status === status ? SearchStatus.ALL : status }));
    const isFiltering = search.length > 0 || searchValue.tags.length > 0 || searchValue.status !== SearchStatus.ALL;
    const resetFilters = () => { setSearchValue({ value: "", tags: [], status: SearchStatus.ALL }); setDeepSearch(false); setPage(0); };
    useEffect(() => setPage(0), [searchValue.value, searchValue.status, searchValue.tags, library.sort, library.pageSize]);
    useEffect(() => {
        const key = (event: KeyboardEvent) => {
            if ((event.ctrlKey || event.metaKey) && !event.altKey && event.key.toLowerCase() === "f") { event.preventDefault(); searchRoot.current?.querySelector("input")?.focus(); }
            else if (event.key === "Escape" && searchRoot.current?.contains(document.activeElement)) { setSearchValue(value => ({ ...value, value: "" })); }
        };
        window.addEventListener("keydown", key); return () => window.removeEventListener("keydown", key);
    }, []);

    // From 3 characters on, setting names match too ("volume" finds plugins with a volume setting)
    const settingHits = useMemo(() => {
        const hits = new Map<string, SettingEntry[]>();
        if (!deepSearch || search.trim().length < 3) return hits;

        for (const entry of searchSettings(search)) {
            const list = hits.get(entry.plugin.name);
            if (list) list.push(entry);
            else hits.set(entry.plugin.name, [entry]);
        }
        return hits;
    }, [search, deepSearch]);

    const pluginFilter = (plugin: typeof Plugins[keyof typeof Plugins]) => {
        const { status, tags } = searchValue;

        switch (status) {
            case SearchStatus.FAVORITES:
                if (!library.favorites.includes(plugin.name)) return false;
                break;
            case SearchStatus.RECENT:
                if (!library.recent.includes(plugin.name)) return false;
                break;
            case SearchStatus.DISABLED:
                if (isPluginEnabled(plugin.name)) return false;
                break;
            case SearchStatus.ENABLED:
                if (!isPluginEnabled(plugin.name)) return false;
                break;
            case SearchStatus.NEW:
                if (!newPlugins?.includes(plugin.name)) return false;
                break;
            case SearchStatus.USER_PLUGINS:
                if (!PluginMeta[plugin.name]?.userPlugin) return false;
                break;
            case SearchStatus.API_PLUGINS:
                if (!plugin.name.endsWith("API")) return false;
                break;
        }

        if (tags.length && tags.some(t => !plugin.tags?.includes(t))) return false;

        if (!search.length) return true;

        return (
            plugin.name.toLowerCase().includes(search) ||
            plugin.name.match(/[A-Z]/g)?.join("").toLowerCase().includes(search) || // acronyms like BF for BetterFolders
            plugin.description.toLowerCase().includes(search) ||
            tPluginDesc(plugin.name, plugin.description).toLowerCase().includes(search) ||
            plugin.searchTerms?.some(t => t.toLowerCase().includes(search)) ||
            matchesIntent(plugin.name, plugin.description, plugin.searchTerms, search) ||
            settingHits.has(plugin.name)
        );
    };

    const [newPlugins] = useAwaiter(() => DataStore.get("Solcord_existingPlugins").then((cachedPlugins: Record<string, number> | undefined) => {
        const now = Date.now() / 1000;
        const existingTimestamps: Record<string, number> = {};
        const sortedPluginNames = Object.values(sortedPlugins).map(plugin => plugin.name);

        const newPlugins: string[] = [];
        for (const { name: p } of sortedPlugins) {
            const time = existingTimestamps[p] = cachedPlugins?.[p] ?? now;
            if ((time + 60 * 60 * 24 * 2) > now) {
                newPlugins.push(p);
            }
        }
        DataStore.set("Solcord_existingPlugins", existingTimestamps);

        return lodash.isEqual(newPlugins, sortedPluginNames) ? [] : newPlugins;
    }));

    const plugins = [] as JSX.Element[];
    const requiredPlugins = [] as JSX.Element[];
    const visibleNames: string[] = [];

    const showApi = searchValue.status === SearchStatus.API_PLUGINS;
    for (const p of sortedPlugins) {
        if (p.hidden || (!showApi && !isListedPlugin(p)))
            continue;

        if (!pluginFilter(p)) continue;
        visibleNames.push(p.name);

        const isRequired = p.required || p.isDependency || depMap[p.name]?.some(d => settings.plugins[d].enabled);

        if (isRequired) {
            const tooltipText = p.required || !depMap[p.name]
                ? t("This plugin is required for Solcord to function.")
                : makeDependencyList(depMap[p.name]?.filter(d => settings.plugins[d].enabled));

            requiredPlugins.push(
                <Tooltip text={tooltipText} key={p.name}>
                    {({ onMouseLeave, onMouseEnter }) => (
                        <PluginCard
                            onMouseLeave={onMouseLeave}
                            onMouseEnter={onMouseEnter}
                            onRestartNeeded={onRestartNeeded}
                            disabled={true}
                            plugin={p}
                            favorite={library.favorites.includes(p.name)}
                            key={p.name}
                        />
                    )}
                </Tooltip>
            );
        } else {
            plugins.push(
                <PluginCard
                    onRestartNeeded={onRestartNeeded}
                    disabled={false}
                    plugin={p}
                    favorite={library.favorites.includes(p.name)}
                    isNew={newPlugins?.includes(p.name)}
                    isPopular={POPULAR_PLUGINS.has(p.name)}
                    matchedSettings={settingHits.get(p.name)}
                    key={p.name}
                />
            );
        }
    }

    // Before paint, so the shift never shows. Where the browser's own scroll anchoring already kept it, this finds 0
    useLayoutEffect(() => {
        const hold = held;
        if (!hold || Date.now() > hold.until) return;
        held = undefined;
        const shift = hold.card.isConnected ? hold.card.getBoundingClientRect().top - hold.top : 0;
        const scroller = Math.abs(shift) >= 1 && scrollerOf(hold.card);
        if (scroller) scroller.scrollTop += shift;
    });

    const pages = Math.max(1, Math.ceil(plugins.length / library.pageSize)), shownPage = Math.min(page, pages - 1);
    const pager = <div className="sc-library-pager"><button disabled={shownPage === 0} onClick={() => setPage(shownPage - 1)}>Previous</button><span>Page {shownPage + 1} of {pages}</span><button disabled={shownPage + 1 >= pages} onClick={() => setPage(shownPage + 1)}>Next</button></div>;

    return (
        <SettingsTab>
            {IS_SAFE_MODE && <SafeModeCard />}
            {changes.hasChanges && <ReloadRequiredCard />}

            <PluginStats
                enabled={enabledCount}
                total={sortedPlugins.length}
                fresh={newPlugins?.length ?? 0}
                status={searchValue.status}
                onSelect={onStatSelect}
            />

            <ProfilesBar onRestartNeeded={() => changes.handleChange(`${t("Profile")}.plugins`)} />

            <UIElementsButton />

            <ErrorBoundary noop>
                <div className={Margins.top16} ref={searchRoot}>
                    <TextInput
                        inputClassName={cl("filter-control")}
                        placeholder="Search names, descriptions, or what you want to do…"
                        value={searchValue.value}
                        onChange={onSearch}
                        autoFocus
                    />
                </div>
            </ErrorBoundary>

            <div className="sc-library-tools">
                <button aria-pressed={searchValue.status === SearchStatus.FAVORITES} onClick={() => onStatSelect(SearchStatus.FAVORITES)}>Favorites ({library.favorites.length})</button>
                <button aria-pressed={searchValue.status === SearchStatus.RECENT} onClick={() => onStatSelect(SearchStatus.RECENT)}>Recently opened</button>
                <button disabled={!isFiltering && !deepSearch} onClick={resetFilters}>Clear filters</button>
                <label>Sort<select value={library.sort} onChange={event => { const sort = event.currentTarget.value as LibrarySort; editLibrary(value => ({ ...value, sort })); }}><option value="popular">Popular first</option><option value="name">A–Z</option><option value="favorites">Favorites first</option><option value="recent">Recently opened</option></select></label>
                <label>Per page<select value={library.pageSize} onChange={event => { const pageSize = Number(event.currentTarget.value); editLibrary(value => ({ ...value, pageSize })); }}>{[30, 60, 90].map(count => <option key={count} value={count}>{count}</option>)}</select></label>
            </div>
            <label className="sc-library-deep"><input type="checkbox" checked={deepSearch} onChange={event => setDeepSearch(event.currentTarget.checked)} />Include individual settings in search (slower)</label>

            <ErrorBoundary noop>
                <div className={classes(Margins.bottom20, Margins.top8, cl("filter-controls"))}>
                    <Select
                        options={[
                            { label: t("Show All"), value: SearchStatus.ALL, default: true },
                            { label: t("Show Enabled"), value: SearchStatus.ENABLED },
                            { label: t("Show Disabled"), value: SearchStatus.DISABLED },
                            { label: t("Show New"), value: SearchStatus.NEW },
                            { label: "Favorites", value: SearchStatus.FAVORITES },
                            { label: "Recently opened", value: SearchStatus.RECENT },
                            hasUserPlugins && { label: t("Show UserPlugins"), value: SearchStatus.USER_PLUGINS },
                            { label: t("Show API Plugins"), value: SearchStatus.API_PLUGINS },
                        ].filter(isTruthy)}
                        serialize={String}
                        select={status => setSearchValue(prev => ({ ...prev, status }))}
                        isSelected={v => v === searchValue.status}
                        closeOnSelect={true}
                        placeholder={t("Filter by Type")}
                    />
                    <SearchableSelect
                        options={PluginTags.map(tag => ({ label: t(tag), value: tag }))}
                        value={searchValue.tags}
                        onChange={tags => setSearchValue(prev => ({ ...prev, tags }))}
                        closeOnSelect={false}
                        placeholder={t("Filter by Tags")}
                        multi
                    />
                </div>
            </ErrorBoundary>

            <div className={classes(Margins.top20, cl("list-heading"))}>
                <HeadingTertiary>{t("Plugins")}</HeadingTertiary>
                <span className={cl("count")}>{t("{count} shown", { count: plugins.length + requiredPlugins.length })}</span>
                <button className="sc-library-copy" onClick={async () => { try { await navigator.clipboard.writeText(`Solcord ${VERSION}\n${visibleNames.map(name => `${isPluginEnabled(name) ? "[on]" : "[off]"} ${name}`).join("\n")}`); setCopyStatus("Copied plugin names and enabled states."); } catch { setCopyStatus("Could not copy the list."); } }}>Copy this list</button>
            </div>
            {copyStatus && <p role="status">{copyStatus}</p>}
            {plugins.length > library.pageSize && pager}

            {plugins.length || requiredPlugins.length
                ? (
                    <div className={cl("grid")}>
                        {plugins.length
                            ? plugins.slice(shownPage * library.pageSize, (shownPage + 1) * library.pageSize)
                            : <Paragraph>{t("No plugins meet the search criteria.")}</Paragraph>
                        }
                    </div>
                )
                : (
                    <div className={cl("empty")}>
                        <EmptyBrand />
                        <ExcludedPluginsList search={search} />
                        {isFiltering && <button onClick={resetFilters}>Show all plugins</button>}
                    </div>
                )
            }
            {plugins.length > library.pageSize && pager}


            <Divider className={Margins.top20} />

            <HeadingTertiary className={classes(Margins.top20, Margins.bottom8)}>
                {t("Required Plugins")}
            </HeadingTertiary>

            <div className={cl("grid")}>
                {requiredPlugins.length
                    ? requiredPlugins
                    : <Paragraph>{t("No plugins meet the search criteria.")}</Paragraph>
                }
            </div>
        </SettingsTab >
    );
}

function makeDependencyList(deps: string[]) {
    return (
        <>
            <Paragraph>{t("This plugin is required by:")}</Paragraph>
            {deps.map((dep: string) => <Paragraph key={dep} className={cl("dep-text")}>{dep}</Paragraph>)}
        </>
    );
}

export default wrapTab(PluginSettings, "Plugins");


export function PluginDependencyList({ deps }: { deps: string[]; }) {
    const { t } = useI18n();
    return (
        <>
            <Paragraph>{t("This plugin is required by:")}</Paragraph>
            {deps.map((dep: string) => <Paragraph key={dep} className={cl("dep-text")}>{dep}</Paragraph>)}
        </>
    );
}
