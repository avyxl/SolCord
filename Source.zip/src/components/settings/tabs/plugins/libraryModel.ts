/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

export type LibrarySort = "popular" | "name" | "favorites" | "recent";
export interface LibraryPreferences { favorites: string[]; recent: string[]; sort: LibrarySort; pageSize: number; }
export const DEFAULT_LIBRARY: LibraryPreferences = { favorites: [], recent: [], sort: "popular", pageSize: 60 };
const safeNames = (value: unknown, max: number) => Array.isArray(value) ? [...new Set(value.filter((name): name is string => typeof name === "string" && name.length > 0 && name.length <= 100))].slice(0, max) : [];
export function cleanLibrary(value: unknown): LibraryPreferences {
    const data = value && typeof value === "object" ? value as Partial<LibraryPreferences> : {};
    return { favorites: safeNames(data.favorites, 100), recent: safeNames(data.recent, 60), sort: ["popular", "name", "favorites", "recent"].includes(data.sort || "") ? data.sort! : "popular", pageSize: [30, 60, 90].includes(data.pageSize || 0) ? data.pageSize! : 60 };
}
export function favoriteNames(current: string[], name: string) { return current.includes(name) ? current.filter(value => value !== name) : [name, ...current].slice(0, 100); }
export function recentNames(current: string[], name: string) { return [name, ...current.filter(value => value !== name)].slice(0, 60); }
const aliases: Record<string, string> = {
    SolcordBot: "clean dm chat history purge delete own messages commands prefix",
    CustomBadge: "upload image png jpg custom profile badges",
    OwnerBadge: "redeem key owner developer contributor staff profile badges",
    CustomProfile: "custom fake profile avatar banner shared bio",
    FakeProfileThemes: "profile theme gradient colors colours",
    VolumeBooster: "louder quiet volume sound audio",
    BetterFolders: "organize server folders",
    QuickDelete: "delete last own message shortcut",
    ThemeLibrary: "themes appearance background colors colours"
};
const normal = (text: string) => text.replace(/([a-z])([A-Z])/g, "$1 $2").normalize("NFKD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
const synonyms: Record<string, string> = { msgs: "message", messages: "message", dms: "dm", my: "own", colours: "color", colors: "color" };
export function matchesIntent(name: string, description: string, terms: readonly string[] | undefined, query: string) {
    const words = normal(query).split(/\s+/).filter(Boolean).map(word => synonyms[word] || word);
    const haystack = normal([name, description, ...(terms || []), aliases[name] || ""].join(" "));
    return words.length > 0 && words.every(word => haystack.includes(word));
}
export function requirementLabels(name: string): string[] {
    const labels: Record<string, string[]> = { SolcordBot: ["Activation key"], OwnerBadge: ["Staff key", "Solcord community"], CustomBadge: ["Solcord community"], GpuBinder: ["Windows only"], AppleMusicRichPresence: ["macOS Music app"], XSOverlay: ["XSOverlay required"] };
    return labels[name] || [];
}
