/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import * as DataStore from "@api/DataStore";

import { cleanLibrary, DEFAULT_LIBRARY, favoriteNames, LibraryPreferences, recentNames } from "./libraryModel";

const key = "Solcord_pluginLibrary_v1";
let current: LibraryPreferences = { ...DEFAULT_LIBRARY }, loaded: Promise<void> | undefined;
let writes = Promise.resolve();
const listeners = new Set<() => void>();
export const librarySnapshot = () => current;
export function watchLibrary(listener: () => void) { listeners.add(listener); return () => { listeners.delete(listener); }; }
export function loadLibrary() {
    return loaded ??= DataStore.get(key).then(value => { current = cleanLibrary(value); for (const fn of listeners) fn(); }).catch(() => {});
}
export function editLibrary(edit: (value: LibraryPreferences) => LibraryPreferences) {
    void loadLibrary().then(() => {
        current = cleanLibrary(edit(current));
        for (const fn of listeners) fn();
        const snapshot = current;
        writes = writes.catch(() => {}).then(() => DataStore.set(key, snapshot)).catch(() => {});
    });
}
export const toggleFavorite = (name: string) => editLibrary(value => ({ ...value, favorites: favoriteNames(value.favorites, name) }));
export const recordPluginVisit = (name: string) => editLibrary(value => ({ ...value, recent: recentNames(value.recent, name) }));
