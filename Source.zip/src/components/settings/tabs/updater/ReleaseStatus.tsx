/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { Card } from "@components/Card";
import type { UpdateTrust } from "@main/updater/common";
import { useEffect, useState } from "@webpack/common";

import gitHash from "~git-hash";

export function ReleaseStatus() {
    const [trust, setTrust] = useState<UpdateTrust | null>(null);
    const [copied, setCopied] = useState("");
    useEffect(() => {
        let active = true;
        const refresh = () => { void SolcordNative.updater.getTrust().then(value => { if (active) setTrust(value); }).catch(() => {}); };
        refresh(); window.addEventListener("solcord:update-status", refresh);
        return () => { active = false; window.removeEventListener("solcord:update-status", refresh); };
    }, []);
    return <Card style={{ padding: 16, marginBottom: 20 }}>
        <h3 style={{ marginBottom: 8 }}>Installed: Solcord {VERSION}</h3>
        <p>Build <code>{gitHash}</code></p>
        <p>{trust?.pending ? "An update is downloaded. Restart Discord to load the new version." : "This is the version currently running in Discord."}</p>
        <p>{trust?.checkedAt ? `Last checked: ${new Date(trust.checkedAt).toLocaleString()}` : "No update check has completed yet."}</p>
        <p>{trust?.signed ? "The update feed has a valid signature." : "The update feed has not been verified yet."}</p>
        {trust?.rejected && <p>The previous update failed to start and was rolled back. Check for a newer release.</p>}
        <button className="sc-library-copy" onClick={async () => {
            try { await navigator.clipboard.writeText(`Solcord ${VERSION}\nBuild: ${gitHash}\nUpdate signature: ${trust?.signed ? "verified" : "not verified"}\nRestart required: ${!!trust?.pending}`); setCopied("Version information copied."); }
            catch { setCopied("Could not copy version information."); }
        }}>Copy version information</button>
        {copied && <p role="status">{copied}</p>}
    </Card>;
}
