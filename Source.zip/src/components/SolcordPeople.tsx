/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { SOLCORD_PEOPLE } from "@shared/solcordPeople";
export function SolcordPeople({ authorOnly = false }: { authorOnly?: boolean; }) {
    return <div className="sc-people">{SOLCORD_PEOPLE.slice(0, authorOnly ? 1 : 2).map(person => {
        const card = <><img src={person.avatar} alt="" width={48} height={48} loading="lazy" decoding="async" /><span><strong>{person.name}</strong><small>{person.role}</small></span></>;
        return "url" in person ? <a key={person.name} href={person.url} target="_blank" rel="noopener noreferrer">{card}</a> : <div key={person.name}>{card}</div>;
    })}</div>;
}
