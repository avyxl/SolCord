/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import "./styles.css?screen";

import { showNotice } from "@api/Notices";
import { bootState, getPluginsChangedSinceGoodStart } from "@api/SafeMode";
import { Settings } from "@api/Settings";
import { SolcordModal } from "@components/SolcordModal";
import { PluginPickList } from "@components/settings/PluginPickList";
import { RenderModalProps } from "@solcord/discord-types";
import { classNameFactory } from "@utils/css";
import { t, useI18n } from "@utils/i18n";
import { relaunch } from "@utils/native";
import { openModal, useState } from "@webpack/common";

import Plugins from "~plugins";

const cl = classNameFactory("ec-safe-");

function SafeModeModal({ onClose, transitionState }: RenderModalProps) {
    const { t } = useI18n();

    // Blame the plugins in the crash's stack first, otherwise whatever was enabled since the last good start
    const fromCrash = bootState.suspects.filter(name => name in Plugins && Settings.plugins[name]?.enabled);
    const candidates = fromCrash.length ? fromCrash : getPluginsChangedSinceGoodStart().filter(name => name in Plugins);
    const [keepOn, setKeepOn] = useState(() => new Set<string>());

    const restart = () => {
        for (const name of candidates) Settings.plugins[name].enabled = keepOn.has(name);
        relaunch();
    };

    const offCount = candidates.length - keepOn.size;

    return (
        <SolcordModal
            transitionState={transitionState}
            onClose={onClose}
            size="md"
            title={t("Solcord started in safe mode")}
            subtitle={bootState.reason === "manual"
                ? t("As you asked, Solcord started with its plugins, themes and Custom CSS off. Nothing was changed: everything comes back when you restart.")
                : t("Discord didn't finish starting {count} times in a row, so this time Solcord started with its plugins, themes and Custom CSS off. Nothing was changed.", { count: bootState.failedStarts })}
            actions={bootState.reason === "manual" || !candidates.length
                ? [
                    { text: t("Stay in safe mode"), variant: "secondary", onClick: onClose },
                    { text: t("Restart normally"), variant: "primary", onClick: relaunch }
                ]
                : [
                    { text: t("Stay in safe mode"), variant: "secondary", onClick: onClose },
                    { text: offCount ? t("Turn off {count} and restart", { count: offCount }) : t("Restart normally"), variant: "primary", onClick: restart }
                ]}
        >
            {bootState.reason === "crashes" && (candidates.length
                ? (
                    <section className={cl("section")}>
                        <h3 className={cl("heading")}>
                            {fromCrash.length ? t("These plugins changed the part of Discord that crashed") : t("These plugins were turned on since Discord last started fine")}
                        </h3>
                        <p className={cl("hint")}>{t("They're set to stay off. Switch back on any you're sure about.")}</p>
                        <PluginPickList
                            names={candidates}
                            isOn={name => keepOn.has(name)}
                            onChange={(name, on) => setKeepOn(prev => {
                                const next = new Set(prev);
                                on ? next.add(name) : next.delete(name);
                                return next;
                            })}
                        />
                    </section>
                )
                : (
                    <p className={cl("hint")}>
                        {t("Solcord couldn't tell which plugin it was. Turn off the ones you added most recently in the Plugins tab, then restart.")}
                    </p>
                )
            )}
        </SolcordModal>
    );
}

/** Safe mode notice with the way back out. Shown once Discord's UI is up */
export function showSafeModeScreen() {
    showNotice(t("Safe mode: Solcord's plugins, themes and Custom CSS are off until you restart."), t("Restart normally"), relaunch);
    openModal(props => <SafeModeModal {...props} />);
}
