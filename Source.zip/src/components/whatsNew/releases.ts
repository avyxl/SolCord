/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { AppsIcon, ShieldCheckIcon, SlidersIcon, SolcordMark } from "@components/SolcordIcons";
import { IMPLEMENTED, PARTIAL } from "@solcord3/availability";
import type { IconProps } from "@utils/types";
import type { ComponentType } from "react";

export interface Release {
    version: string;
    summary: string;
    highlights: {
        Icon: ComponentType<IconProps>;
        title: string;
        description: string;
    }[];
}

/**
 * Newest first. Only big releases belong here: anything listed greets people with a card after they update,
 * so a bug fix release stays out, and whether a release gets one is decided when it ships.
 */
export const RELEASES: Release[] = [{
    version: "3.0.3",
    summary: "A faster plugin library, native Linux setup and a simpler way to publish signed updates.",
    highlights: [
        { Icon: AppsIcon, title: "Your plugin library", description: "Favorites, recently opened plugins, task search, saved sorting and bounded pages make the full library easier to use." },
        { Icon: SlidersIcon, title: "Less work while browsing", description: "Ordinary searches use lightweight metadata. Search through individual settings only when you choose to." },
        { Icon: SolcordMark, title: "Native Linux setup", description: "One executable installs, repairs or removes Solcord. A native launcher starts Discord without a resident helper, including supported Arch system-Electron packages." },
        { Icon: ShieldCheckIcon, title: "Clearer signed updates", description: "See the running version, signature status and pending restart in Updater. The new owner publisher releases compiled updates without rebuilding the project." }
    ]
}, {
    version: "3.0.2",
    summary: "SolcordBot adds key-activated commands to your existing Solcord client. The 3.0.2 installer updates 3.0.1 correctly.",
    highlights: [
        { Icon: AppsIcon, title: "SolcordBot commands", description: "Enable SolcordBot, redeem your key in its settings, then use ,sol help. Review and purge your own messages, check progress, copy links and IDs, and keep private notes." },
        { Icon: SlidersIcon, title: "Plugin workspaces open locally", description: "Fixed the failed dynamic import error. Plugin panels and their tools now load from the installed Solcord files instead of requesting JavaScript from discord.com." },
        { Icon: AppsIcon, title: "New tools and utilities", description: `${IMPLEMENTED.size} additions are implemented, with ${PARTIAL.size} more in progress. Planned entries are not enabled plugins.` },
        { Icon: SolcordMark, title: "Changelog, wherever you need it", description: "Open release notes from the top-right button, the control center, or Settings > Changelog." },
        { Icon: ShieldCheckIcon, title: "Local tools and explicit actions", description: "Selected text and files stay local in the new workspace. Nothing is sent automatically." },
        { Icon: SlidersIcon, title: "Optional by default", description: "Tool workspaces load when opened. Observers run only when their plugins are enabled. Model downloads are optional." }
    ]
}, {
    version: "2.4.0",
    summary: "More badge freedom and better shared-profile verification.",
    highlights: [
        { Icon: AppsIcon, title: "Three staff badges together", description: "Show Owner, Developer, and Contributor together when they are unlocked." },
        { Icon: SolcordMark, title: "Two custom badge slots", description: "Keep two image badges alongside staff badges." },
        { Icon: ShieldCheckIcon, title: "Profile verification fixes", description: "Profile updates preserve verified staff badges and refresh cached verification." },
        { Icon: SlidersIcon, title: "Discord-style startup", description: "The normal Discord loading flow uses the Solcord logo and developed by avyxl text, without the music intro." }
    ]
}, {
    version: "2.0.0",
    summary: "A clearer view and a proper Solcord entrance.",
    highlights: [
        { Icon: SlidersIcon, title: "Your chat palette", description: "Switch Solcord chat colors on or off without changing the settings UI." },
        { Icon: SolcordMark, title: "Welcome to Solcord", description: "Your spinning logo and soundtrack at startup, with music controls and Skip." },
        { Icon: ShieldCheckIcon, title: "Light profiles, readable text", description: "Light surfaces keep their own contrast." },
        { Icon: AppsIcon, title: "Session Desk", description: "Expiring scratch capsules and a timed quiet layout." }
    ]
}];
