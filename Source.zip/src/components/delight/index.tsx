/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { showToast, Toasts } from "@webpack/common";

/** Small explicit feedback for settings actions. No idle or keyboard-triggered effects. */
export function peek(text: string, time = 3200) {
    showToast(text, Toasts.Type.MESSAGE, { duration: time });
}
export function boop() { peek("Solcord"); }
export function tapVersion() { peek(`Solcord v${VERSION}`); }
