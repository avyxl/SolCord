/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { randomUUID } from "crypto";
interface ClipboardAdapter { write(data: { text: string; html: string }): void; readText(): string; readHTML(): string; clear(): void; }
/** Never clears a later copy, even when its plain text is identical. */
export class ExpiringClipboard {
    private jobs = new Map<number, { token: string; text: string; html: string; expiresAt: number; timer: ReturnType<typeof setTimeout> }>();
    constructor(private clipboard: ClipboardAdapter) {}
    copy(owner: number, text: string, seconds: number) {
        if (typeof text !== "string" || !text || text.length > 16000) throw new Error("Enter 1–16,000 characters.");
        if (!Number.isInteger(seconds) || seconds < 5 || seconds > 600) throw new Error("Choose an expiry from 5 to 600 seconds.");
        if (!this.jobs.has(owner) && this.jobs.size >= 32) throw new Error("Too many temporary clipboard sessions.");
        this.cancel(owner);
        const token = randomUUID();
        const escaped = text.replace(/[&<>"']/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]!);
        this.clipboard.write({ text, html: '<meta name="solcord-expiry" content="' + token + '"><pre>' + escaped + '</pre>' });
        const html = this.clipboard.readHTML();
        if (!html.includes(token) || this.clipboard.readText() !== text) throw new Error("The clipboard did not retain its expiry marker. The content was not scheduled for clearing.");
        const expiresAt = Date.now() + seconds * 1000;
        const timer = setTimeout(() => { try { this.expire(owner, token); } catch { this.cancel(owner); } }, seconds * 1000);
        timer.unref?.();
        this.jobs.set(owner, { token, text, html, expiresAt, timer });
        return { token, expiresAt };
    }
    expire(owner: number, token: string) {
        const job = this.jobs.get(owner);
        if (!job || job.token !== token) return false;
        this.cancel(owner);
        if (this.clipboard.readText() !== job.text || this.clipboard.readHTML() !== job.html) return false;
        this.clipboard.clear(); return true;
    }
    cancel(owner: number) {
        const job = this.jobs.get(owner);
        if (job) { clearTimeout(job.timer); this.jobs.delete(owner); }
    }
}
