/*
 * Solcord, a Discord client mod
 * Copyright (c) 2025 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { NativeSettings } from "@main/settings";
import { session } from "electron";

type PolicyMap = Record<string, string[]>;

export const ConnectSrc = ["connect-src"];
export const ImageSrc = [...ConnectSrc, "img-src"];
export const CssSrc = ["style-src", "font-src"];
export const ImageAndCssSrc = [...ImageSrc, ...CssSrc];
export const ImageAndMediaSrc = [...ImageSrc, "media-src"];
export const ScriptSrc = ["script-src", "worker-src"];
// A theme needs styles, fonts and images, never connect-src: that directive is what would let code injected into
// the page send data out, so hosts that only ever serve themes don't get it
export const ThemeSrc = ["style-src", "font-src", "img-src"];
const ImageOnly = ["img-src"];
const FrameOnly = ["frame-src"];

// Plugins can whitelist their own domains by importing this object in their native.ts
// script and just adding to it. But generally, you should just edit this file instead

export const CspPolicies: PolicyMap = {
    // For working on a theme with a local server. No connect-src, so page code can't reach other local services
    "http://localhost:*": ThemeSrc,
    "http://127.0.0.1:*": ThemeSrc,
    "localhost:*": ThemeSrc,
    "127.0.0.1:*": ThemeSrc,

    "*.github.io": ThemeSrc, // GitHub pages, used by most themes
    // GitHub content and raw files: used by most themes, and for the sounds of Moyai, KeyboardSounds, Jumpscare,
    // WaitForSlot and WebcamStartNotifier (github.com/.../raw/... redirects to raw.githubusercontent.com).
    // Plugins like ClearURLs, Animalese and the Control Center's version check fetch from here too
    "github.com": [...ImageAndCssSrc, "media-src"],
    "raw.githubusercontent.com": [...ImageAndCssSrc, "media-src"],
    "*.gitlab.io": ThemeSrc, // GitLab pages, used by some themes
    "gitlab.com": ThemeSrc, // GitLab raw, used by some themes
    "*.codeberg.page": ThemeSrc, // Codeberg pages, used by some themes
    "codeberg.org": ThemeSrc, // Codeberg raw, used by some themes

    "*.githack.com": ThemeSrc, // githack (namely raw.githack.com), used by some themes
    "jsdelivr.net": ThemeSrc, // jsDelivr, used by very few themes

    "fonts.googleapis.com": ImageAndCssSrc, // Google Fonts, used by many themes; FontLoader and GifMaker also fetch the CSS

    "i.imgur.com": ImageOnly, // Imgur, used by some themes
    "i.ibb.co": ImageOnly, // ImgBB, used by some themes
    "i.pinimg.com": ImageOnly, // Pinterest, used by some themes
    "*.tenor.com": ImageAndMediaSrc, // Tenor: themes, GifProviderSwitcher search and previews
    "files.catbox.moe": ThemeSrc, // Catbox, used by some themes

    "cdn.discordapp.com": ImageAndCssSrc, // Discord CDN, used by Solcord and some themes to load media
    "media.discordapp.net": ImageSrc, // Discord media CDN, possible alternative to Discord CDN

    // CDNs used for some things by Solcord.
    // FIXME: we really should not be using CDNs anymore
    "cdnjs.cloudflare.com": ImageAndCssSrc,
    "cdn.jsdelivr.net": ImageAndCssSrc,

    // Discord's script nonce stops injected scripts, and these CDNs host anyone's code,
    // so only the exact packages Solcord runs may execute from them
    "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/": ScriptSrc, // PdfViewer
    "https://cdn.jsdelivr.net/npm/tesseract.js@7.0.0/": [...ScriptSrc, ...ConnectSrc], // Optional Solcord OCR
    "https://cdn.jsdelivr.net/npm/tesseract.js-core@7.0.0/": [...ScriptSrc, ...ConnectSrc],
    "https://cdn.jsdelivr.net/npm/@tesseract.js-data/eng@1.0.0/": ConnectSrc,
    "https://cdn.jsdelivr.net/npm/@tesseract.js-data/ara@1.0.0/": ConnectSrc,
    "https://cdn.jsdelivr.net/npm/@tesseract.js-data/heb@1.0.0/": ConnectSrc,
    "https://cdn.jsdelivr.net/npm/heic-to@1.6.7/dist/next/": [...ScriptSrc, ...ConnectSrc], // Optional HEIC decoder
    "https://cdn.jsdelivr.net/npm/@ffmpeg/core@0.12.6/": ScriptSrc, // ClipUpload, FileUpload, MoreStickers
    "https://cdn.jsdelivr.net/npm/@huggingface/transformers@4.3.0/": ScriptSrc, // VoiceMessageTranscriber
    "https://cdn.jsdelivr.net/npm/onnxruntime-web@1.31.0-dev.20260914-8d85527a0/": ScriptSrc, // VoiceMessageTranscriber
    "https://cdn.jsdelivr.net/npm/@vap/shiki-worker@0.0.8/": ScriptSrc, // ShikiCodeblocks
    "https://cdn.jsdelivr.net/npm/stegcloak-dist@1.0.0/": ScriptSrc, // InvisibleChat
    "https://cdn.jsdelivr.net/npm/jsqr@1.4.0/": ScriptSrc, // LoginWithQR, loaded when a QR code is read

    // The online viewers FileViewer opens a file in, as a frame only: nothing else may load from them
    "https://drive.google.com/viewerng/": FrameOnly,
    "https://view.officeapps.live.com/op/": FrameOnly,
    "https://www.viewstl.com": FrameOnly,
    "https://embed.tidal.com/": FrameOnly, // TidalEmbeds' player; Discord's own frame-src doesn't have it

    // Function Specific
    "https://solcord-presence.adammohamedali01.workers.dev": ImageSrc, // Installation count, linked profiles, and custom badge images
    "api.github.com": ConnectSrc, // used for updating Solcord itself
    "ws.audioscrobbler.com": ConnectSrc, // Last.fm API
    "translate-pa.googleapis.com": ConnectSrc, // Google Translate API
    "translate.googleapis.com": ConnectSrc, // Google Translate romanization used by MusicControls lyrics
    "*.solcord.com": ImageSrc, // Solcord-hosted images
    "solcord.com": ConnectSrc, // Cloud settings sync (off by default); *.solcord.com does not cover the apex host
    "manti.vendicated.dev": ImageSrc, // ReviewDB API
    "decor.fieryflames.dev": ConnectSrc, // Decor API
    "ugc.decor.fieryflames.dev": ImageSrc, // Decor CDN
    "sponsor.ajay.app": ConnectSrc, // Dearrow API
    "dearrow-thumb.ajay.app": ImageSrc, // Dearrow Thumbnail CDN
    "usrbg.is-hardly.online": ImageSrc, // USRBG API
    "icons.duckduckgo.com": ImageSrc, // DuckDuckGo Favicon API (Reverse Image Search)

    "themes.equicord.org": ImageAndCssSrc, // Theme Library API, previews, and online theme CSS

    // APIs that bundled plugins call from the renderer; without these the requests fail with "Failed to fetch"
    "badges.equicord.org": ConnectSrc, // GlobalBadges
    "timezone.creations.works": ConnectSrc, // Timezones
    // No open CORS proxy: one in connect-src is a door to every host. FileUpload, MoreStickers and GifMaker
    // fetch through their native.ts on desktop, and the browser build has no CSP to get past
    "lrclib.net": ConnectSrc, // MusicControls lyrics
    "spotify-lyrics-api-pi.vercel.app": ConnectSrc, // MusicControls lyrics
    "api.thecatapi.com": ConnectSrc, // MoreCommands
    "api.thedogapi.com": ConnectSrc, // MoreCommands
    "nekos.best": ConnectSrc, // MoreCommands
    "www.reddit.com": ConnectSrc, // MoreCommands
    "*.wikipedia.org": ConnectSrc, // WikiLookup
    "free.freeipapi.com": ConnectSrc, // VoiceServerInfo
    "huggingface.co": ConnectSrc, // VoiceMessageTranscriber model download
    "*.huggingface.co": ConnectSrc,
    "*.hf.co": ConnectSrc,
    "api.stats.fm": ConnectSrc, // RichPresence
    "dc.songspotlight.nexpid.xyz": ConnectSrc, // SongSpotlight
    "api.imgur.com": ConnectSrc, // ChannelWallpaper uploads
    "api.openai.com": ConnectSrc, // ChatGPT (user-supplied key)
    "placeholder.nin0.dev": ImageSrc, // FavoriteAnything placeholders
    "userpfp.github.io": ConnectSrc, // UserPFP's list of avatars
    "*.tenor.co": ImageAndMediaSrc,
    "*.giphy.com": ImageAndMediaSrc,
    "*.listenbrainz.org": ConnectSrc, // MusicRichPresence
    "coverartarchive.org": ConnectSrc, // MusicRichPresence album art lookup
    "musicbrainz.org": ConnectSrc, // MusicRichPresence track lookup
    "fonts.google.com": ConnectSrc, // FontLoader and GifMaker font search
    "streaks.equicord.org": ConnectSrc, // Streaks API
    "archive.org": ConnectSrc,
    "*.archive.org": ConnectSrc,
};

const findHeader = (headers: PolicyMap, headerName: Lowercase<string>) => {
    return Object.keys(headers).find(h => h.toLowerCase() === headerName);
};

const parsePolicy = (policy: string): PolicyMap => {
    const result: PolicyMap = {};
    policy.split(";").forEach(directive => {
        const [directiveKey, ...directiveValue] = directive.trim().split(/\s+/g);
        if (directiveKey && !Object.prototype.hasOwnProperty.call(result, directiveKey)) {
            result[directiveKey] = directiveValue;
        }
    });

    return result;
};

const stringifyPolicy = (policy: PolicyMap): string =>
    Object.entries(policy)
        .filter(([, values]) => values?.length)
        .map(directive => directive.flat().join(" "))
        .join("; ");


const patchCsp = (headers: PolicyMap) => {
    const reportOnlyHeader = findHeader(headers, "content-security-policy-report-only");
    if (reportOnlyHeader)
        delete headers[reportOnlyHeader];

    const header = findHeader(headers, "content-security-policy");

    if (header) {
        const csp = parsePolicy(headers[header][0]);

        const pushDirective = (directive: string, ...values: string[]) => {
            csp[directive] ??= [...(csp["default-src"] ?? [])];
            csp[directive].push(...values);
        };

        pushDirective("style-src", "'unsafe-inline'");
        // we could make unsafe-inline safe by using strict-dynamic with a random nonce on our Solcord loader script https://content-security-policy.com/strict-dynamic/
        // HOWEVER, at the time of writing (24 Jan 2025), Discord is INSANE and also uses unsafe-inline
        // Once they stop using it, we also should
        pushDirective("script-src", "'unsafe-inline'", "'unsafe-eval'");

        for (const directive of ["style-src", "connect-src", "img-src", "font-src", "media-src", "worker-src"]) {
            pushDirective(directive, "blob:", "data:", "solcord:");
        }

        for (const [host, directives] of Object.entries(NativeSettings.store.customCspRules)) {
            for (const directive of directives) {
                pushDirective(directive, host);
            }
        }

        for (const [host, directives] of Object.entries(CspPolicies)) {
            for (const directive of directives) {
                pushDirective(directive, host);
            }
        }

        headers[header] = [stringifyPolicy(csp)];
    }
};

export function initCsp() {
    session.defaultSession.webRequest.onHeadersReceived(({ responseHeaders, resourceType }, cb) => {
        if (responseHeaders) {
            if (resourceType === "mainFrame")
                patchCsp(responseHeaders);

            // Fix hosts that don't properly set the css content type, such as
            // raw.githubusercontent.com
            if (resourceType === "stylesheet") {
                const header = findHeader(responseHeaders, "content-type");
                if (header)
                    responseHeaders[header] = ["text/css"];
            }
        }

        cb({ cancel: false, responseHeaders });
    });

    // assign a noop to onHeadersReceived to prevent other mods from adding their own incompatible ones.
    // For instance, OpenAsar adds their own that doesn't fix content-type for stylesheets which makes it
    // impossible to load css from github raw despite our fix above
    session.defaultSession.webRequest.onHeadersReceived = () => { };
}

