/*
 * Solcord, a Discord client mod
 * Copyright (c) 2022 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

export const SOLCORD_FILES = [
    IS_DISCORD_DESKTOP ? "patcher.js" : "solcordDesktopMain.js",
    IS_DISCORD_DESKTOP ? "preload.js" : "solcordDesktopPreload.js",
    IS_DISCORD_DESKTOP ? "renderer.js" : "solcordDesktopRenderer.js",
    IS_DISCORD_DESKTOP ? "renderer.css" : "solcordDesktopRenderer.css",
    // Solcord Desktop's own two files update with Solcord (desktop/src)
    ...(IS_DISCORD_DESKTOP ? [] : ["main.js", "preload.js"]),
];

/** The release manifest this build reads: Solcord Desktop has its own, signed the same way, in its own repository */
export const MANIFEST_URL = IS_DISCORD_DESKTOP
    ? "https://raw.githubusercontent.com/avyxl/SolCord/updates/version.json"
    : "https://raw.githubusercontent.com/avyxl/SolCord/updates-desktop/version.json";

/** What the updater has actually checked, for the settings page. Nothing here is assumed */
export interface UpdateTrust {
    /** 0 until a release manifest has been fetched */
    checkedAt: number;
    signed: boolean;
    /** Files can only be compared while the release they were signed for is the one running */
    installedFiles: "match" | "changed" | "unknown";
    pending: boolean;
    hasPrevious: boolean;
    /** The release that was undone because it never started, until a later one starts */
    rejected: string | null;
}

export function serializeErrors(func: (...args: any[]) => any) {
    return async function () {
        try {
            return {
                ok: true,
                value: await func(...arguments)
            };
        } catch (e: any) {
            return {
                ok: false,
                error: e instanceof Error ? {
                    // prototypes get lost, so turn error into plain object
                    ...e,
                    message: e.message,
                    name: e.name,
                    stack: e.stack
                } : e
            };
        }
    };
}
