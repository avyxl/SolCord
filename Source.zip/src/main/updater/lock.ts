/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { randomUUID } from "crypto";
import { closeSync, existsSync, fsyncSync, lstatSync, openSync, readFileSync, unlinkSync, writeSync } from "fs";
import { dirname, join } from "path";
export const updateLockPath = (directory: string) => join(dirname(directory), ".solcord-update.lock");
/** A crashed lock is repaired by the installer after Discord is closed. Never steal another process's lock. */
export function updateInProgress(directory: string) {
    const file = updateLockPath(directory);
    if (!existsSync(file)) return false;
    try {
        if (lstatSync(file).isSymbolicLink() || lstatSync(file).size > 2048) return true;
        const record = JSON.parse(readFileSync(file, "utf8"));
        if (record.format !== "solcord-update-lock-v1" || !Number.isSafeInteger(record.pid) || record.pid <= 0) return true;
        try { process.kill(record.pid, 0); return true; }
        catch (error) { return (error as NodeJS.ErrnoException).code !== "ESRCH"; }
    } catch { return true; }
}
export async function withUpdateLock<T>(directory: string, operation: () => Promise<T>): Promise<T> {
    const file = updateLockPath(directory), token = randomUUID();
    const repairGuard = join(dirname(directory), ".solcord-update.repair-lock");
    if (existsSync(repairGuard)) throw new Error("The Solcord installer is repairing this installation. Close Discord and finish Repair first.");
    let fd: number;
    try { fd = openSync(file, "wx", 0o600); }
    catch (error) {
        if ((error as NodeJS.ErrnoException).code === "EEXIST") throw new Error("Another Solcord update is running. If it was interrupted, close Discord and use Repair in the installer.");
        throw error;
    }
    try {
        writeSync(fd, JSON.stringify({ format: "solcord-update-lock-v1", pid: process.pid, token, at: Date.now() }));
        fsyncSync(fd);
        if (existsSync(repairGuard)) throw new Error("The Solcord installer started a repair. Try updating after it finishes.");
        return await operation();
    } finally {
        closeSync(fd);
        try { if (JSON.parse(readFileSync(file, "utf8")).token === token) unlinkSync(file); } catch { }
    }
}
