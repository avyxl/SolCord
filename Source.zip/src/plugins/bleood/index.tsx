/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import "./styles.css";

import { definePluginSettings } from "@api/Settings";
import { SolcordModal } from "@components/SolcordModal";
import type { RenderModalProps } from "@solcord/discord-types";
import definePlugin, { OptionType } from "@utils/types";
import { closeModal, openModal, useEffect, useState } from "@webpack/common";

import { BLEOOD_AUDIO_BASE64, RASKAL_IMAGE } from "./assets";

let audio: HTMLAudioElement | undefined;
let audioUrl: string | undefined;
let modalKey: string | undefined;
let generation = 0;

export const settings = definePluginSettings({
    volume: {
        type: OptionType.SLIDER,
        description: "Sound volume",
        markers: [0, 25, 50, 75, 100],
        default: 50,
        stickToMarkers: false,
        onChange(value: number) {
            if (audio) audio.volume = Math.min(1, Math.max(0, value / 100));
        }
    }
});

function stopSound() {
    if (!audio) return;
    audio.pause();
    audio.currentTime = 0;
}

function dismiss() {
    generation++;
    const key = modalKey;
    modalKey = undefined;
    if (key) closeModal(key);
    stopSound();
}

function getAudio() {
    if (!audio) {
        const bytes = Uint8Array.from(atob(BLEOOD_AUDIO_BASE64), value => value.charCodeAt(0));
        audioUrl = URL.createObjectURL(new Blob([bytes], { type: "audio/mpeg" }));
        audio = new Audio();
        audio.preload = "none";
        audio.src = audioUrl;
        audio.addEventListener("ended", dismiss);
    }
    return audio;
}

function playSound() {
    const player = getAudio();
    player.pause();
    player.currentTime = 0;
    const volume = Number(settings.store.volume);
    player.volume = Number.isFinite(volume) ? Math.min(1, Math.max(0, volume / 100)) : 0.5;
    return player.play();
}

function RaskalPopup({ instance, ...props }: RenderModalProps & { instance: number; }) {
    const [needsClick, setNeedsClick] = useState(false);

    const replay = () => {
        if (instance !== generation) return;
        try {
            void playSound().then(() => setNeedsClick(false), () => setNeedsClick(true));
        } catch {
            setNeedsClick(true);
        }
    };

    useEffect(() => {
        if (instance === generation) replay();
        return () => {
            if (instance === generation) stopSound();
        };
    }, [instance]);

    return (
        <SolcordModal
            {...props}
            size="sm"
            title="You have been raskaled!"
            actions={[
                { text: needsClick ? "Play sound" : "Play again", variant: "secondary", onClick: replay },
                { text: "Close", variant: "primary", onClick: props.onClose }
            ]}
        >
            <div className="sc-bleood-popup">
                <img src={RASKAL_IMAGE} alt="You have been raskaled!" draggable={false} />
                {needsClick && <p role="status">Click Play sound to allow audio in Discord.</p>}
            </div>
        </SolcordModal>
    );
}

export function showRaskal() {
    dismiss();
    const instance = ++generation;
    modalKey = openModal(props => <RaskalPopup {...props} instance={instance} />, {
        modalKey: "solcord-bleood",
        onCloseCallback() {
            if (instance !== generation) return;
            modalKey = undefined;
            stopSound();
        }
    });
}

export default definePlugin({
    name: "bleood",
    description: "A 1-in-50 chance to get raskaled when you send a message: your clip and a surprise popup inside Discord.",
    authors: [{ name: "avyxl", id: 0n }],
    tags: ["Fun"],
    enabledByDefault: true,
    dependencies: ["MessageEventsAPI"],
    settings,

    settingsAboutComponent: () => (
        <div className="sc-bleood-about">
            <p>Each message you send has a 1-in-50 chance to play the sound and show the popup.</p>
            <button type="button" onClick={showRaskal}>Test bleood</button>
        </div>
    ),

    onBeforeMessageSend() {
        // This hook runs only for local sends, never for incoming messages or edits.
        // A fresh independent roll for every send, rather than a counter.
        if (Math.floor(Math.random() * 50) !== 0) return;
        // A prank must never cancel, change, or delay the message.
        try {
            showRaskal();
        } catch { }
    },

    stop() {
        dismiss();
        if (audio) {
            audio.removeEventListener("ended", dismiss);
            audio.removeAttribute("src");
            audio.load();
            audio = undefined;
        }
        if (audioUrl) URL.revokeObjectURL(audioUrl);
        audioUrl = undefined;
    }
});
