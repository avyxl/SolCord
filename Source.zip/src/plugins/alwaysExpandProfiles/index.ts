/*
 * Solcord, a Discord client mod
 * Copyright (c) 2025 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { Devs } from "@utils/constants";
import definePlugin from "@utils/types";

export default definePlugin({
    name: "AlwaysExpandProfiles",
    description: "Always expands profile popouts to the full modal",
    tags: ["Appearance", "Utility"],
    authors: [Devs.rootpoi, Devs.kraethis, Devs.ewlle],
    patches: [
        {
            find: '"view-profile"',
            replacement: {
                match: /function (\i)\(\i?\)\{.{0,45}\(0,\i\.openUserProfileModal.{0,300}(?=return)/,
                replace: "$&return $1();"
            },
            all: true
        },
    ],
});
