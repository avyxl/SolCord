/*
 * Solcord, a Discord client mod
 * Copyright (c) 2024 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { BaseText } from "@components/BaseText";
import { SolcordModal } from "@components/SolcordModal";
import { Heading } from "@components/Heading";
import { BookCheckIcon, OpenExternalIcon, PencilIcon, StarFilled, StarOutlined, TrashIcon, UnsendIcon, WindowTopOutlineIcon, XLargeBoldIcon } from "@components/Icons";
import { Paragraph } from "@components/Paragraph";
import { RenderModalProps } from "@solcord/discord-types";
import { loadAllIcons } from "@plugins/_core/concatenatedModules";
import { bookmarkFolderColors, bookmarkPlaceholderName, closeOtherTabs, closeTab, closeTabsToTheLeft, closeTabsToTheRight, createTab, getDiscordFolderIcon, getDiscordFolderIconNames, hasClosedTabs, isBookmarkFolder, openedTabs, reopenClosedTab, settings, toggleCompactTab } from "@plugins/channelTabs/util";
import { Bookmark, BookmarkFolder, Bookmarks, ChannelTabsProps, UseBookmarkMethods } from "@plugins/channelTabs/util/types";
import { getIntlMessage } from "@utils/discord";
import { t } from "@utils/i18n";
import { Margins } from "@utils/margins";
import { Button, ChannelStore, closeModal, ColorPicker, FluxDispatcher, Menu, openModal, ReadStateStore, ReadStateUtils, Select, TextInput, useEffect, useMemo, useState } from "@webpack/common";

const legacyFolderColors: Record<string, string> = {
    "var(--channeltabs-red)": bookmarkFolderColors.Red,
    "var(--channeltabs-blue)": bookmarkFolderColors.Blue,
    "var(--channeltabs-yellow)": bookmarkFolderColors.Yellow,
    "var(--channeltabs-green)": bookmarkFolderColors.Green,
    "var(--channeltabs-black)": bookmarkFolderColors.Black,
    "var(--channeltabs-white)": bookmarkFolderColors.White,
    "var(--channeltabs-orange)": bookmarkFolderColors.Orange,
    "var(--channeltabs-pink)": bookmarkFolderColors.Pink
};

const normalizeFolderColor = (color?: string) => {
    if (!color) return bookmarkFolderColors.Black;
    return legacyFolderColors[color] ?? color;
};

const colorToInt = (color?: string) => {
    const normalized = normalizeFolderColor(color);
    if (!/^#([0-9a-f]{6})$/i.test(normalized)) return parseInt(bookmarkFolderColors.Black.slice(1), 16);
    return parseInt(normalized.slice(1), 16);
};

const intToColor = (value: number | null) =>
    value == null
        ? bookmarkFolderColors.Black
        : `#${value.toString(16).padStart(6, "0")}`;

export function BasicContextMenu() {
    const { showBookmarkBar } = settings.use(["showBookmarkBar"]);

    return (
        <Menu.Menu
            navId="channeltabs-context"
            onClose={() => FluxDispatcher.dispatch({ type: "CONTEXT_MENU_CLOSE" })}
            aria-label="ChannelTabs Context Menu"
        >
            <Menu.MenuGroup>
                <Menu.MenuCheckboxItem
                    checked={showBookmarkBar}
                    id="show-bookmark-bar"
                    label={t("Bookmark Bar")}
                    action={() => {
                        settings.store.showBookmarkBar = !settings.store.showBookmarkBar;
                    }}
                />
            </Menu.MenuGroup>
        </Menu.Menu>
    );
}

function FolderGlyph({ color, iconName }: { color: string; iconName?: string; }) {
    const IconComponent = getDiscordFolderIcon(iconName);
    const resolvedColor = normalizeFolderColor(color);
    const fill = iconName === "CircleShieldIcon" ? "var(--background-base-low)" : resolvedColor;
    const customIconSize = 16;

    return (
        <div style={{
            alignItems: "center",
            color: resolvedColor,
            display: "flex",
            justifyContent: "center",
            lineHeight: 0
        }}>
            {IconComponent
                ? <IconComponent
                    height={customIconSize}
                    width={customIconSize}
                    color={resolvedColor}
                    fill={fill}
                    style={{ transform: "scale(0.6666667)", transformOrigin: "center" }}
                />
                : <svg height={16} width={16} viewBox="0 0 24 24">
                    <path
                        fill="currentColor"
                        d="M20 7H12L10.553 5.106C10.214 4.428 9.521 4 8.764 4H3C2.447 4 2 4.447 2 5V19C2 20.104 2.895 21 4 21H20C21.104 21 22 20.104 22 19V9C22 7.896 21.104 7 20 7Z"
                    />
                </svg>}
        </div>
    );
}

function FolderChipPreview({ name, color, iconName }: { name: string; color: string; iconName?: string; }) {
    return (
        <div style={{
            alignItems: "center",
            border: "1px solid var(--border-subtle)",
            borderRadius: 8,
            display: "inline-flex",
            gap: 8,
            marginTop: 12,
            maxWidth: "100%",
            padding: "6px 10px"
        }}>
            <FolderGlyph color={color} iconName={iconName} />
            <BaseText size="sm">{name.trim() || "Folder"}</BaseText>
        </div>
    );
}

function FolderIconPickerModal({ modalProps, modalKey, name, color, iconName, onSelect, onColorChange }: {
    modalProps: RenderModalProps,
    modalKey: string,
    name: string,
    color: string,
    iconName?: string,
    onSelect: (iconName: string) => void,
    onColorChange: (color: string) => void;
}) {
    const [search, setSearch] = useState("");
    const [localColor, setLocalColor] = useState(normalizeFolderColor(color));
    // The icons Discord hasn't shown yet arrive a moment after the picker opens
    const [iconsLoaded, setIconsLoaded] = useState(false);
    useEffect(() => {
        let open = true;
        loadAllIcons().then(() => open && setIconsLoaded(true));
        return () => { open = false; };
    }, []);
    const iconNames = useMemo(() => getDiscordFolderIconNames(), [iconsLoaded]);
    const filteredIconNames = useMemo(() => {
        const normalized = search.trim().toLowerCase();
        if (!normalized) return iconNames;
        return iconNames.filter(iconName => iconName.toLowerCase().includes(normalized));
    }, [iconNames, search]);

    return (
        <SolcordModal
            {...modalProps}
            size="sm"
            title={<BaseText size="lg" weight="semibold">{t("Choose Folder Icon")}</BaseText>}
            actions={[
                {
                    text: "Close",
                    variant: "secondary",
                    onClick: () => closeModal(modalKey)
                }
            ]}
        >
            <Heading className={Margins.top16}>{t("Preview")}</Heading>
            <FolderChipPreview name={name} color={localColor} iconName={iconName} />
            <Heading className={Margins.top16}>{t("Icon Color")}</Heading>
            <div className={Margins.top8}>
                <ColorPicker
                    color={colorToInt(localColor)}
                    onChange={value => {
                        const nextColor = intToColor(value);
                        setLocalColor(nextColor);
                        onColorChange(nextColor);
                    }}
                    showEyeDropper={false}
                />
            </div>
            <Heading className={Margins.top16}>{t("Search")}</Heading>
            <TextInput
                value={search}
                placeholder={`Search ${iconNames.length} icons...`}
                onChange={setSearch}
            />
            <div style={{
                display: "grid",
                gap: 8,
                gridTemplateColumns: "repeat(auto-fill, minmax(52px, 1fr))",
                marginTop: 16,
                maxHeight: 320,
                overflowY: "auto"
            }}>
                {filteredIconNames.map(name => (
                    <button
                        key={name}
                        onClick={() => {
                            onSelect(name);
                            closeModal(modalKey);
                        }}
                        style={{
                            alignItems: "center",
                            background: name === iconName ? "var(--background-modifier-hover)" : "var(--background-secondary)",
                            border: "1px solid var(--border-subtle)",
                            borderRadius: 8,
                            cursor: "pointer",
                            display: "flex",
                            height: 52,
                            justifyContent: "center",
                            padding: 0
                        }}
                        title={name}
                        type="button"
                    >
                        <FolderGlyph color={localColor} iconName={name} />
                    </button>
                ))}
            </div>
        </SolcordModal>
    );
}

function FolderAppearanceFields({
    name,
    setName,
    color,
    setColor,
    iconName,
    setIconName,
    placeholder = "Folder"
}: {
    name: string,
    setName: (value: string) => void,
    color: string,
    setColor: (value: string) => void,
    iconName?: string,
    setIconName: (value?: string) => void,
    placeholder?: string;
}) {
    return <>
        <Heading className={Margins.top16}>{t("Folder Name")}</Heading>
        <TextInput
            value={name === placeholder ? undefined : name}
            placeholder={placeholder}
            onChange={setName}
        />
        <Heading className={Margins.top16}>{t("Folder Color")}</Heading>
        <div className={Margins.top8}>
            <ColorPicker
                color={colorToInt(color)}
                onChange={value => setColor(intToColor(value))}
                showEyeDropper={false}
            />
        </div>
        <Heading className={Margins.top16}>{t("Folder Icon")}</Heading>
        <FolderChipPreview name={name} color={color} iconName={iconName} />
        <Button
            className={Margins.top8}
            onClick={() => {
                const key = openModal(modalProps => (
                    <FolderIconPickerModal
                        modalProps={modalProps}
                        modalKey={key}
                        name={name}
                        color={color}
                        iconName={iconName}
                        onSelect={setIconName}
                        onColorChange={setColor}
                    />
                ));
            }}
        >{t("Choose Icon")}</Button>
        {iconName && <Button
            className={Margins.top8}
            color={Button.Colors.TRANSPARENT}
            look={Button.Looks.FILLED}
            onClick={() => setIconName(undefined)}
        >{t("Use Default Icon")}</Button>}
    </>;
}

export function EditModal({ modalProps, modalKey, bookmark, onSave }: {
    modalProps: RenderModalProps,
    modalKey: string,
    bookmark: Bookmark | BookmarkFolder,
    onSave: (name: string, color: string, iconName?: string) => void;
}) {
    const [name, setName] = useState(bookmark.name);
    const [color, setColor] = useState(isBookmarkFolder(bookmark) ? normalizeFolderColor(bookmark.iconColor) : bookmarkFolderColors.Black);
    const [iconName, setIconName] = useState(isBookmarkFolder(bookmark) ? bookmark.iconName : undefined);
    const placeholder = bookmarkPlaceholderName(bookmark);

    return (
        <SolcordModal
            {...modalProps}
            size="sm"
            title={<BaseText size="lg" weight="semibold">{t("Edit Bookmark")}</BaseText>}
            actions={[
                {
                    text: "Save",
                    variant: "primary",
                    onClick: () => onSave(name || placeholder, color, iconName)
                },
                {
                    text: "Cancel",
                    variant: "secondary",
                    onClick: () => closeModal(modalKey)
                }
            ]}
        >
            {isBookmarkFolder(bookmark)
                ? <FolderAppearanceFields
                    name={name}
                    setName={setName}
                    color={color}
                    setColor={setColor}
                    iconName={iconName}
                    setIconName={setIconName}
                    placeholder={placeholder}
                />
                : <>
                    <Heading className={Margins.top16}>{t("Bookmark Name")}</Heading>
                    <TextInput
                        value={name === placeholder ? undefined : name}
                        placeholder={placeholder}
                        onChange={setName}
                    />
                </>}
        </SolcordModal>
    );
}

function AddToFolderModal({ modalProps, modalKey, bookmarks, onSave }: {
    modalProps: RenderModalProps,
    modalKey: string,
    bookmarks: Bookmarks,
    onSave: (folderIndex: number, folderName: string, folderColor: string, iconName?: string) => void;
}) {
    const [folderIndex, setIndex] = useState(-1);
    const [folderName, setFolderName] = useState("");
    const [folderColor, setFolderColor] = useState<string>(bookmarkFolderColors.Black);
    const [iconName, setIconName] = useState<string | undefined>();

    return (
        <SolcordModal
            {...modalProps}
            size="sm"
            title={<BaseText size="lg" weight="semibold">{t("Add Bookmark to Folder")}</BaseText>}
            actions={[
                {
                    text: "Save",
                    variant: "primary",
                    onClick: () => onSave(folderIndex, folderName, folderColor, iconName)
                },
                {
                    text: "Cancel",
                    variant: "secondary",
                    onClick: () => closeModal(modalKey)
                }
            ]}
        >
            <Heading className={Margins.top16}>{t("Select a folder")}</Heading>
            <Select
                options={[...Object.entries(bookmarks)
                    .filter(([, bookmark]) => isBookmarkFolder(bookmark))
                    .map(([index, bookmark]) => ({
                        label: bookmark.name,
                        value: parseInt(index, 10)
                    })),
                {
                    label: "Create one",
                    value: -1,
                    default: true
                }]}
                isSelected={v => v === folderIndex}
                select={setIndex}
                serialize={String}
            />
            {folderIndex === -1 && <FolderAppearanceFields
                name={folderName}
                setName={setFolderName}
                color={folderColor}
                setColor={setFolderColor}
                iconName={iconName}
                setIconName={setIconName}
            />}
        </SolcordModal>
    );
}

function DeleteFolderConfirmationModal({ modalProps, modalKey, onConfirm }: {
    modalProps: RenderModalProps,
    modalKey: string,
    onConfirm: () => void;
}) {
    return (
        <SolcordModal
            {...modalProps}
            size="sm"
            title={<BaseText size="lg" weight="semibold">{t("Are you sure?")}</BaseText>}
            actions={[
                {
                    text: "Delete",
                    variant: "critical-primary",
                    onClick: onConfirm
                },
                {
                    text: "Cancel",
                    variant: "secondary",
                    onClick: () => closeModal(modalKey)
                }
            ]}
        >
            <Paragraph className={Margins.top16}>
                {t("Deleting a bookmark folder will also delete all bookmarks within it.")}</Paragraph>
        </SolcordModal>
    );
}

export function BookmarkContextMenu({ bookmarks, index, methods }: { bookmarks: Bookmarks, index: number, methods: UseBookmarkMethods; }) {
    const { showBookmarkBar, bookmarkNotificationDot } = settings.use(["showBookmarkBar", "bookmarkNotificationDot"]);
    const bookmark = bookmarks[index];
    const isFolder = isBookmarkFolder(bookmark);

    return (
        <Menu.Menu
            navId="channeltabs-bookmark-context"
            onClose={() => FluxDispatcher.dispatch({ type: "CONTEXT_MENU_CLOSE" })}
            aria-label="ChannelTabs Bookmark Context Menu"
        >
            <Menu.MenuGroup>
                {bookmarkNotificationDot && !isFolder &&
                    <Menu.MenuItem
                        id="mark-as-read"
                        icon={BookCheckIcon}
                        leadingAccessory={{ type: "icon", icon: BookCheckIcon }}
                        label={getIntlMessage("MARK_AS_READ")}
                        disabled={!ReadStateStore.hasUnread(bookmark.channelId)}
                        action={() => ReadStateUtils.ackChannel(ChannelStore.getChannel(bookmark.channelId))}
                    />
                }
                {isFolder
                    ? <Menu.MenuItem
                        id="open-all-in-folder"
                        label={t("Open All Bookmarks")}
                        icon={StarFilled}
                        leadingAccessory={{ type: "icon", icon: StarFilled }}
                        action={() => bookmark.bookmarks.forEach(b => createTab(b))}
                    />
                    : < Menu.MenuItem
                        id="open-in-tab"
                        label={t("Open in New Tab")}
                        icon={OpenExternalIcon}
                        leadingAccessory={{ type: "icon", icon: OpenExternalIcon }}
                        action={() => createTab(bookmark)}
                    />
                }
            </Menu.MenuGroup>
            <Menu.MenuGroup>
                <Menu.MenuItem
                    id="edit-bookmark"
                    label={t("Edit Bookmark")}
                    icon={PencilIcon}
                    leadingAccessory={{ type: "icon", icon: PencilIcon }}
                    action={() => {
                        const key = openModal(modalProps =>
                            <EditModal
                                modalProps={modalProps}
                                modalKey={key}
                                bookmark={bookmark}
                                onSave={(name, color, iconName) => {
                                    methods.editBookmark(index, {
                                        name,
                                        ...(isFolder && { iconColor: normalizeFolderColor(color), iconName })
                                    });
                                    closeModal(key);
                                }
                                }
                            />
                        );
                    }}
                />
                <Menu.MenuItem
                    id="delete-bookmark"
                    label={t("Delete Bookmark")}
                    icon={TrashIcon}
                    leadingAccessory={{ type: "icon", icon: TrashIcon }}
                    action={() => {
                        if (isFolder) {
                            const key = openModal(modalProps =>
                                <DeleteFolderConfirmationModal
                                    modalProps={modalProps}
                                    modalKey={key}
                                    onConfirm={() => {
                                        methods.deleteBookmark(index);
                                        closeModal(key);
                                    }}
                                />);
                        }
                        else methods.deleteBookmark(index);
                    }}
                />
                <Menu.MenuItem
                    id="add-to-folder"
                    label={t("Add Bookmark to Folder")}
                    icon={PencilIcon}
                    leadingAccessory={{ type: "icon", icon: PencilIcon }}
                    disabled={isFolder}
                    action={() => {
                        const key = openModal(modalProps =>
                            <AddToFolderModal
                                modalProps={modalProps}
                                modalKey={key}
                                bookmarks={bookmarks}
                                onSave={(index, folderName, folderColor, iconName) => {
                                    if (index === -1) {
                                        const folderIndex = methods.addFolder(folderName, normalizeFolderColor(folderColor), iconName);
                                        methods.addBookmark(bookmark as Bookmark, folderIndex);
                                    }
                                    else methods.addBookmark(bookmark as Bookmark, index);
                                    methods.deleteBookmark(bookmarks.indexOf(bookmark));
                                    closeModal(key);
                                }
                                }
                            />
                        );
                    }}
                />
            </Menu.MenuGroup>
            <Menu.MenuGroup>
                <Menu.MenuCheckboxItem
                    checked={showBookmarkBar}
                    id="show-bookmark-bar"
                    label={t("Bookmark Bar")}
                    icon={StarOutlined}
                    leadingAccessory={{ type: "icon", icon: StarOutlined }}
                    action={() => {
                        settings.store.showBookmarkBar = !settings.store.showBookmarkBar;
                    }}
                />
            </Menu.MenuGroup>
        </Menu.Menu>
    );
}

export function TabContextMenu({ tab }: { tab: ChannelTabsProps; }) {
    const channel = ChannelStore.getChannel(tab.channelId);
    const [compact, setCompact] = useState(tab.compact);
    const { showBookmarkBar } = settings.use(["showBookmarkBar"]);

    return (
        <Menu.Menu
            navId="channeltabs-tab-context"
            onClose={() => FluxDispatcher.dispatch({ type: "CONTEXT_MENU_CLOSE" })}
            aria-label="ChannelTabs Tab Context Menu"
        >
            <Menu.MenuGroup>
                {channel &&
                    <Menu.MenuItem
                        id="mark-as-read"
                        label={getIntlMessage("MARK_AS_READ")}
                        icon={BookCheckIcon}
                        leadingAccessory={{ type: "icon", icon: BookCheckIcon }}
                        disabled={!ReadStateStore.hasUnread(channel.id)}
                        action={() => ReadStateUtils.ackChannel(channel)}
                    />
                }
                <Menu.MenuCheckboxItem
                    checked={compact}
                    id="toggle-compact-tab"
                    label={t("Compact")}
                    icon={WindowTopOutlineIcon}
                    leadingAccessory={{ type: "icon", icon: WindowTopOutlineIcon }}
                    action={() => {
                        setCompact(compact => !compact);
                        toggleCompactTab(tab.id);
                    }}
                />
            </Menu.MenuGroup>
            {openedTabs.length !== 1 && <Menu.MenuGroup>
                <Menu.MenuItem
                    id="close-tab"
                    label={t("Close Tab")}
                    icon={XLargeBoldIcon}
                    leadingAccessory={{ type: "icon", icon: XLargeBoldIcon }}
                    action={() => closeTab(tab.id)}
                />
                <Menu.MenuItem
                    id="close-other-tabs"
                    label={t("Close Other Tabs")}
                    icon={XLargeBoldIcon}
                    leadingAccessory={{ type: "icon", icon: XLargeBoldIcon }}
                    action={() => closeOtherTabs(tab.id)}
                />
                <Menu.MenuItem
                    id="close-right-tabs"
                    label={t("Close Tabs to the Right")}
                    icon={XLargeBoldIcon}
                    leadingAccessory={{ type: "icon", icon: XLargeBoldIcon }}
                    disabled={openedTabs.indexOf(tab) === openedTabs.length - 1}
                    action={() => closeTabsToTheRight(tab.id)}
                />
                <Menu.MenuItem
                    id="close-left-tabs"
                    label={t("Close Tabs to the Left")}
                    icon={XLargeBoldIcon}
                    leadingAccessory={{ type: "icon", icon: XLargeBoldIcon }}
                    disabled={openedTabs.indexOf(tab) === 0}
                    action={() => closeTabsToTheLeft(tab.id)}
                />
                <Menu.MenuItem
                    id="reopen-closed-tab"
                    label={t("Reopen Closed Tab")}
                    icon={UnsendIcon}
                    leadingAccessory={{ type: "icon", icon: UnsendIcon }}
                    disabled={!hasClosedTabs()}
                    action={() => reopenClosedTab()}
                />
            </Menu.MenuGroup>}
            <Menu.MenuGroup>
                <Menu.MenuCheckboxItem
                    checked={showBookmarkBar}
                    id="show-bookmark-bar"
                    label={t("Bookmark Bar")}
                    icon={StarOutlined}
                    leadingAccessory={{ type: "icon", icon: StarOutlined }}
                    action={() => {
                        settings.store.showBookmarkBar = !settings.store.showBookmarkBar;
                    }}
                />
            </Menu.MenuGroup>
        </Menu.Menu>
    );
}
