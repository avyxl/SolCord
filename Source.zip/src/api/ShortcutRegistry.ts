/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

export interface RegisteredShortcut { id: string; label: string; keys: string[]; scope?: string; }
const providers = new Map<string, () => RegisteredShortcut[]>();
export function registerShortcutProvider(owner: string, provider: () => RegisteredShortcut[]) { providers.set(owner, provider); return () => { if (providers.get(owner) === provider) providers.delete(owner); }; }
export function normalizeShortcut(keys: string[], mac = typeof navigator !== "undefined" && /Mac/i.test(navigator.platform)) {
    const aliases: Record<string, string> = { control: "ctrl", controlleft: "ctrl", controlright: "ctrl", command: "meta", cmd: "meta", option: "alt", esc: "escape", " ": "space", mod: mac ? "meta" : "ctrl" };
    return [...new Set(keys.map(key => aliases[key.toLowerCase()] ?? key.toLowerCase()).filter(Boolean))].sort().join("+");
}
export function inspectRegisteredShortcuts() {
    const rows: (RegisteredShortcut & { owner: string; chord: string })[] = [], errors: string[] = [];
    for (const [owner, provider] of providers) {
        try {
            const values = provider();
            if (!Array.isArray(values) || values.length > 1000) throw new Error("Invalid provider result.");
            for (const row of values) if (row && typeof row.id === "string" && typeof row.label === "string" && Array.isArray(row.keys) && row.keys.length > 0 && row.keys.length <= 12 && row.keys.every(key => typeof key === "string" && key.length <= 50)) rows.push({ ...row, owner, chord: normalizeShortcut(row.keys) });
        } catch { errors.push(owner); }
    }
    const groups = new Map<string, typeof rows>();
    for (const row of rows) groups.set(row.chord, [...groups.get(row.chord) ?? [], row]);
    const conflicts = [...groups].flatMap(([chord, group]) => group.length > 1 && group.some((row, i) => group.some((other, j) => i !== j && (!row.scope || !other.scope || row.scope === "global" || other.scope === "global" || row.scope === other.scope))) ? [{ chord, bindings: group }] : []);
    return { bindings: rows, conflicts, unavailableProviders: errors };
}
