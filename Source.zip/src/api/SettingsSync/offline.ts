/*
 * Solcord, a Discord client mod
 * Copyright (c) 2025 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { PlainSettings } from "@api/Settings";
import { t } from "@utils/i18n";
import { Logger } from "@utils/Logger";
import { Plugin, PluginSettingDefCommon } from "@utils/types";
import { chooseFile, saveFile } from "@utils/web";
import { moment, Toasts } from "@webpack/common";

import Plugins, { getPluginListInfo } from "~plugins";

const toast = (type: string, message: string) =>
    Toasts.show({
        type,
        message,
        id: Toasts.genId()
    });

const toastSuccess = () =>
    toast(Toasts.Type.SUCCESS, t("Settings successfully imported. Restart to apply changes!"));

const toastFailure = (err: any) =>
    toast(Toasts.Type.FAILURE, t("Couldn't import those settings :( {error}", { error: String(err) }));

const logger = new Logger("SettingsSync:Offline", "#39b7e0");

function isSafeObject(obj: any) {
    if (obj == null || typeof obj !== "object") return true;

    for (const key in obj) {
        if (["__proto__", "constructor", "prototype"].includes(key)) {
            return false;
        }
        if (!isSafeObject(obj[key])) {
            return false;
        }
    }

    return true;
}

function getSensitiveKeys(plugin: Plugin) {
    return Object.entries(plugin.settings?.def ?? {})
        .filter(([, setting]) => (setting as PluginSettingDefCommon).sensitive)
        .map(([key]) => key);
}

/**
 * A plugin's sensitive settings. For a lazy plugin whose code isn't loaded they come from what the build read from
 * its source, so a backup doesn't load the code of every plugin there is (that took a third of a second)
 */
export function sensitiveKeysOf(name: string) {
    const known = getPluginListInfo(name);
    if (known && !known.k?.includes("*")) return known.k ?? [];
    return getSensitiveKeys(Plugins[name]);
}

// Whoever controls an import must not get to redirect this device's keys, choose who can act for the user or whom
// the user follows into voice, stop its updates or load a browser extension into Discord. Exports leave these
// settings out, so a file that carries them was written by hand: they never come from a file or from the cloud
function keepLocalSettings(imported: any) {
    for (const pluginName of Object.keys(Plugins)) {
        const keys = sensitiveKeysOf(pluginName);
        if (!keys.length) continue;
        const local = PlainSettings.plugins[pluginName] ?? {};

        for (const key of keys) {
            if (key in local) ((imported.plugins ??= {})[pluginName] ??= {})[key] = local[key];
            else delete imported.plugins?.[pluginName]?.[key];
        }
    }

    for (const key of ["cloud", "autoUpdate", "autoUpdateNotification", "enableReactDevtools"]) imported[key] = PlainSettings[key];
}

export async function importSettings(data: string) {
    try {
        var parsed = JSON.parse(data);
    } catch (err) {
        throw new Error(`Failed to parse JSON: ${String(err)}`);
    }

    if (!isSafeObject(parsed))
        throw new Error("Unsafe Settings");

    if ("settings" in parsed && "quickCss" in parsed) {
        keepLocalSettings(parsed.settings);
        Object.assign(PlainSettings, parsed.settings);
        await SolcordNative.settings.set(parsed.settings);
        await SolcordNative.quickCss.set(parsed.quickCss);
    } else
        throw new Error("Invalid Settings. Is this even a Solcord Settings file?");
}

export async function exportSettings({ minify }: { minify?: boolean; } = {}) {
    const settings = structuredClone(SolcordNative.settings.get());
    // Backups get shared for support and cloud sync leaves the device
    for (const pluginName of Object.keys(Plugins)) {
        for (const key of sensitiveKeysOf(pluginName)) delete settings.plugins[pluginName]?.[key];
    }

    const quickCss = await SolcordNative.quickCss.get();
    return JSON.stringify({ settings, quickCss }, null, minify ? undefined : 4);
}

export async function downloadSettingsBackup() {
    const filename = `solcord-settings-backup-${moment().format("YYYY-MM-DD")}.json`;
    const backup = await exportSettings();
    const data = new TextEncoder().encode(backup);

    if (IS_DISCORD_DESKTOP) {
        DiscordNative.fileManager.saveWithDialog(data, filename);
    } else {
        saveFile(new File([data], filename, { type: "application/json" }));
    }
}

export async function uploadSettingsBackup(showToast = true): Promise<void> {
    if (IS_DISCORD_DESKTOP) {
        const [file] = await DiscordNative.fileManager.openFiles({
            filters: [
                { name: t("Solcord Settings Backup"), extensions: ["json"] },
                { name: "all", extensions: ["*"] }
            ]
        });

        if (file) {
            try {
                await importSettings(new TextDecoder().decode(file.data));
                if (showToast) toastSuccess();
            } catch (err) {
                logger.error(err);
                if (showToast) toastFailure(err);
            }
        }
    } else {
        const file = await chooseFile("application/json");
        if (!file) return;

        const reader = new FileReader();
        reader.onload = async () => {
            try {
                await importSettings(reader.result as string);
                if (showToast) toastSuccess();
            } catch (err) {
                logger.error(err);
                if (showToast) toastFailure(err);
            }
        };
        reader.readAsText(file);
    }
}
