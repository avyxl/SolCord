/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 avyxl
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

/** Native banners need their own lifetime: the operating system may retain them indefinitely. */
export function bindNativeLifetime(notice: Notification, timeout: number, onClick?: () => void, onClose?: () => void, dismissOnClick = true) {
    let finished = false;
    let timer: ReturnType<typeof setTimeout> | undefined;
    const finish = () => {
        if (finished) return;
        finished = true;
        clearTimeout(timer);
        notice.onclick = notice.onclose = null;
        onClose?.();
    };
    const dismiss = () => { if (finished) return; try { notice.close(); } finally { finish(); } };
    notice.onclose = finish;
    notice.onclick = () => { try { onClick?.(); } finally { if (dismissOnClick) dismiss(); } };
    if (Number.isFinite(timeout) && timeout > 0) timer = setTimeout(dismiss, timeout);
    return dismiss;
}
