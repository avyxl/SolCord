/*
 * Solcord, a Discord client mod
 * Copyright (c) 2023 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import * as DataStore from "@api/DataStore";
import { Settings } from "@api/Settings";
import { openNotificationSettingsModal } from "@components/settings/tabs/solcord/NotificationSettings";
import { RenderModalProps } from "@solcord/discord-types";
import { classNameFactory } from "@utils/css";
import { useI18n } from "@utils/i18n";
import { useAwaiter } from "@utils/react";
import { ConfirmModal, Forms, ListScrollerThin, Modal, openModal, React, Timestamp, useEffect, useReducer, useState } from "@webpack/common";
import { nanoid } from "nanoid";
import type { DispatchWithoutAction } from "react";

import NotificationComponent from "./NotificationComponent";
import type { NotificationData } from "./Notifications";

interface PersistentNotificationData extends Pick<NotificationData, "title" | "body" | "image" | "icon" | "color"> {
    timestamp: number;
    id: string;
}

const KEY = "notification-log";

const getLog = async () => {
    const log = await DataStore.get(KEY);
    return log ?? [];
};

const cl = classNameFactory("vc-notification-log-");
const signals = new Set<DispatchWithoutAction>();

export async function persistNotification(notification: NotificationData) {
    if (notification.noPersist) return;

    const limit = Settings.notifications.logLimit;
    if (limit === 0) return;

    await DataStore.update(KEY, (old: PersistentNotificationData[] | undefined) => {
        const log = old ?? [];

        // Omit stuff we don't need
        const {
            onClick, onClose, richBody, permanent, noPersist, dismissOnClick,
            ...pureNotification
        } = notification;

        log.unshift({
            ...pureNotification,
            timestamp: Date.now(),
            id: nanoid()
        });

        if (log.length > limit && limit !== 200)
            log.length = limit;

        return log;
    });

    signals.forEach(x => x());
}

export async function deleteNotification(timestamp: number) {
    const log = await getLog();
    const index = log.findIndex(x => x.timestamp === timestamp);
    if (index === -1) return;

    log.splice(index, 1);
    await DataStore.set(KEY, log);
    signals.forEach(x => x());
}

export function useLogs() {
    const [signal, setSignal] = useReducer(x => x + 1, 0);

    useEffect(() => {
        signals.add(setSignal);
        return () => void signals.delete(setSignal);
    }, []);

    const [log, _, pending] = useAwaiter(getLog, {
        fallbackValue: [],
        deps: [signal]
    });

    return [log, pending] as const;
}

function NotificationEntry({ data }: { data: PersistentNotificationData; }) {
    const [removing, setRemoving] = useState(false);

    return (
        <div className={cl("wrapper", { removing })}>
            <NotificationComponent
                {...data}
                permanent={true}
                dismissOnClick={false}
                onClose={() => {
                    if (removing) return;
                    setRemoving(true);

                    setTimeout(() => deleteNotification(data.timestamp), 200);
                }}
                richBody={
                    <div className={cl("body-wrapper")}>
                        <div className={cl("body")}>{data.body}</div>
                        <Timestamp timestamp={new Date(data.timestamp)} className={cl("timestamp")} />
                    </div>
                }
            />
        </div >
    );
}

export function NotificationLog({ log, pending }: { log: PersistentNotificationData[], pending: boolean; }) {
    const { t } = useI18n();
    if (!log.length && !pending)
        return (
            <div>
                <div className={cl("empty")} />
                <Forms.FormText style={{ textAlign: "center" }}>
                    {t("No notifications yet")}
                </Forms.FormText>
            </div>
        );

    return (
        <ListScrollerThin
            className={cl("container")}
            sections={[log.length]}
            sectionHeight={0}
            rowHeight={120}
            renderSection={() => null}
            renderRow={item => <NotificationEntry data={log[item.row]} key={log[item.row].id} />}
        />
    );
}

function LogModal(props: RenderModalProps) {
    const { t } = useI18n();
    const [log, pending] = useLogs();

    return (
        <Modal
            {...props}
            size="xl"
            title={t("Notification Log")}
            actions={[
                {
                    text: t("Notification Settings"),
                    variant: "primary",
                    onClick: openNotificationSettingsModal
                },
                {
                    text: t("Clear Notification Log"),
                    variant: "critical-primary",
                    disabled: !log.length,
                    onClick() {
                        openModal(props =>
                            <ConfirmModal
                                {...props}
                                title={t("Are you sure?")}
                                subtitle={t("This will permanently remove {count} notification(s). This action cannot be undone.", { count: log.length })}
                                confirmText={t("Do it!")}
                                onConfirm={async () => {
                                    await DataStore.set(KEY, []);
                                    signals.forEach(x => x());
                                }}
                            />
                        );
                    }
                }
            ]}
        >
            <NotificationLog log={log} pending={pending} />
        </Modal>
    );
}

export function openNotificationLogModal() {
    openModal(props => <LogModal {...props} />);
}
