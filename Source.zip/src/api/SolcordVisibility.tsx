/*
 * Solcord, a Discord client mod
 * Copyright (c) 2026 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { React } from "@webpack/common";
import type { PropsWithChildren } from "react";

// Lives here rather than in the HideSolcord plugin so the header bar and settings keep working with that plugin removed

let isHidden = false;
const listeners = new Set<() => void>();

export function getIsSolcordHidden() {
    return isHidden;
}

export function setSolcordHidden(hidden: boolean) {
    if (isHidden === hidden) return;

    isHidden = hidden;
    listeners.forEach(cb => cb());
}

export function onHiddenChange(cb: () => void) {
    listeners.add(cb);
    return () => { listeners.delete(cb); };
}

/** Whether Solcord is hidden, re-rendering the component when that changes */
export function useSolcordHidden() {
    return React.useSyncExternalStore(onHiddenChange, getIsSolcordHidden);
}

/**
 * Leaves out what a plugin draws while Solcord is hidden. Only the drawing goes: the plugin keeps running, so a
 * fake mute stays a fake mute. The APIs plugins draw through wrap their output in this, so every plugin follows it
 */
export function SolcordOnly({ children }: PropsWithChildren) {
    return useSolcordHidden() ? null : <>{children}</>;
}
