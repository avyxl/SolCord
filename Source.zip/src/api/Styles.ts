/*
 * Solcord, a Discord client mod
 * Copyright (c) 2022 Vendicated and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { generateTextCss } from "@components/BaseText";
import { generateMarginCss } from "@components/margins";
import { classNameFactory as _classNameFactory, classNameToSelector, createAndAppendStyle } from "@utils/css";

import { getScreenStyle } from "~plugins";

// Kept for plugins that still import it from here
/** @deprecated Import this from `@utils/css` instead */
export const classNameFactory = _classNameFactory;

export interface Style {
    name: string;
    source: string;
    classNames: Record<string, string>;
    dom: HTMLStyleElement | null;
}

export const styleMap = window.SolcordStyles ??= new Map();

export const solcordRootNode = document.createElement("solcord-root");
/**
 * Houses all Solcord core styles. This includes all imported css files
 */
export const coreStyleRootNode = document.createElement("solcord-styles");
/**
 * Houses all plugin specific managed styles
 */
export const managedStyleRootNode = document.createElement("solcord-managed-styles");
/**
 * Houses the user's themes and quick css
 */
export const userStyleRootNode = document.createElement("solcord-user-styles");

solcordRootNode.style.display = "none";
solcordRootNode.append(coreStyleRootNode, managedStyleRootNode, userStyleRootNode);

export function initStyles() {
    const osValuesNode = createAndAppendStyle("solcord-os-theme-values", coreStyleRootNode);
    createAndAppendStyle("solcord-text", coreStyleRootNode).textContent = generateTextCss();
    const rendererCssNode = createAndAppendStyle("solcord-css-core", coreStyleRootNode);
    const desktopCssNode = IS_SOLCORD_DESKTOP ? createAndAppendStyle("solcord-desktop-css-core", coreStyleRootNode) : null;
    createAndAppendStyle("solcord-margins", coreStyleRootNode).textContent = generateMarginCss();

    SolcordNative.native.getRendererCss().then(css => rendererCssNode.textContent = css);
    if (IS_DEV) {
        SolcordNative.native.onRendererCssUpdate(newCss => {
            rendererCssNode.textContent = newCss;
        });
    }

    if (IS_SOLCORD_DESKTOP && SolcordDesktopNative.app.getRendererCss) {
        SolcordDesktopNative.app.getRendererCss().then(css => desktopCssNode!.textContent = css);
        SolcordDesktopNative.app.onRendererCssUpdate(newCss => {
            desktopCssNode!.textContent = newCss;
        });
    }

    SolcordNative.themes.getSystemValues().then(values => {
        const variables = Object.entries(values)
            .filter(([, v]) => !!v)
            .map(([k, v]) => `--${k}: ${v};`)
            .join("");
        osValuesNode.textContent = `:root{${variables}}`;
    });
}

document.addEventListener("DOMContentLoaded", () => {
    document.documentElement.append(solcordRootNode);
}, { once: true });

let screenStyles: HTMLStyleElement | undefined;

/**
 * Adds the styles of Solcord's own screens, imported with `?screen`: settings, dialogs, the welcome screen. Discord's page
 * doesn't carry them until one of those is first drawn, so each restyle of Discord has fewer rules to match.
 * Call it when such a screen renders; after the first call it does nothing
 */
export function enableScreenStyles() {
    if (screenStyles) return;

    const node = screenStyles = createAndAppendStyle("solcord-screens", coreStyleRootNode);
    const queued = window.SolcordScreenStyles ??= [];
    // The desktop build keeps the core's own screen styles with the plugin code outside the script, and queues where
    // each one is instead (see getScreenStyle)
    const text = (entry: string | { k: string; }) => typeof entry === "string" ? entry : getScreenStyle(entry.k);
    node.textContent = queued.map(text).join("\n");
    // A screen whose code is only loaded later, like a plugin's tab, adds its styles as it loads
    queued.push = (...css: Array<string | { k: string; }>) => {
        node.textContent += `\n${css.map(text).join("\n")}`;
        return queued.length;
    };
}

export function requireStyle(name: string) {
    const style = styleMap.get(name);
    if (!style) throw new Error(`Style "${name}" does not exist`);
    return style;
}

/**
 * A style's name can be obtained from importing a stylesheet with `?managed` at the end of the import
 * @param name The name of the style
 * @returns `false` if the style was already enabled, `true` otherwise
 * @example
 * import pluginStyle from "./plugin.css?managed";
 *
 * // Inside some plugin method like "start()" or "[option].onChange()"
 * enableStyle(pluginStyle);
 */
export function enableStyle(name: string) {
    const style = requireStyle(name);

    if (style.dom?.isConnected)
        return false;

    if (!style.dom) {
        style.dom = document.createElement("style");
        style.dom.dataset.solcordName = style.name;
    }
    compileStyle(style);

    managedStyleRootNode.appendChild(style.dom);
    return true;
}

/**
 * @param name The name of the style
 * @returns `false` if the style was already disabled, `true` otherwise
 * @see {@link enableStyle} for info on getting the name of an imported style
 */
export function disableStyle(name: string) {
    const style = requireStyle(name);
    if (!style.dom?.isConnected)
        return false;

    style.dom.remove();
    style.dom = null;
    return true;
}

/**
 * @param name The name of the style
 * @returns `true` in most cases, may return `false` in some edge cases
 * @see {@link enableStyle} for info on getting the name of an imported style
 */
export const toggleStyle = (name: string) => isStyleEnabled(name) ? disableStyle(name) : enableStyle(name);

/**
 * @param name The name of the style
 * @returns Whether the style is enabled
 * @see {@link enableStyle} for info on getting the name of an imported style
 */
export const isStyleEnabled = (name: string) => requireStyle(name).dom?.isConnected ?? false;

/**
 * Sets the variables of a style
 * ```ts
 * // -- plugin.ts --
 * import pluginStyle from "./plugin.css?managed";
 * import { setStyleVars } from "@api/Styles";
 * import { findByPropsLazy } from "@webpack";
 * const classNames = findByPropsLazy("thin", "scrollerBase"); // { thin: "thin-31rlnD scrollerBase-_bVAAt", ... }
 *
 * // Inside some plugin method like "start()"
 * setStyleClassNames(pluginStyle, classNames);
 * enableStyle(pluginStyle);
 * ```
 * ```scss
 * // -- plugin.css --
 * .plugin-root [--thin]::-webkit-scrollbar { ... }
 * ```
 * ```scss
 * // -- final stylesheet --
 * .plugin-root .thin-31rlnD.scrollerBase-_bVAAt::-webkit-scrollbar { ... }
 * ```
 * @param name The name of the style
 * @param classNames An object where the keys are the variable names and the values are the variable values
 * @param recompile Whether to recompile the style after setting the variables, defaults to `true`
 * @see {@link enableStyle} for info on getting the name of an imported style
 */
export const setStyleClassNames = (name: string, classNames: Record<string, string>, recompile = true) => {
    const style = requireStyle(name);
    style.classNames = classNames;
    if (recompile && isStyleEnabled(style.name))
        compileStyle(style);
};

/**
 * Updates the stylesheet after doing the following to the sourcecode:
 *   - Interpolate style classnames
 * @param style **_Must_ be a style with a DOM element**
 * @see {@link setStyleClassNames} for more info on style classnames
 */
export const compileStyle = (style: Style) => {
    if (!style.dom) throw new Error("Style has no DOM element");

    style.dom.textContent = style.source
        .replace(/\[--(\w+)\]/g, (match, name) => {
            const className = style.classNames[name];
            return className ? classNameToSelector(className) : match;
        });
};


