# Solcord 2.4.0

Maintained by [avyxl](https://avyxl.github.io/portfolio/). Contributor: shmegg. [Project website](https://avyxl.github.io/SolCord/).

Solcord modifies the installed Discord desktop app. This release includes its Windows installer, corresponding source, and the presence/staff-proof backend.

## Changes

- OwnerBadge independently toggles Owner, Developer, and Contributor; all three can be displayed together. Each badge retains its own signed proof.
- CustomBadge has two stable upload slots, with a maximum of two visible images. Removing or replacing one slot preserves the other; legacy single-image records remain readable.
- Shmegg receives contributor metadata and the supplied photo on exactly 300 bundled plugins, selected by a fixed name list. Avyxl remains listed on every plugin.

- Shared CustomProfiles and CustomBadge uploads use the dedicated profiles channel, 1573410012716343389, in the Solcord server. No separate account link or bot setup is needed.
- New invite: https://discord.gg/BNapnPqGku. The normal Discord Join/Dismiss invite dialog appears once per Discord account after startup. Already joined accounts are skipped, and dismissal persists.
- OwnerBadge checks reusable role keys on the server, then publishes a signed proof in the channel. Viewers require a valid proof matching the Discord message author. Keys are never posted or embedded in the client.
- All plugin author cards display avyxl with the supplied photo. The contributors section also displays shmegg with the second supplied photo. Original copyright/license notices and source attribution remain.
- Shared image assets total about 17 KB. Cached profile rendering makes no network requests; channel reads and store updates are batched and bounded. The embedded payload is about 10% smaller than 2.2.0.
- Anonymous installation-counter participation remains enabled by default; later opt-outs stay saved. Profile sharing remains a separate, off-by-default switch.
- The ordinary Discord in-app loader retains the Sol logo and developed by avyxl text. The musical intro and Panda remain removed. Bleood, Session Desk, profile contrast fixes, and chat-color controls remain.

## Install and use

Extract the release ZIP, fully quit Discord, run SolcordInstaller.exe, choose the installation, and install/update. Reopen Discord, join the server, enable Solcord > Community profiles > Share my CustomProfile, then save your CustomProfile. Other users need this update, the relevant plugins enabled, and channel access.

Profile posts and images are visible in the dedicated channel. They are not hidden Discord profile fields. Email, phone, credentials, and copied-user identifiers are excluded. Standard Discord clients show the official profile.

See START-HERE.html for the full guide. Existing 2.2 users should save again to publish in the new channel and redeem staff keys again for channel proofs. The same private staff-key package remains valid.

## Performance and limits

One shared reader starts after the client is ready, processes at most five 100-message pages per pass, and retains at most 1,000 records. Rendering uses the cache, incoming updates are batched, and history refreshes pause while hidden. Passive events, a ten-minute fallback, and a manual Refresh profiles button handle updates. Very old posts beyond the initial 500-message window may need their author to save again. Use the dedicated channel for profile records.

Staff-proof lookups are batched by 20 and cached for up to five minutes with a 300-entry cap. Proofs expire after 90 days and can be renewed by redeeming the key again. A failed verification hides the staff badge.

## Build and validation

Client source is under Source/Solcord; backend source is under CommunityBackend. Use Node.js 22+ and pnpm 11.9.0:

~~~sh
corepack pnpm install --frozen-lockfile
node scripts/build/build.mjs --standalone --disable-updater
node test/sharing.mjs
node test/presence.mjs
~~~

On Windows, scripts/buildInstaller.ps1 compiles the current dist payload and writes local checksums.

Passed: desktop build, TypeScript, edited-file lint/styles, 20 backend tests, sharing/invite/presence checks, appearance/Bleood/Session Desk/security/UI regressions, two-user browser tests against an isolated Workers runtime, and all eight installer self-tests. Test Discord message traffic was mocked; no real messages or joins were sent from the user's account. A signed-in Discord desktop session was not exercised. Payload-size measurements do not guarantee FPS or memory use on every machine.

## Privacy, keys, and licensing

The approximate online counter uses only a random installation ID; the service stores its hash and last-seen time. IDs seen in the last three minutes are counted. It is not a unique-person/download total or tamper-proof count. Cloudflare processes requests under its platform policies.

Shared cosmetics are public channel posts. Server-verified staff proofs identify the account that can post them; anyone holding a universal key may claim its role. Keep raw keys and the Worker signing secret out of public packages and repositories. The deployed backend is configured; optional bot commands require a separately created Discord application.

GPL-3.0-or-later. See LICENSE and THIRD_PARTY_NOTICES.md for preserved notices. Solcord is not affiliated with Discord Inc. or the Solana Foundation. Supplied logos and photos are included as provided.

Release metadata describes the actual local installer/payload hashes. Automatic background updates remain disabled. Install future compatibility updates manually.
