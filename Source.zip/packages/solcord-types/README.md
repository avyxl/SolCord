# Solcord Types

Typings for Solcord's api, published to npm

```sh
npm i @solcord/types

yarn add @solcord/types

pnpm add @solcord/types
```
