/* eslint-disable */

/// <reference path="Solcord.d.ts" />
/// <reference path="globals.d.ts" />
/// <reference path="modules.d.ts" />
