## Solcord 3.0.3 — Plugin library, Linux setup and publishing

- Windows notification fix: native Solcord banners expire after the configured timeout. In-app notifications keep counting down while Discord is unfocused, and switching apps releases a stale hover pause.

- Favorites: Star frequently used plugins and filter the library to your favorites.
- Recently opened: Return to plugins whose settings you opened recently.
- Saved sorting: Choose popular, alphabetical, favorites-first or recently opened order.
- Intent search: Search for tasks such as clean DMs, quiet audio or profile PNGs.
- Lightweight search: Ordinary search uses metadata; individual-setting search is optional.
- Bounded plugin pages: Choose 30, 60 or 90 cards per page instead of drawing the entire library.
- Remembered page size: Your page-size and sorting preferences survive restarts.
- Keyboard search: Ctrl+F focuses plugin search; Escape clears its text.
- Clear filters: Reset search and filters with one action.
- Plugin requirements: Cards identify staff keys, community access and platform requirements.
- Copy plugin names: Copy a plugin name directly from its card.
- Copy filtered list: Copy matching names and enabled states without exporting settings or keys.
- Accessible controls: Favorite and settings buttons have labels and visible keyboard focus.
- Release details: Updater settings show the running version, last check and signature status.
- Restart status: See pending restarts or rollback notices and copy a concise version report.
- Version ordering: A signed older or malformed release cannot replace a newer client.
- Native Linux setup executable; no system Python or FUSE required. Includes Arch system-Electron support and a native launcher that replaces itself with Discord.
- New standalone Windows Solcord Publisher selects a compiled release, checks its existing signing key, and publishes immutable signed update files with corresponding source. No Node.js or rebuild is required to publish.
- Keeps the existing 623-plugin desktop bundle and shared profile/badge formats.

## Solcord 3.0.2 — SolcordBot and installer update fix

- Adds optional, key-activated `,sol` commands to the existing 3.0.0 client.
- Preview and confirm purges of your own messages in the current channel or DM, with any positive count or all eligible history. Other authors are excluded; pinned messages are skipped by default.
- Includes stop/status, message counting, last-message links, IDs, link copying, Discord timestamps, private notes and uptime.
- Uses fixed scan boundaries, bounded memory, serialized deletions, Discord retry times and account-change cancellation. Command replies stay local.
- Existing 3.0.0 plugins, profile sharing and badge compatibility are retained.
- Activation is a shared local code, not server-enforced licensing. See docs/SOLCORD-BOT.md.

# Solcord 3.0.0-dev.2

Fixed packed workspace loading, redesigned the Windows installer, reduced startup script parsing, and enabled the signed installed-client updater with the owner public key. Added the Windows Update Manager to build and publish future signed updates. Added Clipboard Expiry. Detailed notes: docs/CHANGELOG-3.0-dev.2.md. This development release contains 144 implemented additions, 54 planned, 1 partial and 1 already covered. The user accepted 144 additions for this release.

# Changelog

## 3.0.0-dev.1 (development, 2026-11-22)

This is an unfinished development build. It is not the completed 200-feature release.

- Persistent changelog button in the top-right toolbar, Settings > Changelog, and the Settings home action.
- All 200 proposals have explicit Available, In progress, Already covered, or Planned status. Planned entries are not working plugins.
- 143 additions currently implemented; 1 in progress, 1 already covered by the signed updater, 55 planned. See [the complete status list](docs/SOLCORD-3.0-STATUS.md).
- Added send/edit safeguards, draft history, bounded local indexing, image/media tools, document indexing, personal notebooks and local planning tools.
- Added shared PTT, call-quality and speaking-time monitoring, explicit device failover and per-device volume profiles. No additional getStats polling or speech recording is used by these monitors.
- Added selective settings import with review and pre-import backup, configuration checks, profile-sync diagnostics and reviewable support reports.
- Added a live shortcut registry used by Keyboard Navigation and Command Palette, with conflict inspection.
- Added saved local search workspaces with filters and result pages, account-specific channel aliases and seven-day navigation trails.
- Added supported attachment playback memory with privacy pauses and an in-app media volume/playback panel.
- Tool workspaces load after an explicit Open action. Optional speech models are downloaded only after permission in the tool.
- Added per-thread reading checkpoints, cached catch-up outlines, per-channel attachment spoiler defaults, own-message repost drafts and attributed conversation PNG exports.
- Added a local font coverage inspector, optional on-device OCR and HEIC conversion, official documentation reference cards, and configured checksum/URL reputation lookups with explicit review.
- Compiled the Windows WPF development installer with the current embedded payload, version label and prerelease-aware upgrade ordering. Seven portable installer check groups pass; Windows GUI and platform-specific checks remain outstanding.
- Repaired the development source archive's missing dependency patch and made its test setup portable.

Validation: 104 local model cases, 15 native-service adapter cases, 13 voice-runtime cases, 15 account/navigation runtime cases, 10 playback-runtime cases and 6 changelog/deferred-loading cases; 10 thread/catch-up/spoiler cases and 13 compose/PNG/worker/reputation cases; TypeScript and source lint. Chunk, webpack, method-wrapper, profile-sharing, multi-badge, rules, UI regression, mutation-string and 150,000-round fuzz checks pass. The broad security suite reports four DNS integration failures because this environment intercepts the test connection with HTTP 403 before the scripted resolver runs. The historical bundle size ratchet also still fails (704 KB startup, 3,886 KB optional chunks against 405/3,353 KB limits); its limits were preserved. Real Discord, OS audio hardware and optional model downloads still need integration verification. The older browser fixture passed in the previous environment; the current environment restricts Chromium startup.

## Inherited source history

The earlier source history below is retained for traceability. It is separate from this development build's release numbering.

## 4.1.1 (2026-11-15)

### Added

- Panda visits: now and then the panda somersaults along the bottom of Discord, head to toe. Click it to catch it. It never comes while you're typing, sharing your screen or watching something full screen, and Panda visits in the Solcord tab turns it off. A few smaller surprises came with it.

### Security

- SharePerms kept its limits only for well-formed commands. The user named in a command went into the request's address as typed, so someone given a single permission could reach other parts of the account: `+kick ../../../channels/<id>` deleted a channel. Commands now take a mention or an ID and nothing else.
- AntiDeleteMessage no longer sends back a message you deleted yourself on this device. It used to, so something pasted by mistake couldn't be removed while the plugin was on.
- A settings file or cloud sync can't set the protected settings at all. Until now a hand-made file could on a device that had none of them set, which let it choose who may use SharePerms or where uploads go. Whom FollowUser follows into voice channels and calls, and whom AutoDisconnect acts on, are protected the same way.
- The updater, install.sh and the Linux installer check the shape of a release manifest as well as its signature. The signature covers the fields joined by line breaks, so a file's line could be moved into the installer hash and the release would verify with that file left out; a manifest must now list exactly Solcord's files and keep each field to its own line.
- A download or upload that is redirected to another host no longer takes its headers or its file along: an upload service's key stays with the server it was typed for.
- PdfViewer's pdf.js and its worker, and InvisibleChat's StegCloak, only run when they match their known hashes. Both run inside Discord's own page, and until now whatever the CDN served was trusted.
- ChannelWallpaper takes a friend's sync message only in your DM with that friend (it used to take one from any channel you share) and no longer asks Discord to delete the friend's message. The default password for a sync server is now `solcord`; a server still set to the old default needs it typed in.
- FileViewer opens its viewer in a sandboxed frame, and its description says the file's link goes to Google, Microsoft or viewstl.com.
- The browser extension and the userscript only run on discord.com and its PTB and Canary apps. They used to load on every discord.com subdomain, such as the support site, and removed that site's content security policy too.
- The Linux installer's window address carries a code that works once instead of the token its API trusts, since other users of the computer can read a process's command line. It only uses admin rights in a folder that belongs to root.
- install.sh only downloads over https, and takes just Solcord's four files out of the archive, by name.
- Starting Discord signed out no longer counts against an update. Three starts on the login page used to undo a working update and refuse it for a day.
- The loader the installers write no longer reads the folder override that exists for the installer's own tests.
- Smaller hardening: CallRecorder never overwrites a file or writes to a device name, arRPC's local server can't send Discord other kinds of events, MessageLoggerEnhanced caps how much one log read may ask for, the toolbox only opens a download link on solcord.com, an unused host left the content security policy, and the build workflow no longer leaves its token in the checkout.
- A profile another Solcord user shared is checked harder before it's shown. Its picture links may only hold the characters Discord's own links do: anything else could have reached into a theme's CSS through FullVCPFP and ThemeAttributes, which now quote the link as well. Badge bits that mean something else to Discord (system account, verified bot, spammer) are dropped, badge ids, tiers and nameplate palettes are matched against what Solcord knows, and the invisible characters that hide text or flip its direction are removed from names, pronouns and bios.

### Fixed

- With CustomProfile on, Discord no longer crashes for a moment as it starts, when you save a profile, or when another Solcord user's profile arrives. For names it changes, CustomProfile skipped part of Discord's own code, so the chat drew a message with fewer of its parts than the time before, which React can't handle.
- "+N" next to a profile's badges shows the rest of them again. With Discord's new badge pages, a profile shows six badges and "+N" opened Discord's page, which only lists the badges Discord gives out: Solcord's and the plugins' were missing, so for many profiles it was empty, or showed an error when Discord's servers didn't answer. It opens Solcord's badge window now, with every badge on the profile.
- CustomProfile lists the whole shop again. When Discord had already loaded a few items, such as the decoration on a profile it showed, the window took those few for the shop and offered only them.
- The link at the top of a plugin's window opens the plugin's source code on GitHub. It went to a page on solcord.com that doesn't exist.
- Plugins can show their small pop-up messages (toasts) again. Discord's November 14 update rebuilt how toasts work, and every plugin action that ended with one failed with an error.
- Fixes for Discord's November 14 update. BetterForwards' footer under a forwarded message opens the channel it came from again: it goes there with Discord's own navigation instead of the code Discord removed. Questify's button in the server list, and the classes and colors it gives quest tiles (Canary), work again.
- RoleColorEverywhere colors names in voice channels again while VoiceFakeDetector is on: the two changed the same spot, and whichever started second did nothing.
- WebScreenShareFixes keeps stereo on whenever DTX is off in the browser while VoiceSettings is on too. VoiceSettings' Force Stereo changed the same line first, and WebScreenShareFixes then found nothing to change.
- A creation date chosen in CustomProfile showed only on your own screen. Other Solcord users see it now, in your profile and as your account's age, like the rest of what you set there. A date someone else shares is only taken when it's a real day.
- Fixes for Discord's November 10 update. NoBlockedMessages hides blocked messages again. WebScreenShareFixes no longer adds stereo twice now that Discord adds it too. FakeNitro's and BetterScreenShare's quality and theme unlocks also work where Discord moved its Nitro checks (Canary). ShowHiddenChannels drops a patch for voice joins Discord no longer makes when you click a channel mention.
- The Plugins tab no longer breaks with "Plugin code … isn't in this build" when Solcord's files were replaced while Discord was open. Search skips the plugins it can't load and asks once for a restart, and those plugins are listed with a note to restart.
- The Linux installer falls back to solcord.com's release archive when GitHub can't be reached. It used to read single files from the site, which Cloudflare's warning on solcord.com held back, so the fallback never worked.
- More names left over from other clients are gone. Solcord Desktop's build flag and API no longer carry Vesktop's name, and its theme style is `solcord-desktop-css-core`. MusicControls' Tidal player and FontLoader use Solcord's `ec-` classes instead of Equicord's `eq-`; themes that styled the old names need the new ones. ShowBadgesInChat no longer lists the donor and contributor badges twice, once under Vencord's name. ServerBackup writes `solcord-server-backup` and still opens older backups. Questify's quest notes, three loading quotes and three plugin READMEs no longer talk about other clients, and checks for Legcord, which Solcord never runs in, are gone.
- 12 translations nothing showed any more were removed.
- UserPFP loads its list of avatars again; Solcord's content security policy was blocking it.
- Names left over from other clients are gone from what you see: SharePerms' messages and its help (which listed a command that doesn't exist), EventLogs' export file, DiscordDevBanner's variables and its "Vesktop" label inside Solcord Desktop, and three plugin descriptions that pointed at Vesktop. EventLogs and FakeDM keep what they saved under the old names. Three console shortcuts and a settings icon that only worked in Vesktop were removed.
- ChannelWallpaper's "From a URL…" did nothing in the desktop app, which has no browser prompt. It asks in a window of its own now, and checks the link is an image or a video.
- BetterSessions, Decor, IRememberYou and ProfileSets threw when they started before an account had signed in. IRememberYou's tab no longer breaks when it opens before its saved list has loaded, and Wellbeing's tab is there even when its saved numbers can't be read.
- Eight plugins (ChannelTabs, EventLogs, ExportDM, FakeDM, MoreStickers, ProfileSets, ReorderAttachments, ThemeLibrary) animated every property of some elements, including ones that change their layout; they now animate only what changes.
- A dropdown in the Solcord tab, like Language or Badge dates, opened under the group below it.
- Typing in the CustomProfile window was slow: every key redrew all of the shop's decorations, effects, frames and nameplates and two dozen styled names. Each shelf now redraws only when its own pick changes, and pictures out of view aren't drawn.
- An older installer no longer takes Solcord back to its own release. Solcord updates itself, so an installer kept in Downloads can be older than the Solcord it finds; it now keeps the newer one and only hooks Discord up again, and says so. It keeps those files only when the signed release manifest confirms they are Solcord's: anything else, a file planted there under a high version included, is replaced with the installer's own.
- Turning FakeFriends and SurfaceTranslate off and on in some orders broke Discord until a restart: both changed the same parts of Discord, and one could bring back the other's code after that plugin was off, or end up calling itself. Plugins that change Discord's stores now share one way of doing it that works in any order. MessageLoggerEnhanced and CustomProfile use it too.
- CustomCommands turned off now takes your tags with it, and turning it on again works. Before, the tags stayed usable and the plugin couldn't start again until Discord restarted.
- A command with sub-commands, like /tags, leaves the list when its plugin is turned off.
- AlwaysAnimate keeps animating gradient role colors in the member list on Discord's next update, which adds another place its old search matched first.
- WebScreenShareFixes and VoiceSettings' Force Stereo keep stereo audio, and Questify keeps blocking quest fetches, on Discord's next update, which rewrites both places.
- ImageZoom stops listening to the video it zoomed once the zoom closes.
- When a plugin's change makes one of Discord's modules fail, the log and the plugin report say which plugins changed it, instead of a bare TypeError.
- When a plugin's change made one of Discord's modules fail, Discord's own code ran in its place, but on top of the failed attempt, so the module stayed broken and every plugin that searched past it failed too. Signed out on Discord Stable this hit Discord's settings menu, which is why the daily plugin report listed about 440 broken searches; it lists none now.
- DefaultStatusForever did nothing; the custom status window now starts "Clear after" at Don't clear.
- MusicControls can translate lyrics again. The translation always failed, so lyrics stayed in their own language.
- Settings that did nothing now work: GlobalBadges' Paicord badges switch, MentionColors' server list and channel list switches, WhosWatching's spectator panel switch, and MessageLoggerEnhanced's switch to stop saving messages.
- MentionColors gives the badges back to Discord when it is turned off, instead of leaving them colored.
- VoiceMessagesInBackground's player shows its pulsing ring while a message plays.
- TidalEmbeds' player never showed in the desktop app: Discord's page doesn't allow frames from embed.tidal.com, and Solcord now does.
- A HopOn or BlockKeywords pattern that isn't a valid regex no longer breaks the plugin: HopOn threw on every message and BlockKeywords failed to start. Such a pattern just doesn't match now, and BlockKeywords' Regex Helper shows which one it is. HopOn also builds its pattern once instead of on every message.
- ClearURLs skips a provider whose pattern JavaScript can't read, instead of losing every provider.
- EncryptedMessage's decrypted text could end up under the copy of a message that MessageLinkEmbeds shows, instead of under the message itself: it checked a mark by its old Vencord name. UnlimitedFavoriteGIFs' fallback looked for Discord's modules under Vencord's name too, so it never found them.
- CustomProfile's shop sections missed what Discord only sells in a bundle, and a product opened in the shop never showed up in them: they asked Discord for a smaller catalog than its own shop does, and only refreshed when the whole catalog came in. They now ask the way the shop does, so either one's fetch serves both, list a bundle's parts and every variant, and take in products as they arrive. The catalog is also kept on this computer, so the window lists it at once instead of waiting for the shop after every start, and a search field finds an item by name across all four sections.
- MessageLoggerEnhanced's first start could fail to make its image folder when its data folder didn't exist yet. It also read, and the first time wrote, its settings file every time Discord started, with the plugin off too; now that waits until the plugin uses it.
- Turning on a plugin did nothing, its switch just slid back, when Solcord's files had been replaced while Discord was open: that plugin's code wasn't in the files any more and the error went nowhere. After an update Solcord now reads the code from the copy of the running version the updater keeps, and when that's gone too (files replaced by the installer or by hand), a notice says to restart Discord, with a button for it.
- Turning on a plugin that needs a restart made the Plugins tab jump: the restart card appeared at the top and pushed the whole list, the card you just clicked included, down by its height. The card you switch now stays exactly where it was.
- The weekly mutation test failed after 4.1.0: two of its entries, the rollback's file restore and the secret scrub on settings exports, still named the lines as they read before that release rewrote them. They match again, and every test run now checks that each entry still matches one place in the source, so a rewritten line is noticed with the change that rewrote it.

### Removed

- About 2,000 lines nothing used: functions, plugin parts left behind by older versions of their patches, styles no element has, 119 translations per language of text Solcord no longer shows, and four packages.
- MotionBlur's "whole app" switch, which did nothing: the blur always covers the whole window. Its strength slider now stops at 6 px, where the blur stops.
- FileSplitter's "join files after download" switch, which did nothing.

### Changed

- Downloads come from Solcord's [GitHub releases](https://github.com/avyxl/SolCord/releases) instead of solcord.com, which keeps its pages, install.sh and the update archive. Every release lists its files with a SHA256SUMS. Old links to the files on solcord.com lead to the same downloads.
- The installer says what Solcord sends over the network: nothing to us, an update check on GitHub, and whatever a plugin you turn on uses. solcord.com has a [code signing policy](https://github.com/avyxl/SolCord/code-signing-policy) for the coming signed Windows downloads.
- CustomProfile's window has the switch for seeing other Solcord users' profiles at the top. It was only in the plugin's settings, where it was easy to turn off without noticing.
- The Solcord tab is laid out like the installer: the panda logo, the version and how many plugins and themes are on at the top, with the contribution and donation cards right under it, then quick actions and the settings in groups (General, Appearance, Window, Performance, Advanced). Where the Solcord section goes in Settings can be picked right there. The panda on the logo wakes up while you point at it.
- Solcord's entry in Discord's settings has the logo, the E with the panda asleep on it, and every Solcord tab, including those plugins add, has a new two-tone icon that matches Discord's own, in pixel style too.
- Solcord's switches, settings and Control Center move more like things a hand moves. A switch's knob stretches while pressed, springs across a little past the end and settles, and its mark rolls with it. Settings pages come in a part at a time, the first plugin cards and the ones a search brings back come in as a wave, and a plugin's card takes a blue edge when it's on. Tiles, buttons and the logo sink when pressed and spring back. The Control Center grows out of its button and goes back into it, one highlight slides between its rows, the counts and the memory number count to their values, and a switched-on row's icon hops. Solcord's entries in Discord's settings sidebar share one blue light that slides to the one under the pointer, and their icons spring, while Discord's own entries keep Discord's hover. The CustomProfile window comes in a part at a time, and its choices, toggle, fields and buttons move the same way. With Discord's reduced motion on, none of it moves.
- FakeNitro, CustomProfile, HideSolcord, MessageLogger, SmoothType and oneko list rootpoi as their author.
- Plugin windows, about 75 of them, open in Solcord's colors and move like Solcord's own: their parts come in one after another and buttons sink when pressed and spring back. Plain fields and buttons a plugin left unstyled are drawn as Solcord's, and SharePerms, FakeDM, EventLogs and ExportDM no longer fix Discord's old colors, white text or neon greens in place.
- Every plugin's preview video is redone in a finished look: the Discord window sits on Solcord's night with the plugin's name above it and the caption under it, so nothing covers the chat, at 1280×720 and 60 fps. The "plugin turned on" switch the videos were meant to show now appears.
- Thirteen plugin descriptions that read as unfinished are rewritten, among them RecordUrMic, NoRoleHeaders, InRole, PlainFolderIcon and SteamStatusSync.
- The bug report form asks which Solcord version you have and points to the Solcord server and solcord.com/download, instead of Vencord's.
- The last places where Endcord's own text or code still said Vencord say Endcord: UserpluginInstaller's settings and messages, the translations ShowBadgesInChat no longer used, and a few internal names. The copyright notices in file headers stay, as the GPL requires.
- Code comments across Solcord read like a person wrote them: about 800 rewritten in plain technical English and 170 that only repeated the next line removed. Leftovers in French, Turkish and Italian are in English, "Step 1:" and "FIX:" notes, box-drawing banners and doc comments that restate a method's name are gone, and a few log messages lost their emoji. ZIP+ lost an unreachable fallback branch. No behaviour changes.

## 4.1.0 (2026-11-07)

### Added

- Control Center: the panda in the title bar opens your looks, profiles, Game Mode and memory use in one place.
- Theme Studio: pick colors, font and corners and watch Discord change as you go, with no code.
- Diagnostics: how long each plugin took to start and how much memory Discord uses, measured on your PC.
- Game Mode: while you play, Discord draws at a lower frame rate and pauses its animations.
- Streamer Shield: blurs your DM list in Streamer Mode, and can turn Streamer Mode on when you share your screen.
- A live security card that shows whether the running release is signed and its files are intact.
- A What's New card after big updates.
- 8 new plugins:
  - SecretGuard holds back a message that looks like it has a token, key, password or card number in it, until you press Enter again.
  - SuspiciousLinks warns under a message when a link only pretends to be Discord, Steam or another well-known site. Nothing is looked up online.
  - LocalTimes shows a time written with a time zone, like "8pm EST", in your own time zone.
  - QuoteMessage quotes a message in your message box, with who wrote it and a link back.
  - ReplyChain shows the whole conversation a reply answers, in one window.
  - DraftList lists every chat where you left a message unsent.
  - ColorText's /color writes your message in color.
  - PrivacyCurtain blurs Discord while you're away.
- An Solcord Developer badge, the panda, for the people who make Solcord. The Solcord Contributor badge is now a stalk of bamboo.
- A welcome screen on the first start: pick a look and a few packs of plugins, or start with none.
- CustomProfile is shared: other Solcord users see your profile, through the #profiles channel on Solcord's Discord server, a few seconds after you save it. Nothing goes through a server of Solcord's own.
- CustomProfile has a Nitro date: the day your Nitro badge says you subscribed, shown when someone hovers it.
- When Discord can't finish starting, Solcord looks for a newer release by itself after a few minutes, installs it and loads Discord again. Before, a release that broke on a new Discord could only be fixed by downloading the installer again.

### Changed

- Every Solcord screen uses one look, the Solcord theme, and one way of moving.
- The repository root is tidier: the installer's sources are in `installer/` and the app icons in `assets/`.
- File headers carry their original copyright notices again, as written in Vencord and Equicord.
- 18 plugins that did the same job as another plugin are gone. If you had one on, the plugin that does its job is turned on for you:
  - SpotifyControls → MusicControls
  - RecentDMSwitcher → RecentChannelSwitcher
  - FollowVoiceUser → FollowUser
  - CancelFriendRequestNC → CancelFriendRequest
  - ZipPreview and AutoZipper → ZIP+
  - GifCaptioner → GifMaker
  - LastFMRichPresence → MusicRichPresence
  - TalkInReverse → ReverseText
  - DoubleClickEdit → MessageClickActions
  - FavoriteMedia → FavoriteAnything
  - ProfileMedia → ViewIcons
  - StreamerModeOnStream → StreamerShield
  - Translate+ → Translate
  - ClickableRoles → InRole
  - FriendInvites → FriendCodes
  - rzStudioAudio → VoiceSettings
  - FavoriteGifSearch had nothing left to do, since Discord now searches favorite GIFs itself.
- The Plugins tab opens faster and stays smooth: it draws the first cards at once and the rest just after, and turning one plugin on no longer draws every card again. Its switch slides first, then the plugin starts.
- The CustomProfile editor has a wider scrollbar with room around it.
- The Privacy pack on the welcome screen includes SecretGuard and SuspiciousLinks.

### Fixed

- ChannelWallpaper's "From a URL…" did nothing in the desktop app, which has no browser prompt. It asks in a window of its own now, and checks the link is an image or a video.
- BetterSessions, Decor, IRememberYou and ProfileSets threw when they started before an account had signed in. IRememberYou's tab no longer breaks when it opens before its saved list has loaded, and Wellbeing's tab is there even when its saved numbers can't be read.
- Eight plugins (ChannelTabs, EventLogs, ExportDM, FakeDM, MoreStickers, ProfileSets, ReorderAttachments, ThemeLibrary) animated every property of some elements, including ones that change their layout; they now animate only what changes.
- A dropdown in the Solcord tab, like Language or Badge dates, opened under the group below it.
- Typing in the CustomProfile window was slow: every key redrew all of the shop's decorations, effects, frames and nameplates and two dozen styled names. Each shelf now redraws only when its own pick changes, and pictures out of view aren't drawn.
- Discord Canary no longer stays on its "Starting" screen with Solcord installed. Newer Discord builds pass some exports as plain values and no longer mark modules as loaded, and Solcord now handles both.
- Discord's old color names point at the new ones, so themes written for them keep working.
- FileViewer works again. It read the file type from the link, which ends in Discord's signature, so it never showed its button, and Discord's security policy blocked the viewers it opens.
- With PdfViewer on, FileViewer leaves PDFs to it, so they aren't sent to Google's viewer.
- F8Break and HideSolcord both use F8. Turning one of them on now offers to turn the other off.
- ChannelTabs and RecentChannelSwitcher both use Ctrl+Tab. Turning one of them on now offers to turn the other off.
- Discord's update of November 6 broke these, and they work again:
  - Questify (the Quests tab in Discovery)
  - BetterSettings (the settings fade delay)
  - OnePingPerDM
  - KeywordNotify (its inbox tab)
  - BetterForwards (its footer)
  - The icons in IconViewer, ChannelTabs' folders and BetterForwards
  - SidebarChat's forum view
  - Every plugin that loads a part of Discord on demand
- Plugins fixed for the same new Discord: BadgeAPI, SurfaceClassesAPI, FakeNitro, AlwaysAnimate, VolumeBooster, CustomIdle, MoreJumboEmoji, NoDraftLengthLimit, OpenInApp, FavoriteAnything, FullVCPFP, USRBG, ImageLink, NoReplyMention, BetterImageEditor and PermissionFreeWill.
- RoleColorEverywhere colors reaction lists and poll results again, and the member list's role headers alongside BetterRoleContext.
- CustomTimestamps and RealtimeTimestamps show their tooltips on Discord's timestamps again.
- Notices from Solcord show again, and so does the version line in Settings.
- Questify keeps quest videos playing again.
- DmReadReceipt no longer breaks message previews, such as the one in CustomTimestamps' settings.
- BetterSessions no longer announces every session you already have as new the first time it runs.
- The welcome screen and the new plugins window no longer open on top of each other.
- ShowBadgesInChat's contributor badge shows again: its picture came from a site Discord blocks.

## 4.0.33 (2026-11-01)

### Fixed

- ChannelWallpaper's "From a URL…" did nothing in the desktop app, which has no browser prompt. It asks in a window of its own now, and checks the link is an image or a video.
- BetterSessions, Decor, IRememberYou and ProfileSets threw when they started before an account had signed in. IRememberYou's tab no longer breaks when it opens before its saved list has loaded, and Wellbeing's tab is there even when its saved numbers can't be read.
- Eight plugins (ChannelTabs, EventLogs, ExportDM, FakeDM, MoreStickers, ProfileSets, ReorderAttachments, ThemeLibrary) animated every property of some elements, including ones that change their layout; they now animate only what changes.
- A dropdown in the Solcord tab, like Language or Badge dates, opened under the group below it.
- Typing in the CustomProfile window was slow: every key redrew all of the shop's decorations, effects, frames and nameplates and two dozen styled names. Each shelf now redraws only when its own pick changes, and pictures out of view aren't drawn.
- The window drags from its title bar again.
- Old Stable profiles that still use discordapp.com are trusted.

## 4.0.32 (2026-11-01)

### Security

- Releases are verified before they're installed, and the installers are hardened.
- The main process, the preload script and plugin natives are locked down.
- The browser extension and the build toolchain are hardened.
- Security tests, a threat model and architecture docs were added.

### Changed

- Translations are split into one file per language.
- Every repository link points at Solcord/Solcord.

### Fixed

- ChannelWallpaper's "From a URL…" did nothing in the desktop app, which has no browser prompt. It asks in a window of its own now, and checks the link is an image or a video.
- BetterSessions, Decor, IRememberYou and ProfileSets threw when they started before an account had signed in. IRememberYou's tab no longer breaks when it opens before its saved list has loaded, and Wellbeing's tab is there even when its saved numbers can't be read.
- Eight plugins (ChannelTabs, EventLogs, ExportDM, FakeDM, MoreStickers, ProfileSets, ReorderAttachments, ThemeLibrary) animated every property of some elements, including ones that change their layout; they now animate only what changes.
- A dropdown in the Solcord tab, like Language or Badge dates, opened under the group below it.
- Typing in the CustomProfile window was slow: every key redrew all of the shop's decorations, effects, frames and nameplates and two dozen styled names. Each shelf now redraws only when its own pick changes, and pictures out of view aren't drawn.
- Plugin patches broken by Discord updates.

## 4.0.31 (2026-10-29)

- SupportHelper asks only once to join the Solcord server and to star the repository.

## 4.0.30 (2026-10-28)

- CustomProfile: hiding Nitro no longer breaks file uploads.

## 4.0.29 (2026-10-26)

- CustomProfile: avatar decorations and profile effects work again.
- Each plugin contributor is listed once.

## 4.0.27 (2026-10-24)

- Linux and macOS installs work even when the site's scripts are blocked.
- A macOS installer app that carries its own copy of Solcord.
- The unused profile-fetch code and the stale `api.solcord.com` entry in the content security policy are removed.

## 4.0.26 (2026-10-24)

The first release from this repository.

- Plugins that are off aren't loaded at all, and translations are built on first use, so Solcord starts faster and uses less memory.
- A new installer around the logo's pixel panda, which never removes a mod another Discord install still uses.
- Every plugin description, setting and message is available in English, Turkish, Russian, Spanish and French.
- Dozens of plugins fixed for current Discord, plugins that patch the same spot run together, and plugin conflicts are explained instead of crashing.
- Updater checksums, a reproducible [benchmark](benchmark/README.md) against Vencord, Equicord and plain Discord, and one-command releases.
