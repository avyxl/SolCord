# Solcord update-signing key setup

Run this on your own Windows PC. The key is created there; never send the private key here.

1. Extract the source ZIP and install Node.js 22 or newer. Open PowerShell in the extracted project.
2. Run `node scripts/setupUpdateKey.mjs`.

The private key is saved at `%USERPROFILE%\.solcord\update-signing-key.pem`. Windows permissions restrict it to your account and SYSTEM. The script refuses to overwrite an existing key or place it inside the source project. Keep an encrypted private backup. Losing the key prevents signing updates trusted by installed clients.

3. The script updates the public trust in `src/main/updater/updateKey.pem` and `installer/Core/ReleaseManifest.cs`. These public files can be committed. If you need help, send only `update-signing-key.public.pem`.
4. Rebuild both the client and installer after setup. Older installations need a manual reinstall to trust your new key. A server manifest cannot silently change their trusted key.
5. In a clean Git checkout, install pinned dependencies with `corepack pnpm install --frozen-lockfile`, commit the public-key/source changes, then run `node scripts/uploadRelease.mjs --dry-run` on Windows.

The release script reads the private key at the default location. For another location, set the SOLCORD_UPDATE_KEY environment variable to its full local file path first. That variable is a path, not the key contents.

6. Review the generated payloads and signed version.json under `dist/release`. Publish the exact generated files together using your repository release process. Keep corresponding source with the release. Do not edit a signed manifest afterward.

This handoff is a local development build. It does not publish a release or enable an unsigned update feed. Discord compatibility fixes still need to be implemented, built, signed and published; an updater cannot generate those fixes.

Mobile uses P-256 too, with a different manifest format. Put the base64 SPKI public key in its `bundle/release-key.pub`, rebuild Android and iOS loaders, then sign with `bundle/scripts/sign-release.mjs`. Keep mobile and desktop manifests separate. Never leave Endcord’s public key in a Solcord release.

If setup stopped after creating the key, update to the corrected script and run `node scripts/setupUpdateKey.mjs --resume`. This retains the existing private key and finishes public-key setup; it does not rotate your key.
