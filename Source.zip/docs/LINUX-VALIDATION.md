# Linux 3.0.2 validation

GitHub Actions run: https://github.com/avyxl/SolCord/actions/runs/45244147089
Commit: cc9276ff6a7803f946c92455931bb1c499570376
Runner: Ubuntu 24.04; Node 24; Electron 41.2.1.

Passed: 11 Linux installer filesystem, rollback, symlink, process-lock and restrictive-umask tests; all 720 packed chunks for 623 lazy plugins parsed and resolved; deferred import/cache checks; 12 SolcordBot groups; 104 Solcord3 model cases; 17 native-service adapter cases; 13 voice-runtime adapter cases; 15 navigation/account-collection cases; 10 playback-runtime cases; 10 reading/spoiler cases.

Native smoke test used a disposable ASAR/Electron fixture app: the real packaged Solcord main-process patcher loaded, replaced BrowserWindow preload, executed the real Solcord preload followed by the original fixture preload, booted the original ASAR, uninstalled, and booted vanilla again. No live Discord account, token, private key or external conversation was used. This validates the loader architecture; it is not a live Discord/hardware certification of every plugin. Windows/macOS-only integrations retain their platform requirements; immutable Flatpak/Snap images are not patched.

Linux artifact SHA256: e79f447adbbb78eb4a1b3fbe79e486b3a9bb0dba78e3e949c45b56154e1da8b5
Same four universal desktop payloads as the delivered Windows 3.0.2 installer.
