# Configure reputation lookups

The optional File Reputation Lookup and Link Reputation Lookup plugins use an operator-supplied public HTTPS service. They do not ship an API key or pretend that a result is available before the service is configured.

In Integration controls, allow your service's exact origin and choose a daily request budget. The native public-resource client blocks private-address endpoints, checks redirect origins, caps responses and applies a timeout. Credentials and Discord tokens are not sent. Keep a third-party provider's API key on your own server, outside the client and source repository.

File lookup sends `GET /your-endpoint?sha256=<64-lowercase-hex>`. Response example:

```json
{"sha256":"same requested hash","verdict":"unknown","source":"Your provider","details":"No record for this checksum."}
```

URL lookup sends `GET /your-endpoint?url=<encoded-complete-url>`. Response example:

```json
{"url":"exact requested normalized URL","verdict":"suspicious","source":"Your provider","details":"Provider explanation."}
```

Accepted verdicts: `clean`, `unknown`, `suspicious`, `malicious`. Results must echo the exact requested identifier. A result for a different file or URL is rejected. Users review the outgoing checksum or complete URL before a request. Files are never uploaded by the checksum tool. Use an authenticated/rate-limited backend if your provider charges for queries; a public proxy with an embedded provider key needs its own access controls.

API Reference Cards reads a chosen page from supported official documentation sites. It returns attributed excerpts matching the requested term. It does not generate undocumented API signatures or claim a general web search.
