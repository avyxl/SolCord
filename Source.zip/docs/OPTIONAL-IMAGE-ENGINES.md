# Optional local image engines

Local Image OCR requests Tesseract.js 7.0.0 (Apache-2.0), tesseract.js-core 7.0.0 and the selected English, Arabic or Hebrew language package at 1.0.0 from jsDelivr. The engine runs in dedicated workers after an explicit download action. OCR uses a local PNG reduced to at most 4 megapixels. Closing/cancelling terminates the worker tree. Downloaded engine files and language data are not included in the startup script.

HEIC Converter requests heic-to 1.6.7 (LGPL-3.0), which uses libheif, from jsDelivr. Its worker-compatible entry is used in a module worker. Container dimensions are checked before decoding, and the actual decoded dimensions are checked again before encoding the primary image to PNG/JPEG. Input is limited to 25 MB and 24 megapixels. Images are never sent to the CDN. Output encoding excludes original EXIF/location metadata.

Primary sources:

- https://github.com/naptha/tesseract.js/blob/master/docs/api.md
- https://github.com/naptha/tesseract.js/blob/master/docs/local-installation.md
- https://github.com/hoppergee/heic-to (worker entry and license)
- https://github.com/strukturag/libheif
- https://learn.microsoft.com/en-us/typography/opentype/spec/cmap (the local font inspector)

The CDN receives ordinary engine-file download requests and the selected language package name. OCR/decoder downloads require network access. Model/engine API checks are separate from real Discord and browser CSP integration testing; do not describe the latter as verified until run in the target client.
