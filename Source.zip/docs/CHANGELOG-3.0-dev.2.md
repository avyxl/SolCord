# Solcord 3.0.0-dev.2

Development preview. See SOLCORD-3.0-STATUS.md for exact availability.

## Plugin loading fixes

- Open buttons now load workspace code from the installed renderer instead of requesting JavaScript from discord.com.
- Nested workspace panels use the same local chunk loader. Opening a tool keeps unrelated panels deferred.
- Failed chunk initialization no longer leaves a half-initialized module cached.
- A missing renderer from the running build asks for a restart; it does not run chunks from a different build.

## Windows installer

- New wide layout with a persistent setup sidebar and clearer client selection.
- Sora headings and Manrope body text are embedded; no font installation or font download is required.
- Purple actions, mint status accents, rounded controls and a slim progress bar replace the pixel controls.
- Removed the delayed pixel intro, speed-line effects and snoring mascot.
- Keyboard activation and visible button focus remain available. Motion follows the Windows animation preference.
- Install, repair, uninstall, settings migration, backups, cancellation rollback and payload integrity checks retain their existing behavior.

## Startup and performance

- Branding images are stored as bounded local data instead of executable JavaScript. The supplied image bytes are preserved.
- The Discord renderer script dropped from approximately 703 KB to 448 KB in the current standalone build. This measures script size, not total app RAM.
- Only three fixed image names can be requested. The image bridge does not accept file paths or remote URLs.
- Startup caches retain the image records actually used and invalidate when the installed renderer changes.
- Feature results are paginated so opening the catalog does not render all 200 entries at once.
- Heavy models, optional engines and feature workspaces continue to load on request.

## Reading and navigation

- Thread Checkpoints stores bounded, account-specific scroll checkpoints and restores them only when appropriate. Explicit message links take priority.
- Catch-up Outline uses cached thread metadata, mention counts and timestamps. It does not fetch a complete message archive.
- Search Workspaces retains named query, filter and page combinations in a bounded account collection.
- Local Channel Aliases changes local channel labels without changing server channel names.
- Navigation Trail records bounded internal navigation metadata and pauses in private sessions.

## Media and files

- Local Image OCR offers explicit downloads for supported language engines and cancels its worker when the action is cancelled.
- HEIC Converter checks dimensions and size before decoding and rejects oversized output.
- Conversation Capture creates an attributed image from selected cached messages with count and text limits.
- Font Coverage Checker reads supported local TTF/OTF cmap formats and compares temporary-font coverage.
- Playback Memory stores bounded positions for finite Discord attachment media; it excludes streams and temporary media URLs.
- Media Audio Mixer controls the current HTML media players while its panel is open. It does not change Discord voice codec processing.

## Composing and shared data

- Move My Message prepares a reviewed destination draft from your own cached message. It does not automatically send or delete either message.
- Channel Spoiler Defaults marks new attachments in configured channels and respects later changes to an individual draft.
- Account-specific collections use atomic updates and account-generation checks to prevent edits from being applied to the wrong account.
- Private-session controls pause supported local history and collection features.

## Reference and reputation tools

- API Reference Cards extracts attributed excerpts from a chosen official documentation page.
- File Reputation Lookup submits a reviewed SHA-256 checksum rather than uploading the selected file.
- Link Reputation Lookup submits the reviewed complete URL to a configured HTTPS service.
- Integration origins and request budgets must be configured before network tools can request their services.
- Reputation replies must match the requested target. A result from an unrelated lookup is refused.

## Voice utilities and maintenance

- Supported voice monitors use cached Discord connection information and bounded observations.
- Backup-device preferences are explicit and device controls are scoped to the selected devices.
- Selective settings imports create a backup and check for concurrent changes before applying reviewed updates.
- Support and settings diagnostics filter protected values and report supported configuration problems.
- The shortcut inspector reads the live providers supported by Keyboard Navigation and Command Palette.

## Updates and development status

- The local update-key setup script creates the owner key on the owner’s PC, outside the source project, and updates the public trust in the client and Windows installer.
- The setup refuses to overwrite an existing private key. Only the public key should be shared.
- This preview is a local build. It does not publish an online release or accept unsigned update metadata.
- The exact counts below distinguish implemented, partial, already-covered and planned requirements. Planned requirements are not installed plugins.
- Live Discord and real device integration still need verification. The bundle-size ratchet remains above its existing limits.

## Signed Windows updates and owner publishing

- Automatic updates are enabled by default for installed standalone Windows mod builds. An existing disabled preference is respected.
- Client and installer trust the owner public key. A release needs its valid signature and each downloaded file must match its SHA-256 checksum.
- The updates branch hosts the Windows mod feed; payload URLs name immutable commits. No remote release has been published by this package.
- Concurrent update checks and installs are deduplicated. Exclusive payload locks coordinate with installer repair.
- All downloads are validated before staging. The previous files remain available for interrupted swap recovery and startup rollback. An older running process cannot confirm a newer update before restarting.
- Added the compiled Solcord Update Manager for local preparation and authenticated Git publication, with the signing key retained on the owner PC. See PUBLISHING-UPDATES.md.
- Clipboard Expiry is the 144th implemented addition. It copies temporary text and clears it after the chosen interval only if its unique clipboard marker still matches.
- Mobile builds are deferred for this release.
