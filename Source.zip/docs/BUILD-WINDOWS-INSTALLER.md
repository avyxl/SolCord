# Build the Windows installer

The installer uses the existing Windows WPF interface and installation engine. It targets .NET Framework 4.8 and embeds the complete client, its supplied logo, and SHA-256 checksums. The default build does not install into Discord.

On Windows, build the client with `pnpm buildStandalone`, then run `powershell -File scripts/buildInstaller.ps1`. That command compiles the installer and runs its Windows self-tests. Close any running copy of the output installer first; the build does not terminate processes.

For compilation on Linux, install Microsoft's .NET SDK and extract the official `Microsoft.NETFramework.ReferenceAssemblies.net48` NuGet package. Run:

```sh
pnpm buildStandalone
node scripts/buildInstallerCross.mjs --dotnet /path/to/dotnet --references /path/to/net48/build/.NETFramework/v4.8
```

The result is a real Windows executable, `SolcordInstaller.exe`. Compiler and reference files are build dependencies; they are not bundled with the installer. The `version.json` file describes this local build and does not claim to be a signed online update feed.

Cross-compilation does not run Windows. Run `SolcordInstaller.exe --self-test installer-selftest.log` on Windows to exercise Windows CNG signing checks, registry behavior, file locking and the full installation suite. Running the executable without arguments opens its normal installer UI.

For 3.0.0-dev.1, the current payload is an unfinished development preview. See `SOLCORD-3.0-STATUS.md` for the available features. Keep it separate from the stable 2.4.0 release.

Portable checks after cross-compiling:

```sh
node test/installer-portable.mjs --dotnet /path/to/dotnet
```

These run the real localization, filesystem detection, migration, integrity, version ordering and install/repair/uninstall code in isolated temporary folders. They also inspect the actual Windows PE metadata and compare every embedded payload to the current build. They explicitly leave the Windows GUI, Windows CNG signing, registry and platform-specific file-lock behavior untested.
