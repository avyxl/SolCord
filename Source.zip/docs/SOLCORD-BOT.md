# SolcordBot

Enable **SolcordBot** in Settings → Solcord → Plugins. Open its settings and redeem the activation key supplied separately by avyxl. Activation is saved for the current Discord account on this device. Use the same key again after switching devices. The distributed plugin contains a SHA-256 verifier, not the original key. This is a shared local activation gate, not server-enforced licensing or a one-use redemption service.

The prefix is `,sol` followed by a space. Commands and replies stay in your local client; no separate Discord bot account or bot token is used. Leave the plugin enabled for its prefix to be intercepted.

| Command | Action |
| --- | --- |
| `,sol help` | Show commands locally. |
| `,sol unlock` | Open key redemption. |
| `,sol purge 50` | Review and delete up to 50 of your latest eligible messages in the current conversation. |
| `,sol purge all` | Review and delete all your eligible messages before the scan's starting time. |
| `,sol count` | Count your eligible messages without deleting them. |
| `,sol stop` | Stop the running scan or purge after the request already in flight. |
| `,sol status` | Show progress locally. |
| `,sol last` | Link to your latest eligible message. |
| `,sol id` | Show your user, channel and server IDs. |
| `,sol link` | Copy the conversation link. |
| `,sol timestamp` | Copy a relative Discord timestamp for now. |
| `,sol timestamp 1800000000 F` | Copy a timestamp for an explicit Unix time and display style. |
| `,sol note add text` | Save an account-local note (up to 100 notes, 1500 characters each). |
| `,sol note list` | List saved notes locally. |
| `,sol note remove 2` | Remove a numbered note. |
| `,sol note clear` | Clear the current account's local notes. |
| `,sol uptime` | Show how long the plugin has been running. |

Purges apply only to the account and conversation captured at the start. A read-only scan shows the actual count and up to five example messages. Type **DELETE** in the confirmation to begin. Other people's messages, webhook messages and system events are excluded. Pinned messages are skipped unless enabled in the plugin's settings before the scan starts. The oldest matching ID is retained, so messages removed separately between scanning and confirmation do not cause older messages to be substituted.

There is no artificial 100-message purge cap. History is read in pages of 100, keeping memory bounded. Deletions run individually, with a 1.2 second minimum delay and additional waits when Discord requests them. Large histories can take a long time. Loss of access stops the operation; it does not silently skip permission failures. Closing or disabling the plugin, changing accounts, locking activation or using stop cancels future requests. A request already sent can complete. A restart never resumes a purge automatically.

The existing server bot remains separate and unchanged. This addition uses the existing desktop profile and badge protocols and does not change mobile client compatibility.

Validation: `node test/solcord-bot.mjs` exercises real plugin code using explicit Discord adapters: ownership filtering, pagination over 100, full history, pinned messages, fixed confirmation boundaries, 429 retry times, 403/404 handling, cancellation, account changes, prefix interception, activation hashing and listener cleanup. Live-account deletion is not performed by these tests.
