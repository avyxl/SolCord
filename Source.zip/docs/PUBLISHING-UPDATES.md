# Publish a Solcord update

1. Extract the Windows installer ZIP and open **SolcordPublisher.exe**. You can also use the separate Publisher download.
2. Choose the complete installer ZIP for the version you want to release. The app reads its version, plugin count, checksums and corresponding source automatically. If you use the EXE, keep its included Source folder beside it.
3. Select your existing update-signing-key.pem if it is not found. The original default is in your home folder under .solcord. Do not generate a replacement key for an ordinary update. Never upload or share this private file.
4. Use **GitHub sign-in** if needed and sign in as avyxl with permission to push to avyxl/SolCord.
5. Click **Check update**. This checks the existing online release, verifies your key against installed clients, signs the new feed and prepares files locally. Nothing is uploaded yet.
6. Check the displayed version change, then click **Publish update**. Wait for the confirmed success message.

Clients receive the release on their normal automatic update checks. They load changed code after Discord restarts. Manual checking is available in Settings > Solcord > Updater.

Requirements: Windows 10/11, .NET Framework 4.8, Git for Windows and access to the existing repository. The publisher does not require Node.js, npm, a source rebuild or a typed version number. A new client version still needs to be built before publishing; choose that compiled installer ZIP.

The app publishes only to the updates branch. Each payload URL points to an immutable commit. The feed includes exactly the four desktop payloads and their SHA-256 checksums. The installer and corresponding Source.zip are published together. The private signing key stays on your PC and is never copied to the release repository.

The app refuses wrong keys, invalid installer checksums, a same/older version, changed staged files and a remote branch changed after checking. If the branch moved, click Check update again. It never force pushes. Public update trust is unchanged from Solcord 3.0.2.

If Git cannot sign in, install Git for Windows, close/reopen the publisher and use GitHub sign-in. If the key is missing, restore your original private key backup. If you get a source warning, choose the complete installer ZIP, not an EXE copied on its own.
